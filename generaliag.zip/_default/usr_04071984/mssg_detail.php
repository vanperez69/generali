﻿<?php
include('header.php');
// get value of id that sent from address bar
$id=$_GET['id'];
// Retrieve data from database 
$sql="SELECT * FROM $mail WHERE mssg_id='$id'";
$update = db_query($connect,"UPDATE $mail SET m_status='read' WHERE mssg_id='$id'");
$result=db_query($connect,$sql);
$rows=db_fetch_array($result, MYSQLI_ASSOC);

?> <!--PAGE CONTENT -->
        <div id="content" class="flex-1 p-6">
             
            <div class="min-h-[700px]">
                  <!--END BLOCK SECTION -->
                <div class="mb-8"></div>
                <div class="w-full">
                   <div class="w-full">
                    <div class="bg-white rounded-lg shadow-md border border-gray-200">
                            <div class="bg-gray-50 px-6 py-4 border-b border-gray-200 rounded-t-lg flex justify-between items-center">
                                <h3 class="text-lg font-semibold text-gray-800">Message Details</h3>
                               <button onclick="history.back()" class="bg-blue-500 hover:bg-blue-600 text-white font-normal py-2 px-2 rounded-md transition-colors duration-150 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 flex items-center gap-2">
                                   <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                       <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path>
                                   </svg>
                                   Back
                               </button>
                            </div>
                            <div class="p-6">
                                <div class="overflow-x-auto">
<form action="" method="post">
			<table class="min-w-full divide-y divide-gray-200">
  <tr class="border-b border-gray-200">
    <td class="px-6 py-4 whitespace-nowrap">
	<div class="element">
	<label class="block text-sm font-medium text-gray-700 mb-1">From: </label>
	<span class="text-sm text-gray-900"><?php echo $rows['m_from']; ?></span></div>
	</td>
    <td class="px-6 py-4 whitespace-nowrap"><div class="element">
	<label class="block text-sm font-medium text-gray-700 mb-1">To: </label>
	<span class="text-sm text-gray-900"><?php echo $rows['m_to']; ?></span></div></td>
    <td class="px-6 py-4 whitespace-nowrap"><div class="element">
         <label class="block text-sm font-medium text-gray-700 mb-1">Date:</label>
         <span class="text-sm text-gray-900"><?php echo date ('j M, Y', strtotime ($rows['m_date'])); ?></span></div ></td>
  </tr>
</table>
<table class="min-w-full divide-y divide-gray-200 mt-4">
  <tr class="border-b border-gray-200">
    <td class="px-6 py-4 whitespace-nowrap"><label class="block text-sm font-medium text-gray-700 mb-1">Subject:</label> <span class="text-sm text-gray-900"><?php echo $rows['m_subject']; ?></span></td>
  </tr>
</table><div class="element mt-4">
			   <label class="block text-sm font-medium text-gray-700 mb-1">Message: </label>
			   <span class="text-sm text-gray-900"><?php echo $rows['m_message']; ?></span></div>
</td>    	
</form>
			  <div class="text-right mt-6">
			  <button type="submit" class="inline-flex items-center px-4 py-2 bg-gray-100 border border-gray-300 rounded-md font-medium text-gray-700 hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500" onclick="window.print();return false;">Print</button></div>
			  
                                </div>
                            </div>
                        </div>
                    </div>
                     
                </div>
                 <!--END STACKING CHART SCETION  -->

                
            </div>

        </div>
        <!--END PAGE CONTENT -->
<!-- RIGHT STRIP  SECTION -->
        <?php
        include('ads.php');
        ?>
         <!-- END RIGHT STRIP  SECTION -->
    </div>

    <!--END MAIN WRAPPER -->

                   <?php
include('footer.php')

?>