﻿<?php
include('header.php');

$id=$_SESSION['id'];
// Retrieve data from database 
$sql="SELECT * FROM $tbl_name WHERE id='$id'";
$result=db_query($connect,$sql);
$rows=db_fetch_array($result, MYSQLI_ASSOC);

?>

<!--PAGE CONTENT -->
        <div id="content">
             
            <div class="inner" style="min-height: 700px;">
<!--END BLOCK SECTION -->
 <!-- CHART & CHAT  SECTION -->
				 <div class="row">
				 <div class="col-lg-12">
                    <div class="bg-white rounded-lg shadow-md border border-gray-200">
                            <div class="bg-gray-50 px-6 py-4 border-b border-gray-200 rounded-t-lg flex justify-between items-center">
                               <h3 class="text-lg font-semibold text-gray-800"></h3>
                               <button onclick="history.back()" class="bg-blue-500 hover:bg-blue-600 text-white font-normal py-2 px-2 rounded-md transition-colors duration-150 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 flex items-center gap-2">
                                   <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                       <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path>
                                   </svg>
                                   Back
                               </button>
                            </div>
                        </div>
                        
                    </div>
				 <div class="col-lg-12 overflow-x-auto">
				 <div class="bg-white rounded-lg shadow-md border border-gray-200 mt-4">
				  <table class="min-w-full divide-y divide-gray-200">
      <tr class="border-b border-gray-200">
        <td class="px-6 py-4 whitespace-nowrap"><div class="element">
          <label class="block text-sm font-medium text-gray-700 mb-1">Account Name: </label>
          <span class="text-sm text-gray-900"><?php echo $rows['name']; ?></span></div></td>
        <td class="px-6 py-4 whitespace-nowrap"><div class="element">
          <label class="block text-sm font-medium text-gray-700 mb-1">Account Number: </label>
          <span class="text-sm text-gray-900"><?php echo $rows['accountnumber']; ?></span></div></td>
        <td class="px-6 py-4 whitespace-nowrap"><div class="element">
          <label class="block text-sm font-medium text-gray-700 mb-1">Available Balance:</label>
          <span class="text-sm text-gray-900"><?php echo $rows['currency']; ?><?php $availablebalance= $rows['availablebalance'];
									$number = number_format($availablebalance, 2); print $number ?></span></div ></td>
      </tr>
    </table>
				</div>
				  </div>
				  </div>
          
				   <div class="row">
                    <form action="" method="post">
                   <div class="col-lg-12">
                    <?php
include($user);
?>
                    <div class="bg-white rounded-lg shadow-md border border-gray-200 mt-4">
                            <div class="px-6 py-4 border-b border-gray-200 bg-gray-50">
                              <h3 class="text-lg font-medium text-gray-900">Request  |  Personal Key</h3>
                            </div>
                            <div class="p-6">
                                <div class="text-center">
       <p>You are sending: <strong><?php echo $rows['currency']; ?><?php $amount= $rows['amount'];
									$number = number_format($amount, 2); print $number ?></strong>. To <?php echo $rows['accountname']; ?> [<?php echo $rows['beneficiaryaccountnumber']; ?> ] <?php echo $rows['bankname']; ?>.<br />
    </div>
	<div class="text-center bg-yellow-100 border border-yellow-300 text-yellow-800 px-4 py-3 rounded-md">
       <p><strong>Code Required:</strong>.<br />
      Enter your "Personal Transaction Key"</p>
    </div>
	<div class="text-center">
			<div class="element mb-4">
             <label class="block text-sm font-medium text-gray-700 mb-3">Personal Transaction Key: <input type="password"  name="trans_code" id="trans_code"  placeholder="Personal Transaction Key" class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" required=""/>
			 <input name="id" type="hidden" value="<?php echo $rows['id']; ?>"/>
			 </label></div>
			  			<div class="element">
	<button type="submit" class="inline-flex items-center px-4 py-2 bg-gray-100 border border-gray-300 rounded-md font-medium text-gray-700 hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500 mr-2" name="trans2" >Submit Code</button>
				<button type="reset" class="inline-flex items-center px-4 py-2 bg-gray-100 border border-gray-300 rounded-md font-medium text-gray-700 hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500" name="reset">Clear</button></div>

</div>
                            </div>
                        </div>
                    </div>
                     
                </div>
				</form>
                 <!--END STACKING CHART SCETION  -->

                
            </div>

        </div>
        <!--END PAGE CONTENT -->

         <!-- RIGHT STRIP  SECTION -->
        <div id="right">

         <br /><br />
            <div class="bg-gray-100 rounded-lg p-4 border border-gray-200">
               <img src="assets/img/ad.png" />
            </div>
         
        </div>
         <!-- END RIGHT STRIP  SECTION -->
    </div>

    <!--END MAIN WRAPPER -->

                   <?php
include('footer.php')

?>