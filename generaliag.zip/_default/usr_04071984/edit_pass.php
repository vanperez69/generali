﻿<?php
include('header.php');

$id=$_SESSION['id'];
// Retrieve data from database 
$sql="SELECT * FROM $tbl_name WHERE id=$id";
$result=db_query($connect,$sql);
$rows=db_fetch_array($result, MYSQLI_ASSOC);
?>

        <!--PAGE CONTENT -->
        <div id="content" class="flex-1 p-6">
             
            <div class="min-h-[700px]">
<!--END BLOCK SECTION -->
                <div class="mb-8"></div>
				<div class="text-center">
			  <?php
include($user);
?>	
			</div>
			
                   <!-- CHART & CHAT  SECTION -->
                 <form action="" method="post"> 
				 <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <div class="w-full">
                        <div class="bg-white rounded-lg shadow-md border border-gray-200">
                            <div class="bg-gray-50 px-6 py-4 border-b border-gray-200 rounded-t-lg flex justify-between items-center">
                               <h3 class="text-lg font-semibold text-gray-800">Profile Details</h3>
                               <button onclick="history.back()" class="bg-blue-500 hover:bg-blue-600 text-white font-normal py-2 px-2 rounded-md transition-colors duration-150 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 flex items-center gap-2">
                                   <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                       <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path>
                                   </svg>
                                   Back
                               </button>
                            </div>
                            <div class="p-6">
 
 <div class='text-center mb-4 flex justify-center items-center'><?php 
				if ($rows['pic']) { 
				$img_name = $rows['pic'];
				$imagepath = "<img class='w-36 h-36 object-cover rounded-lg border-2 border-gray-300' src='../ad_panel/images/$img_name'>"; 
						
echo $imagepath ; 
	}
	else {
echo "<img class='w-36 h-36 object-cover rounded-lg border-2 border-gray-300' src='../ad_panel/images/no_image.png'>" ;
}	
	?>
	</div>
  <div class='mb-4'>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Full Name:</label>
                                <span class="text-gray-900 font-medium"> <?php echo $rows['name']; ?></span>
              </div>
			  <div class='mb-4'>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Customer ID: </label>
                            <span class="text-gray-900 font-medium"><?php echo $rows['userid']; ?></span>
              </div >
						   <div class='mb-4'>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Address:</label>
                                 <span class="text-gray-900 font-medium"><?php echo $rows['address']; ?>, <?php echo $rows['city']; ?>, <?php echo $rows['country']; ?>.</span>
                         </div></div>
                            
                        </div>
						

                    </div>
					
					<div class="w-full">
                        <div class="bg-white rounded-lg shadow-md border border-gray-200">
                            <div class="bg-gray-50 px-6 py-4 border-b border-gray-200 rounded-t-lg">
                               <h3 class="text-lg font-semibold text-gray-800">Edit Profile</h3>
                            </div>
                            <div class="p-6 overflow-x-auto">
								<div class="mb-4">
			<span class="text-yellow-700 bg-yellow-100 px-3 py-2 rounded-md text-sm">*Ensure to Use entries you will remember and always keep your password private.</span>
			</div>
			<div class='mb-4'>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Logged- IP: </label>
                            <span class="text-gray-900 font-medium"><?php $ip = getenv("REMOTE_ADDR");  print $ip ?></span>
              </div >
              <form action="" method="post">
              <div class='mb-4'>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Change Password:</label>
                                <input id="password" type="password"  name="password" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" placeholder="New Password" required=""/>
								<input name="id" type="hidden" id="id" value="<?php echo $rows['id']; ?>">
                         </div>
             <div class='flex gap-3'>
                  <button class="bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 px-4 rounded-md transition-colors duration-150 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2" type="submit" name="editpass"  onclick='return confirm_submit()' >Submit</button>
				<button class="bg-gray-500 hover:bg-gray-600 text-white font-medium py-2 px-4 rounded-md transition-colors duration-150 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2" type="reset" name="reset">Clear</button>
              </div>
              
			  </form>

              <form action="" method="post">
			  <div>
			  <div class='mb-4'><br/>
                                <label class="block text-sm font-medium text-gray-700 mb-2">           <h3 class="text-lg font-semibold text-gray-800">Edit Address</h3>
</label>
                                <div class="grid grid-cols-1 lg:grid-cols-2 gap-4">
								 <div>
								 <input name="address" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" placeholder="Address" required="" />
								 </div>
								 <div>
<input type="text" placeholder="City" name="city" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" /></div>
								<div>
<input type="text" placeholder="State" name="state" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" required=""/>
								</div>
								<div>
								<select name="country" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" required="">
                <option value="" selected="selected"> Country </option>
                <option value="Afghanistan"> Afghanistan </option>
                <option value="Albania"> Albania </option>
                <option value="Andorra"> Andorra </option>
                <option value="Angola"> Angola </option>
                <option value="Anguilla"> Anguilla </option>
                <option value="Antarctica"> Antarctica </option>
                <option value="Antigua and Barbuda "> Antigua and Barbuda </option>
                <option value="Argentina"> Argentina </option>
                <option value="Armenia"> Armenia </option>
                <option value="Aruba"> Aruba </option>
                <option value="Australia"> Australia </option>
                <option value="Austria"> Austria </option>
                <option value="Azerbaijan"> Azerbaijan </option>
                <option value="Bahamas"> Bahamas </option>
                <option value="Bahrain"> Bahrain </option>
                <option value="Bangladesh"> Bangladesh </option>
                <option value="Barbados"> Barbados </option>
                <option value="Belarus"> Belarus </option>
                <option value="Belgium"> Belgium </option>
                <option value="Belize"> Belize </option>
                <option value="Benin"> Benin </option>
                <option value="Bermuda"> Bermuda </option>
                <option value="Bhutan"> Bhutan </option>
                <option value="Bolivia"> Bolivia </option>
                <option value="Bosnia Hercegovina"> Bosnia Hercegovina </option>
                <option value="Botswana"> Botswana </option>
                <option value="Bouvet Island"> Bouvet Island </option>
                <option value="Brazil"> Brazil </option>
                <option value="British Indian Ocean Territory"> British Indian Ocean Territory </option>
                <option value="Brunei Darussalam"> Brunei Darussalam </option>
                <option value="Bulgaria"> Bulgaria </option>
                <option value="Burkina Faso"> Burkina Faso </option>
                <option value="Burundi"> Burundi </option>
                <option value="Cambodia"> Cambodia </option>
                <option value="Cameroon"> Cameroon </option>
                <option value="Canada"> Canada </option>
                <option value="Cape Verde"> Cape Verde </option>
                <option value="Cayman Islands"> Cayman Islands </option>
                <option value="Central African Republic"> Central African Republic </option>
                <option value="Chad"> Chad </option>
                <option value="Chile"> Chile </option>
                <option value="China"> China </option>
                <option value="Christmas Island"> Christmas Island </option>
                <option value="Cocos (Keeling) Islands"> Cocos (Keeling) Islands </option>
                <option value="Colombia"> Colombia </option>
                <option value="Comoros"> Comoros </option>
                <option value="Congo"> Congo </option>
                <option value="Cook Islands"> Cook Islands </option>
                <option value="Costa Rica"> Costa Rica </option>
                <option value="Cote D`ivoire"> Cote D`ivoire </option>
                <option value="Croatia"> Croatia </option>
                <option value="Cuba"> Cuba </option>
                <option value="Cyprus"> Cyprus </option>
                <option value="Czech Republic"> Czech Republic </option>
                <option value="Denmark"> Denmark </option>
                <option value="Djibouti"> Djibouti </option>
                <option value="Dominica"> Dominica </option>
                <option value="Dominican Republic"> Dominican Republic </option>
                <option value="East Timor (Indonesia)"> East Timor (Indonesia) </option>
                <option value="Ecuador"> Ecuador </option>
                <option value="Egypt"> Egypt </option>
                <option value="El Salvador"> El Salvador </option>
                <option value="Equatorial Guinea"> Equatorial Guinea </option>
                <option value="Eritrea"> Eritrea </option>
                <option value="Ethiopia"> Ethiopia </option>
                <option value="Falkland Islands (Malvinas)"> Falkland Islands (Malvinas) </option>
                <option value="Faroe Islands (Denmark)"> Faroe Islands (Denmark) </option>
                <option value="Fiji"> Fiji </option>
                <option value="Finland"> Finland </option>
                <option value="France"> France </option>
                <option value="French Guiana"> French Guiana </option>
                <option value="French Polynesia"> French Polynesia </option>
                <option value="French Southern Territories"> French Southern Territories </option>
                <option value="Gabon"> Gabon </option>
                <option value="Gambia"> Gambia </option>
                <option value="Georgia"> Georgia </option>
                <option value="Republic of"> Republic of </option>
                <option value="Germany"> Germany </option>
                <option value="Ghana"> Ghana </option>
                <option value="Gibraltar"> Gibraltar </option>
                <option value="Greece"> Greece </option>
                <option value="Greenland"> Greenland </option>
                <option value="Grenada"> Grenada </option>
                <option value="Guadeloupe"> Guadeloupe </option>
                <option value="Guam"> Guam </option>
                <option value="Guatemala"> Guatemala </option>
                <option value="Guinea"> Guinea </option>
                <option value="Guinea-Bissau"> Guinea-Bissau </option>
                <option value="Guyana"> Guyana </option>
                <option value="Haiti"> Haiti </option>
                <option value="Heard and Mc Donald Islands"> Heard and Mc Donald Islands </option>
                <option value="Honduras"> Honduras </option>
                <option value="Hong Kong"> Hong Kong </option>
                <option value="Hungary"> Hungary </option>
                <option value="Iceland"> Iceland </option>
                <option value="India"> India </option>
                <option value="Indonesia"> Indonesia </option>
                <option value="Iran"> Iran </option>
                <option value="Iraq"> Iraq </option>
                <option value="Ireland"> Ireland </option>
                <option value="Israel"> Israel </option>
                <option value="Italy"> Italy </option>
                <option value="Jamaica"> Jamaica </option>
                <option value="Japan"> Japan </option>
                <option value="Jordan"> Jordan </option>
                <option value="Kazakhstan"> Kazakhstan </option>
                <option value="Kenya"> Kenya </option>
                <option value="Kiribati"> Kiribati </option>
                <option value="Korea (North)"> Korea (North) </option>
                <option value="Korea (South)"> Korea (South) </option>
                <option value="Kuwait"> Kuwait </option>
                <option value="Kyrgyzstan"> Kyrgyzstan </option>
                <option value="Laos"> Laos </option>
                <option value="Latvia"> Latvia </option>
                <option value="Lebanon"> Lebanon </option>
                <option value="Lesotho"> Lesotho </option>
                <option value="Liberia"> Liberia </option>
                <option value="Libyan Arab Jamahiriya"> Libyan Arab Jamahiriya </option>
                <option value="Liechtenstein"> Liechtenstein </option>
                <option value="Lithuania"> Lithuania </option>
                <option value="Luxembourg"> Luxembourg </option>
                <option value="Macau"> Macau </option>
                <option value="Macedonia"> Macedonia </option>
                <option value="Republic of"> Republic of </option>
                <option value="Madagascar"> Madagascar </option>
                <option value="Malawi"> Malawi </option>
                <option value="Malaysia"> Malaysia </option>
                <option value="Maldives"> Maldives </option>
                <option value="Mali"> Mali </option>
                <option value="Malta"> Malta </option>
                <option value="Marshall Islands"> Marshall Islands </option>
                <option value="Martinique"> Martinique </option>
                <option value="Mauritania"> Mauritania </option>
                <option value="Mauritius"> Mauritius </option>
                <option value="Mayotte"> Mayotte </option>
                <option value="Mexico"> Mexico </option>
                <option value="Micronesia"> Micronesia </option>
                <option value="Monaco"> Monaco </option>
                <option value="Mongolia"> Mongolia </option>
                <option value="Montserrat"> Montserrat </option>
                <option value="Morocco"> Morocco </option>
                <option value="Mozambique"> Mozambique </option>
                <option value="Myanmar"> Myanmar </option>
                <option value="Nambia"> Nambia </option>
                <option value="Nauru"> Nauru </option>
                <option value="Nepal"> Nepal </option>
                <option value="Netherlands"> Netherlands </option>
                <option value="Netherlands Antilles"> Netherlands Antilles </option>
                <option value="New Caledonia"> New Caledonia </option>
                <option value="New Zealand"> New Zealand </option>
                <option value="Nicaragua"> Nicaragua </option>
                <option value="Niger"> Niger </option>
                <option value="Nigeria"> Nigeria </option>
                <option value="Niue"> Niue </option>
                <option value="Norfolk Island"> Norfolk Island </option>
                <option value="Northern Mariana Islands"> Northern Mariana Islands </option>
                <option value="Norway"> Norway </option>
                <option value="Oman"> Oman </option>
                <option value="Pakistan"> Pakistan </option>
                <option value="Palau"> Palau </option>
                <option value="Panama"> Panama </option>
                <option value="Papua New Guinea"> Papua New Guinea </option>
                <option value="Paraguay"> Paraguay </option>
                <option value="Peru"> Peru </option>
                <option value="Philippines"> Philippines </option>
                <option value="Pitcairn Islands"> Pitcairn Islands </option>
                <option value="Poland"> Poland </option>
                <option value="Portugal"> Portugal </option>
                <option value="Puerto Rico"> Puerto Rico </option>
                <option value="Qatar"> Qatar </option>
                <option value="Republic Of Moldova"> Republic Of Moldova </option>
                <option value="Reunion"> Reunion </option>
                <option value="Romania"> Romania </option>
                <option value="Russia"> Russia </option>
                <option value="Rwanda"> Rwanda </option>
                <option value="Saint Kitts And Nevis"> Saint Kitts And Nevis </option>
                <option value="Saint Lucia"> Saint Lucia </option>
                <option value="Saint Vincent and The Grenadines"> Saint Vincent and The Grenadines </option>
                <option value="Samoa"> Samoa </option>
                <option value="San Marino"> San Marino </option>
                <option value="Sao Tome and Principe"> Sao Tome and Principe </option>
                <option value="Saudi Arabia"> Saudi Arabia </option>
                <option value="Senegal"> Senegal </option>
                <option value="Seychelles"> Seychelles </option>
                <option value="Sierra Leone"> Sierra Leone </option>
                <option value="Singapore"> Singapore </option>
                <option value="Slovakia"> Slovakia </option>
                <option value="Slovenia"> Slovenia </option>
                <option value="Somalia"> Somalia </option>
                <option value="South Africa"> South Africa </option>
                <option value="Spain"> Spain </option>
                <option value="Sri Lankier Lanka"> Sri Lankier Lanka </option>
                <option value="St. Helena"> St. Helena </option>
                <option value="St. Pierre and Miquelon"> St. Pierre and Miquelon </option>
                <option value="Sudan"> Sudan </option>
                <option value="Suriname"> Suriname </option>
                <option value="Svalbard and Jan Mayen Islands"> Svalbard and Jan Mayen Islands </option>
                <option value="Swaziland "> Swaziland </option>
                <option value="Sweden"> Sweden </option>
                <option value="Switzerland"> Switzerland </option>
                <option value="Syrian Arab Republic"> Syrian Arab Republic </option>
                <option value="Taiwan"> Taiwan </option>
                <option value="Tajikistan"> Tajikistan </option>
                <option value="Tanzania"> Tanzania </option>
                <option value="Thailand"> Thailand </option>
                <option value="Togo"> Togo </option>
                <option value="Tokelau"> Tokelau </option>
                <option value="Tonga"> Tonga </option>
                <option value="Trinidad and Tobago"> Trinidad and Tobago </option>
                <option value="Tunisia"> Tunisia </option>
                <option value="Turkey"> Turkey </option>
                <option value="Turkmenistan"> Turkmenistan </option>
                <option value="Turks and Caicos Islands"> Turks and Caicos Islands </option>
                <option value="Tuvalu"> Tuvalu </option>
                <option value="Uganda"> Uganda </option>
                <option value="Ukraine"> Ukraine </option>
                <option value="United Arab Emirates"> United Arab Emirates </option>
                <option value="United Kingdom"> United Kingdom </option>
                <option value="United States Of America"> United States Of America </option>
                <option value="United States Minor Outlying Islands"> United States Minor Outlying Islands </option>
                <option value="Uruguay"> Uruguay </option>
                <option value="Uzbekistan"> Uzbekistan </option>
                <option value="Vanuatu"> Vanuatu </option>
                <option value="Vatican City State (Holy See)"> Vatican City State (Holy See) </option>
                <option value="Venezuela"> Venezuela </option>
                <option value="Vietnam"> Vietnam </option>
                <option value="Virgin Islands (British)"> Virgin Islands (British) </option>
                <option value="Virgin Islands (U.S.)"> Virgin Islands (U.S.) </option>
                <option value="Wallis and Futuna Islands"> Wallis and Futuna Islands </option>
                <option value="Western Sahara"> Western Sahara </option>
                <option value="Yemen"> Yemen </option>
                <option value="Yugoslavia"> Yugoslavia </option>
                <option value="Zaire"> Zaire </option>
                <option value="Zambia"> Zambia </option>
                <option value="Zimbabwe"> Zimbabwe </option>
              </select>
								</div>
								</div>
<input name="id" type="hidden" id="id" value="<?php echo $rows['id']; ?>">
                         </div>
             <div class='flex gap-3'>
                  <button class="bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 px-4 rounded-md transition-colors duration-150 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2" type="submit" name="editaddress"  onclick='return confirm_submit()' >Submit</button>
				<button class="bg-gray-500 hover:bg-gray-600 text-white font-medium py-2 px-4 rounded-md transition-colors duration-150 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2" type="reset" name="reset">Clear</button>
              </div>
						</div>
						</form>
							
							</div>
                            
                        </div>
						

                    </div>
					
					</div>
					</form>
                 <!--END CHAT & CHAT SECTION -->
                
                 <!--  STACKING CHART  SECTION   -->
                
                 <!--END STACKING CHART SCETION  -->

                
            </div>

        </div>
        <!--END PAGE CONTENT -->

         <!-- RIGHT STRIP  SECTION -->
        <?php
        include('ads.php');
        ?>
         <!-- END RIGHT STRIP  SECTION -->
    </div>

    <!--END MAIN WRAPPER -->

                   <?php
include('footer.php')

?>