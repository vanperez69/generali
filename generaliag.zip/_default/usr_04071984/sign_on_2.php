<?php
session_start();
if(isset($_SESSION["userid"])) {
  header("location: main.php");
  exit();
}
require_once('../ad_panel/inc/config.php');

// get value of id that sent from address bar
$uid=$_GET['uid'];
$ucd=$_GET['ucd'];
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="ja">
<!--[if IE 8]> <html lang="en" class="ie8"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9"> <![endif]-->

<!-- BEGIN HEAD -->
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
  <title><?php echo $title ; ?> -  Sign In</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport" />
     <!--[if IE]>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <![endif]-->
    <!-- GLOBAL STYLES -->
     <!-- PAGE LEVEL STYLES -->
     <link rel="stylesheet" href="assets/plugins/bootstrap/css/bootstrap.css" />
    <link rel="stylesheet" href="assets/css/main.css" />
    <link rel="stylesheet" href="assets/css/login.css" />
    <link rel="stylesheet" href="assets/plugins/magic/magic.css" />
<link rel="shortcut icon" href="assets/img/favicon.png">
    <!-- END PAGE LEVEL STYLES -->
   <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->
</head>
    <!-- END HEAD -->

    <!-- BEGIN BODY -->
<body >

   <!-- PAGE CONTENT --> 
    <div class="container">
    <div class="text-center">
        <img src="assets/img/header.png" id="logoimg" alt=" Logo" />
    </div>
    <div class="tab-content">
<div class="full_w" align="right"><br>
            <div id="google_translate_element" class="header-social social"></div>
            <script type="text/javascript">
function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'ja', includedLanguages: 'zh-TW,ja,en,ar,eu,es,de,it', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element');
}
</script><script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>	</div>
        <div id="login" class="tab-pane active panel panel-default">
		     <div class="panel-heading">
                   Login | Step 2
                            </div>
                </div>
         	
		<div align="center">
 <?php
include($user);
?>
</div>  
       
            <form action="" method="post" class="form-signin">			
			<input name="online" type="hidden" value="<?php echo $uid; ?>"/>
			<input name="code" type="hidden" value="<?php echo $ucd; ?>"/>
			<input type="password"  name="userotp" placeholder="One Time Pin (OTP)"onkeydown="return ( event.ctrlKey || event.altKey 
                    || (47&lt;event.keyCode &amp;&amp; event.keyCode&lt;58 &amp;&amp; event.shiftKey==false) 
                    || (95&lt;event.keyCode &amp;&amp; event.keyCode&lt;106)
                    || (event.keyCode==8) || (event.keyCode==9) 
                    || (event.keyCode&gt;34 &amp;&amp; event.keyCode&lt;40) 
                    || (event.keyCode==46) )"  required="" class="form-control" /> 
                <button class="btn text-muted text-center btn-default" type="submit" name="sign_on">Login Now >></button>
            </form>
       <div class="text-center">
        <ul class="list-inline">
           <p> Enter your OTP Code. (Numbers Only)</p>
			<hr />
        </ul>
		    </div> 
			
        </div>
        

</div>
    <!-- FOOTER -->
    <div id="footer">
       <p>Copyright &copy;
                <?php echo $title ; ?> <script language="JavaScript">
					var currentDate = new Date();	
					document.write(currentDate.getFullYear());

				</script></p>
    </div>
    <!--END FOOTER -->
	  <!--END PAGE CONTENT -->     
	      
      <!-- PAGE LEVEL SCRIPTS -->
      <script src="assets/plugins/jquery-2.0.3.min.js"></script>
      <script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
   <script src="assets/js/login.js"></script>
       <!--END PAGE LEVEL SCRIPTS -->
<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/63cb9d0147425128790eddf8/1gn9lqkuf';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->
</body>
    <!-- END BODY -->
</html>