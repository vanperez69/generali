﻿<?php
include('header.php');
//------Submit Data from Transfer Page-----
$id=$_POST['id'];

$sql="SELECT * FROM $tbl_name WHERE id='$id'";
$result=db_query($connect,$sql);
$rows=db_fetch_array($result, MYSQLI_ASSOC);

$balance=$rows['availablebalance'];
$bankname=$_POST['bankname'];
$bankbranch=$_POST['bankbranch'];
$iban=$_POST['iban'];
$swift=$_POST['swift'];
$accountname=$_POST['accountname'];
$beneficiaryaccountnumber=$_POST['beneficiaryaccountnumber'];
$amount=$_POST['amount'];
$name=$_POST['name'];
$t_type='Online Transfer';
$t_description='Online Transfer Initiated from your account.' ;
$debit=$_POST["amount"];
$currency=$rows['currency'];
$phone=$rows['phone'];

$p_amount = number_format($amount, 2);
$av_balance = number_format($balance, 2);
$ip =$_SERVER['REMOTE_ADDR'];
$time = date ('j M, Y.  H:ia');

$subject = "New Mail | $title";
$user_email="".$_SESSION['email']."";
?>
<!--PAGE CONTENT -->
        <div id="content">
             
            <div class="inner" style="min-height: 700px;">
<!--END BLOCK SECTION -->
                <br /> <br /> <!-- CHART & CHAT  SECTION -->
				 <div class="row">
				 <div class="col-lg-12">
                    <div class="bg-white rounded-lg shadow-md border border-gray-200">
                            <div class="bg-gray-50 px-6 py-4 border-b border-gray-200 rounded-t-lg flex justify-between items-center">
                               <h3 class="text-lg font-semibold text-gray-800"></h3>
                               <button onclick="history.back()" class="bg-blue-500 hover:bg-blue-600 text-white font-normal py-2 px-2 rounded-md transition-colors duration-150 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 flex items-center gap-2">
                                   <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                       <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path>
                                   </svg>
                                   Back
                               </button>
                            </div>
                        </div>
                    </div>
				 <div class="col-lg-12 overflow-x-auto">
				 <div class="bg-white rounded-lg shadow-md border border-gray-200 mt-4">
				  <table class="min-w-full divide-y divide-gray-200">
      <tr class="border-b border-gray-200">
        <td class="px-6 py-4 whitespace-nowrap"><div class="element">
          <label class="block text-sm font-medium text-gray-700 mb-1">Account Name: </label>
          <span class="text-sm text-gray-900"><?php echo $rows['name']; ?></span></div></td>
        <td class="px-6 py-4 whitespace-nowrap"><div class="element">
          <label class="block text-sm font-medium text-gray-700 mb-1">Account Number: </label>
          <span class="text-sm text-gray-900"><?php echo $rows['accountnumber']; ?></span></div></td>
        <td class="px-6 py-4 whitespace-nowrap"><div class="element">
          <label class="block text-sm font-medium text-gray-700 mb-1">Available Balance:</label>
          <span class="text-sm text-gray-900"><?php echo $rows['currency']; ?><?php $availablebalance= $rows['availablebalance'];
									$number = number_format($availablebalance, 2); print $number ?></span></div ></td>
      </tr>
    </table>
				</div>
				  </div>
				  </div>
				   <div class="row">
                    <div class="col-lg-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                             Confirmed  |  Redirecting...
                            </div>
                            <div class="panel-body">
                                  <div class="table-responsive">
                                  <div align="center">
    <?php
	if($rows['availablebalance']  < $amount){
//------Show Error-----
echo "<div class='btn-danger''> <p>You have Insufficient Balance to complete this Request!</p></br>
 You are attempting to send: <strong>$currency$p_amount</strong>.</br></br>
<div class='btn btn-default'> <a href='javascript:history.back(1)'>Click To Go Back</a></div></br></br></div>";
}else{

$exec1 = db_query($connect,"UPDATE $tbl_name SET bankname='$bankname', bankbranch='$bankbranch', iban='$iban', swift='$swift', accountname='$accountname', beneficiaryaccountnumber='$beneficiaryaccountnumber', amount='$amount'
WHERE id='$id'");
$body = "
<p>Dear ".$_SESSION['name'].",<br>
<br>
Transaction started from <strong>$ip</strong><br>
Sending: <strong>$currency$p_amount</strong><br>
Available Balance: <strong>$currency$av_balance</strong><br>
To: <strong>$accountname</strong><br>
Transaction Date: <strong>$time</strong></p>
<br>
<p>This is a <strong>Transaction Notification</strong> message.<br>
You received this mandatory email notification to update you about activities in your account.<br>
Please contact your account officer for any further inquiries.</p><br>

<p><strong><em>Note:</em></strong> Do not reply to this email, this is an automated notification.</p><br>
<br>
<p>Thank You,<br>
<strong>Customer Care.</strong></p>
";

// mail to client
			$header = "Reply-To: $site_email\r\n";
			$header .= "Return-Path: $site_email\r\n";
			$header .= "From: Customer Care <$site_email>\r\n";
			$header .= "Content-Type: text/html; charset=iso-8859-1\n";
			//mail($user_email,$subject,$body,$header);
//Mail End



$exec2 = db_query($connect,"INSERT INTO $trans (id, name, date, t_type, t_description, debit, balance, currency)
VALUES
('$id','$name',NOW(),'$t_type','$t_description','$debit','$balance','$currency')");

//------Redirect to loading page-----
echo "<div class='btn-success'>
    <p>You are sending: <strong>$currency$p_amount</strong>. To $accountname [$beneficiaryaccountnumber] at $bankname.</p></br>
      Please select an option to continue request...</br></br>
	  <div class='btn btn-default'><a href='javascript:history.back(1)'>Click To Go Back</a></div>  <div class='btn btn-default'><a href='initiate_1.php'>Confirm Request</a></div></br></br>
    </div>";

}
	?>
    </div>
								    
									</div>  </div>
                            
                        </div>
						

                    </div>
					
					</div>
					</form>
                 <!--END CHAT & CHAT SECTION -->
                
                 <!--  STACKING CHART  SECTION   -->
                
                 <!--END STACKING CHART SCETION  -->

                
            </div>

        </div>
        <!--END PAGE CONTENT -->

         <!-- RIGHT STRIP  SECTION -->
        <div id="right">

         <br /><br />
            <div class="well well-small">
               <img src="assets/img/ad.png" />
            </div>
         
        </div>
         <!-- END RIGHT STRIP  SECTION -->
    </div>

    <!--END MAIN WRAPPER -->

                   <?php
include('footer.php')

?>