<?php
session_start();
if(isset($_SESSION["userid"])) {
  header("location: main.php");
  exit();
}
require_once('../ad_panel/inc/config.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <title><?php echo $title ; ?> - Sign In</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
    primary: '#2E4F3E',   // Burnt Green
    secondary: '#8B2E2E', // Burnt Red
    accent: '#A64242'     // Rusty Red (accent tone)
}

                }
            }
        }
    </script>
    
    <link rel="shortcut icon" href="assets/img/favicon.png">
</head>

<body class="bg-gray-50 min-h-screen">
    <!-- PAGE CONTENT --> 
    <div class="container mx-auto px-4 py-8 max-w-md">
        <!-- Logo Section -->
        <div class="text-center mb-8">
            <a href="../../" class="inline-block"><img src="assets/img/header.png" id="logoimg" alt="Logo" class="mx-auto h-16" /></a>
        </div>
        
        
        <!-- Login Panel -->
        <div id="login" class="bg-white rounded-lg shadow-lg overflow-hidden">
            <!-- Panel Header -->
            <div class="bg-gradient-to-br from-red-500 to-red-600 px-6 py-4">
                <h2 class="text-white text-lg font-semibold text-center">Login</h2>
            </div>
            
            <!-- Panel Body -->
            <div class="p-6">
                <!-- User Include -->
                <div class="text-center mb-6">
                    <?php include($user); ?>
                </div>
                
                <!-- Login Form -->
                <form action="" method="post" class="space-y-4">
                    <div>
                        <input 
                            type="text" 
                            name="online" 
                            autocomplete="off" 
                            placeholder="Customer ID: " 
                            class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent transition duration-200 ease-in-out" 
                        />
                    </div>
                    <div>
                        <input 
                            type="password" 
                            name="code" 
                            autocomplete="off" 
                            placeholder="Password" 
                            class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent transition duration-200 ease-in-out" 
                        />
                    </div>
                    <button 
                        class="w-full bg-secondary hover:bg-red-700 text-white font-medium py-3 px-4 rounded-lg transition duration-200 ease-in-out transform hover:scale-105" 
                        type="submit" 
                        name="index"
                    >
                        Continue >>
                    </button>
                </form>
                
                <!-- Additional Links and Info -->
                <div class="text-center mt-6 space-y-4">
                    <div class="flex flex-col sm:flex-row items-center justify-center gap-2 text-sm text-gray-600">
                        <span>Not a registered user?</span>
                        <a href="sign_up.php" class="text-primary hover:text-blue-700 font-medium underline">
                            Click Here To Register
                        </a>
                    </div>
                    
                    <hr class="border-gray-200 my-4" />
                    
                    <div class="text-sm text-gray-600 space-y-2">
                        <p><strong class="text-gray-800">Protect yourself from fraud</strong></p>
                        <p>* We use cookies to deliver you a secure and efficient service.</p>
                        <p>* Always log out of your account after you have finished.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- FOOTER -->
    <div id="footer" class="text-center py-6 text-gray-500 text-sm">
        <p>Copyright &copy; <?php echo $title ; ?> 
            <script language="JavaScript">
                var currentDate = new Date();	
                document.write(currentDate.getFullYear());
            </script>
        </p>
    </div>
    
    <!-- PAGE LEVEL SCRIPTS -->
      
    <!--Start of Tawk.to Script-->
    <script type="text/javascript">
        var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
        (function(){
            var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
            s1.async=true;
            s1.src='https://embed.tawk.to/63cb9d0147425128790eddf8/1gn9lqkuf';
            s1.charset='UTF-8';
            s1.setAttribute('crossorigin','*');
            s0.parentNode.insertBefore(s1,s0);
        })();
    </script>
    <!--End of Tawk.to Script-->
</body>
</html>