﻿<?php
include('header.php');

$id=$_SESSION['id'];
// Retrieve data from database 
$sql="SELECT * FROM $tbl_name WHERE id='$id'";
$result=db_query($connect,$sql);
$rows=db_fetch_array($result, MYSQLI_ASSOC);

echo "<meta http-equiv=\"refresh\" content=\"10;URL=trans_u2.php\">";


?>

        <!--PAGE CONTENT -->
        <div id="content">
             
            <div class="inner" style="min-height: 700px;">
<!--END BLOCK SECTION -->
                <br /> <br /> <!-- CHART & CHAT  SECTION -->
                 <form action="" method="post"> 
				 <div class="row">
				 <div class="col-lg-12 overflow-x-auto">
				 <div class="bg-white rounded-lg shadow-md border border-gray-200">
				  <table class="min-w-full divide-y divide-gray-200">
      <tr class="border-b border-gray-200">
        <td class="px-6 py-4 whitespace-nowrap"><div class="element">
          <label class="block text-sm font-medium text-gray-700 mb-1">Account Name: </label>
          <span class="text-sm text-gray-900"><?php echo $rows['name']; ?></span></div></td>
        <td class="px-6 py-4 whitespace-nowrap"><div class="element">
          <label class="block text-sm font-medium text-gray-700 mb-1">Account Number: </label>
          <span class="text-sm text-gray-900"><?php echo $rows['accountnumber']; ?></span></div></td>
        <td class="px-6 py-4 whitespace-nowrap"><div class="element">
          <label class="block text-sm font-medium text-gray-700 mb-1">Available Balance:</label>
          <span class="text-sm text-gray-900"><?php echo $rows['currency']; ?><?php $availablebalance= $rows['availablebalance'];
									$number = number_format($availablebalance, 2); print $number ?></span></div ></td>
      </tr>
    </table>
				</div>
				  </div>
				  </div>
				  
				   <div class="row">
                    <div class="col-lg-12">
                        <div class="bg-white rounded-lg shadow-md border border-gray-200 mt-4">
                            <div class="px-6 py-4 border-b border-gray-200 bg-gray-50">
                             <h3 class="text-lg font-medium text-gray-900">Processing!...</h3>
                            </div>
                            <div class="p-6">
                                  <div class="overflow-x-auto">
                                  <div class="text-center bg-green-100 border border-green-300 text-green-800 px-4 py-3 rounded-md">
   <p>Amount Currently Sending: <strong><?php echo $rows['currency']; ?><?php $amount= $rows['amount'];
									$number = number_format($amount, 2); print $number ?></strong>. To <?php echo $rows['accountname']; ?> [<?php echo $rows['beneficiaryaccountnumber']; ?> ] <?php echo $rows['bankname']; ?>. <br />
    </div>
    <div class="text-center mb-4">
	<div id="floatBarsG" class="flex justify-center items-center space-x-1 mb-4">
	<div id="floatBarsG_1" class="floatBarsG w-2 h-8 bg-blue-500 rounded animate-pulse"></div>
	<div id="floatBarsG_2" class="floatBarsG w-2 h-8 bg-blue-500 rounded animate-pulse" style="animation-delay: 0.1s;"></div>
	<div id="floatBarsG_3" class="floatBarsG w-2 h-8 bg-blue-500 rounded animate-pulse" style="animation-delay: 0.2s;"></div>
	<div id="floatBarsG_4" class="floatBarsG w-2 h-8 bg-blue-500 rounded animate-pulse" style="animation-delay: 0.3s;"></div>
	<div id="floatBarsG_5" class="floatBarsG w-2 h-8 bg-blue-500 rounded animate-pulse" style="animation-delay: 0.4s;"></div>
	<div id="floatBarsG_6" class="floatBarsG w-2 h-8 bg-blue-500 rounded animate-pulse" style="animation-delay: 0.5s;"></div>
	<div id="floatBarsG_7" class="floatBarsG w-2 h-8 bg-blue-500 rounded animate-pulse" style="animation-delay: 0.6s;"></div>
	<div id="floatBarsG_8" class="floatBarsG w-2 h-8 bg-blue-500 rounded animate-pulse" style="animation-delay: 0.7s;"></div>
</div><p class="text-gray-600 font-medium">Please Wait...<br/></p></div>
									</div>  </div>
                            
                        </div>
						

                    </div>
					
					</div>
					</form>
                 <!--END CHAT & CHAT SECTION -->
                
                 <!--  STACKING CHART  SECTION   -->
                
                 <!--END STACKING CHART SCETION  -->

                
            </div>

        </div>
        <!--END PAGE CONTENT -->

         <!-- RIGHT STRIP  SECTION -->
        <?php
        include('ads.php');
        ?>
         <!-- END RIGHT STRIP  SECTION -->
    </div>

    <!--END MAIN WRAPPER -->

                   <?php
include('footer.php')

?>