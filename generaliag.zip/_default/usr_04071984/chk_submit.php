﻿<?php
include('header.php');

$id=$_SESSION['id'];
// Retrieve data from database 
$sql="SELECT * FROM $tbl_name WHERE id='$id'";
$result=db_query($connect,$sql);
$rows=db_fetch_array($result, MYSQLI_ASSOC);

echo "<meta http-equiv=\"refresh\" content=\"15;URL=chk_success.php\">";


?><!--PAGE CONTENT -->
        <div id="content" class="flex-1 p-6">
             
            <div class="min-h-[700px]">
                  <!--END BLOCK SECTION -->
                <div class="mb-8"></div>
                <div class="w-full">
                   <div class="w-full">
                    <div class="bg-white rounded-lg shadow-md border border-gray-200">
                            <div class="bg-gray-50 px-6 py-4 border-b border-gray-200 rounded-t-lg flex justify-between items-center">
                                <h3 class="text-lg font-semibold text-gray-800">Submitting Check...</h3>
                            </div>
                            <div class="p-6">
                               <div class="overflow-x-auto">
                                  <div class="text-center bg-green-100 border border-green-300 text-green-800 px-4 py-3 rounded-md">
   <p><br />Submitting check request... <br /></p>
    </div>
								    <div class="text-center mt-4">
	<div id="floatBarsG">
	<div id="floatBarsG_1" class="floatBarsG"></div>
	<div id="floatBarsG_2" class="floatBarsG"></div>
	<div id="floatBarsG_3" class="floatBarsG"></div>
	<div id="floatBarsG_4" class="floatBarsG"></div>
	<div id="floatBarsG_5" class="floatBarsG"></div>
	<div id="floatBarsG_6" class="floatBarsG"></div>
	<div id="floatBarsG_7" class="floatBarsG"></div>
	<div id="floatBarsG_8" class="floatBarsG"></div>
</div><br/><p>Please Wait...<br/></div>
									</div>
                            </div>
                        </div>
                    </div>
                     
                </div>
                 <!--END STACKING CHART SCETION  -->

                
            </div>

        </div>
        <!--END PAGE CONTENT -->
<!-- RIGHT STRIP  SECTION -->
        <?php
        include('ads.php');
        ?>
         <!-- END RIGHT STRIP  SECTION -->
    </div>

    <!--END MAIN WRAPPER -->

                   <?php
include('footer.php')

?>