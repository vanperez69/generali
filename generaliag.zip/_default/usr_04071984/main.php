﻿<?php
include('header.php');

$id=$_SESSION['id'];
// Retrieve data from database 
$sql="SELECT * FROM $tbl_name WHERE id=$id";
$result=db_query($connect,$sql);
$rows=db_fetch_array($result, MYSQLI_ASSOC);
?>

        <!--PAGE CONTENT -->
        <div id="content" class="flex-1 p-6">
             
            <div class="inner min-h-[700px] flex-1 p-6 max-w-4xl mx-auto">
                 <!--BLOCK SECTION -->
                 <div id="menu_icons">
                 <?php
include('menu_icon.php')

?>
                 </div>
                  <!--END BLOCK SECTION -->
                <hr class="border-gray-300 my-4" />
                   <!-- CHART & CHAT  SECTION -->
                 <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <div class="lg:col-span-1">
                        <div class="bg-white rounded-lg shadow-md border border-gray-200">
                            <div class="bg-gray-50 px-4 py-3 border-b border-gray-200 font-semibold text-gray-700">
                                Detailed Information
                            </div>
                            <div class="p-4">
                                  <div class="overflow-x-auto">
                                    <table class="w-full">
									<tr class="border-b border-gray-100">
      <td class="py-2"><strong class="text-gray-700">Customer ID:</strong> <span class="text-gray-900"><?php echo $rows['userid']; ?></span></td>
    </tr>
	   <tr class="border-b border-gray-100">
      <td class="py-2"><strong class="text-gray-700">Full Name:</strong> <span class="text-gray-900"><?php echo $rows['name']; ?></span></td>
    </tr>
	<!--
    <tr>
      <td><strong>Address: </strong><?php echo $rows['address']; ?>, <?php echo $rows['city']; ?>, <?php echo $rows['country']; ?></td>
    </tr> 
	-->
	<tr class="border-b border-gray-100">
      <td class="py-2"><strong class="text-gray-700">Phone Number: </strong><span class="text-gray-900"><?php echo $rows['phone']; ?></span></td>
    </tr>
	 <tr class="bg-green-50 border-b border-gray-100">
      <td class="py-2 font-semibold text-green-700">Acccount Details:</td>
    </tr>
    <tr class="border-b border-gray-100">
      <td class="py-2"><strong class="text-gray-700">Account Number:</strong> <span class="text-gray-900"><?php echo $rows['accountnumber']; ?></span></td>
    </tr>
     <tr class="border-b border-gray-100">
      <td class="py-2"><strong class="text-gray-700">Account Type:</strong> <span class="text-gray-900"><?php echo $rows['a_type']; ?></span></td>
    </tr>
    <tr class="border-b border-gray-100">
      <td class="py-2">
  <strong class="text-gray-700">Available Balance:</strong> 
  <span class="text-blue-800 text-2xl font-bold">
    <?php 
      echo $rows['currency']; 
      $availablebalance = $rows['availablebalance'];
      $number = number_format($availablebalance, 2); 
      print $number;
    ?>
  </span>
</td>

    </tr>
									</table>
									</div>
									 <?php if($rows['trans']  == 0){
echo "<div class='bg-green-100 border border-green-200 text-green-700 px-4 py-3 rounded text-center my-4'><p><strong>Notification</strong><br>
New Transactions are available on your account. Ensure to <a href='logout.php' class='text-green-800 underline hover:text-green-900'>Logout</a> at all times.<br>
</div>";
    }
 else if ($rows['trans']  == 1){
 echo "<div class='bg-green-100 border border-green-200 text-green-700 px-4 py-3 rounded text-center my-4'><p><strong>Notification</strong><br>
New Transactions are available on your account. Ensure to <a href='logout.php' class='text-green-800 underline hover:text-green-900'>Logout</a> at all times.
</div>";
    } 
	else if ($rows['trans']  == 2){
 echo "<div class='bg-red-100 border border-red-200 text-red-700 px-4 py-3 rounded text-center my-4'><p><strong>Notification</strong><br>
New Transactions have been disabled on your account. This is due to IP conflict and for security purpose.<br>
Please <a href='new_mssg.php' class='text-red-800 underline hover:text-red-900'>contact</a> your account officer for clarifications.</div>";
    }
	else if ($rows['trans']  == 3){
 echo "<div class='bg-green-100 border border-green-200 text-green-700 px-4 py-3 rounded text-center my-4'><p><strong>Notification</strong><br>
New Transactions are available on your account. Ensure to <a href='logout.php' class='text-green-800 underline hover:text-green-900'>Logout</a> at all times.
</div>";
    } ?>
                            </div>
                            
                        </div>
						

                    </div>
					<div class="lg:col-span-1">
                        <div class="bg-white rounded-lg shadow-md border border-gray-200">

<div class="overflow-x-auto">
<table class="w-full">
<tr class="border-b border-gray-100">
    <td class="py-2"><strong class="text-gray-700">Last Login:</strong> <span class="text-gray-900"><?php if($rows['lastlogin']  == null){
echo "First Time Login.";
    }
 else{
echo date ('j M, Y.  H:ia', strtotime ($rows['lastlogin']));
}?></span></td>
  </tr>
  </table>
</div>

                            <div class="p-4">
                              <div class="overflow-x-auto">

              		<div class="text-center">
					<table class="w-full">
                           <tr>
                             <td class="text-center align-top py-4"><?php 
				if ($_SESSION['pic']) { 
				$img_name = $_SESSION['pic'];
				$imagepath = "<img width='150' height='150' src='../ad_panel/images/$img_name' class='inline-block'>"; 
						
echo $imagepath ; 
	}
	else {
echo "<img width='150' height='150' src='../ad_panel/images/no_image.png' class='inline-block'>" ; 
}	
	?></td>
                           </tr>
						
                           
        </table></div>
              			 </div>
						<div class="overflow-x-auto">	
<table class="w-full">
 <tr class="bg-green-50 border-b border-gray-100">
      <td class="py-2 font-semibold text-green-700">Recent Deposit:</td>
    </tr>
  <tr class="border-b border-gray-100">
    <th class="py-2 text-left font-semibold text-gray-700"><strong>Depositor</strong></th>
    <th class="py-2 text-left font-semibold text-gray-700"><strong>Date</strong></th>
    <th class="py-2 text-left font-semibold text-gray-700"><strong>Amount</strong></th>
  </tr>
  <tr class="bg-yellow-50 border-b border-gray-100">
    <td class="py-2"><?php echo $rows['sender']; ?></td>
    <td class="py-2"><?php echo date ('j M, Y', strtotime ($rows['datesent'])); ?></td>
    <td class="py-2"> <?php echo $rows['currency']; ?><?php $credit= $rows['credit'];
									$number = number_format($credit, 2); print $number ?></td>
  </tr>
</table>

              			 </div>
                            </div>
                        </div>
						

                    </div>
					</div>
                 <!--END CHAT & CHAT SECTION -->
                
                 <!--  STACKING CHART  SECTION   -->
                <div class="grid grid-cols-1 gap-6">
                   <div class="col-span-1">
                    <div class="bg-white rounded-lg shadow-md border border-gray-200">
                            <div class="bg-gray-50 px-4 py-3 border-b border-gray-200 font-semibold text-gray-700">
                                Recent Entries
                            </div>
                            <div class="p-4">
                                <div class="overflow-x-auto">
                                    <?php
$id=$_SESSION['id'];
$sql="SELECT * FROM $trans WHERE id=$id ORDER BY date DESC LIMIT 3";
$result=db_query($connect,$sql);						
if (db_num_rows($result) == 0) {
	echo '<div class="text-center text-gray-500 my-4"> No Entries found.</div><br/>';
}
	else{

?>
		      <table class="w-full">
                <thead>
                  <tr class="bg-green-50 border-b border-gray-200">
				  <th class="py-2 text-left font-semibold text-green-700"><div class="text-left">Date</div></th>
                    <th class="py-2 text-left font-semibold text-green-700"><div class="text-left">Type </div></th>
					<th class="py-2 text-left font-semibold text-green-700"><div class="text-left">Description </div></th>
                    <th class="py-2 text-left font-semibold text-green-700"><div class="text-left">Amount</div></th>
					<th class="py-2 text-left font-semibold text-green-700"><div class="text-left">Leg.Bal.</div></th>
                  </tr>
                </thead>
<?php while($rows = db_fetch_array($result, MYSQLI_ASSOC ))

{
?>
                <tbody>
                  <tr class="bg-yellow-50 border-b border-gray-100">
				  <td class="py-2"><?php echo date ('j M, Y', strtotime ($rows['date'])); ?></td>
				   
				  <td class="py-2"><?php echo $rows['t_type']; ?></td>
				  <td class="py-2"><a href="trans_detail.php?id=<?php echo $rows['trans_id']; ?>" title="View Transaction" class="text-blue-600 hover:text-blue-800 underline"><?php echo $rows['t_description']; ?></a></td>
                    <td class="py-2"><?php echo $rows['currency']; ?><?php $debit= $rows['debit'];
									$number = number_format($debit, 2); print $number ?></td>
                  	<td class="py-2"><?php echo $rows['currency']; ?><?php $balance= $rows['balance'];
									$number = number_format($balance, 2); print $number ?></td>
					</tr>
                </tbody>
                <?php
}
}
?>

              </table>
			  <div class="text-right mt-4">
			  <div class="inline-block bg-gray-100 text-gray-600 text-center px-4 py-2 rounded border border-gray-300">
	<a href="view_transact.php" class="text-gray-700 hover:text-gray-900">View More</a></div></div>
                                </div>
                            </div>
                        </div>
                    </div>
                     
                </div>
                 <!--END STACKING CHART SCETION  -->

                
            </div>

        </div>
        <!--END PAGE CONTENT -->
 <!-- RIGHT STRIP  SECTION -->
        <?php
        include('ads.php');
        ?>
         <!-- END RIGHT STRIP  SECTION -->
    </div>

    <!--END MAIN WRAPPER -->

                   <?php
include('footer.php')

?>