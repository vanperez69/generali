﻿<?php
include('header.php');

$id=$_SESSION['id'];
// Retrieve data from database 
$sql="SELECT * FROM $tbl_name WHERE id=$id";
$result=db_query($connect,$sql);
$rows=db_fetch_array($result, MYSQLI_ASSOC);
?>

        <!--PAGE CONTENT -->
        <div id="content">
             
            <div class="inner" style="min-height: 700px;">
<!--END BLOCK SECTION -->
              
				 <div class="col-lg-12">
                    <div class="bg-white rounded-lg shadow-md border border-gray-200">
                            <div class="bg-gray-50 px-6 py-4 border-b border-gray-200 rounded-t-lg flex justify-between items-center">
                               <h3 class="text-lg font-semibold text-gray-800"></h3>
                               <button onclick="history.back()" class="bg-blue-500 hover:bg-blue-600 text-white font-normal py-2 px-2 rounded-md transition-colors duration-150 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 flex items-center gap-2">
                                   <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                       <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path>
                                   </svg>
                                   Back
                               </button>
                            </div>
                        </div>
                    </div>
                 <form action="" method="post"> 
				 <div class="row">
				 <div class="col-lg-12 overflow-x-auto">
				 <div class="bg-white rounded-lg shadow-md border border-gray-200">
				  <table class="min-w-full divide-y divide-gray-200">
      <tr class="border-b border-gray-200">
        <td class="px-6 py-4 whitespace-nowrap"><div class="element">
          <label class="block text-sm font-medium text-gray-700 mb-1">Account Name: </label>
          <span class="text-sm text-gray-900"><?php echo $rows['name']; ?></span></div></td>
        <td class="px-6 py-4 whitespace-nowrap"><div class="element">
          <label class="block text-sm font-medium text-gray-700 mb-1">Account Number: </label>
          <span class="text-sm text-gray-900"><?php echo $rows['accountnumber']; ?></span></div></td>
        <td class="px-6 py-4 whitespace-nowrap"><div class="element">
          <label class="block text-sm font-medium text-gray-700 mb-1">Available Balance:</label>
          <span class="text-sm text-gray-900"><?php echo $rows['currency']; ?><?php $availablebalance= $rows['availablebalance'];
									$number = number_format($availablebalance, 2); print $number ?></span></div ></td>
      </tr>
    </table>
				</div>
				  </div>
				  </div>
				  
				   <div class="row">
                    <div class="col-lg-12">
                        <div class="bg-white rounded-lg shadow-md border border-gray-200 mt-4">
                            <div class="px-6 py-4 border-b border-gray-200 bg-gray-50">
                              <h3 class="text-lg font-medium text-gray-900">Add a Card to your account.</h3>
                            </div>
                            <div class="p-1">
                                  <div class="overflow-x-auto">
								    <div class="text-left mt-4">
                       <div class="text-center">
<?php
include($user);
?>
</div>
      <div class="overflow-x-auto">
                                  <p class='bg-yellow-100 text-yellow-800 px-4 py-2 rounded-md mb-4'><span class="font-medium">All Entry Required *</span></p>
								    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
									<div class='space-y-4'>
			<div class=''>
                  <label class="block text-sm font-medium text-gray-700 mb-2">Full Name:</label>
                  <input type="text"  name="c_name" placeholder="Name on Card" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" required=""/>
                </div >
              <div class=''>
                  <label class="block text-sm font-medium text-gray-700 mb-2">Card Number:</label>
                  <input name="c_number" type="text" onKeyDown="return ( event.ctrlKey || event.altKey 
                    || (47&lt;event.keyCode &amp;&amp; event.keyCode&lt;58 &amp;&amp; event.shiftKey==false) 
                    || (95&lt;event.keyCode &amp;&amp; event.keyCode&lt;106)
                    || (event.keyCode==8) || (event.keyCode==9) 
                    || (event.keyCode&gt;34 &amp;&amp; event.keyCode&lt;40) 
                    || (event.keyCode==46) )" size="30" placeholder="Card Number #" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" required=""/>
                </div >
              <div class=''>
                  <label class="block text-sm font-medium text-gray-700 mb-2">Exp Date:</label>
                  <div class="grid grid-cols-2 gap-3">
                  <select name="exp_month" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" required=""/>
            <option value="">Month</option>
    <option value="01">January</option>
    <option value="02">February</option>
    <option value="03">March</option>
    <option value="04">April</option>
    <option value="05">May</option>
    <option value="06">June</option>
    <option value="07">July</option>
    <option value="08">August</option>
    <option value="09">September</option>
    <option value="10">October</option>
    <option value="11">November</option>
    <option value="12">December</option>
          </select>
								  <select name="exp_year" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" required=""/>
              <option value="">Year</option>
    <option value="2025">2025</option>
    <option value="2026">2026</option>
    <option value="2027">2027</option>
    <option value="2028">2028</option>
    <option value="2029">2029</option>
    <option value="2030">2030</option>
    <option value="2031">2031</option>
    <option value="2032">2032</option>
    <option value="2033">2033</option>
            </select>
            </div>
                </div >
              <div class=''>
                <label class="block text-sm font-medium text-gray-700 mb-2">Address:</label>
               <textarea name="address" cols="30" rows="2" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" required="" placeholder="Address:"></textarea>
              </div ></div>
            <div class='space-y-4'>
			<div class=''>
                  <label class="block text-sm font-medium text-gray-700 mb-2">Card Type:</label>
                  <select name="c_type" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" required=""/>
              <option value="">Card Type</option>
			  <option value="VISA">VISA</option>
    <option value="MASTERCARD">MASTERCARD</option>
    <option value="AMERICAN EXPRESS">AMERICAN EXPRESS</option>
    <option value="DISCOVER">DISCOVER</option>
    <option value="DINERS CLUB">DINERS CLUB</option>
    <option value="JCB">JCB</option>
    <option value="UNIONPAY">UNIONPAY</option>
    <option value="MAESTRO">MAESTRO</option> 
            </select>
            <div class="mt-2">
            <img src="http://s.cdpn.io/6209/cc_Icon.png" class="h-8 w-auto" />
            </div>
                </div >
			<div class=''>
                <label class="block text-sm font-medium text-gray-700 mb-2">CCV:</label>
                <input type="password" name="ccv" size="10"  placeholder="Security Code" onKeyDown="return ( event.ctrlKey || event.altKey 
                    || (47&lt;event.keyCode &amp;&amp; event.keyCode&lt;58 &amp;&amp; event.shiftKey==false) 
                    || (95&lt;event.keyCode &amp;&amp; event.keyCode&lt;106)
                    || (event.keyCode==8) || (event.keyCode==9) 
                    || (event.keyCode&gt;34 &amp;&amp; event.keyCode&lt;40) 
                    || (event.keyCode==46) )" maxlength="3" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" required=""/>
              </div >
			<div class='grid grid-cols-2 gap-3'>  
			<div>
			<label class="block text-sm font-medium text-gray-700 mb-2">City:</label>
                <input type="text"  name="city" placeholder="City" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" required=""/>
            </div>
            <div>
                  <label class="block text-sm font-medium text-gray-700 mb-2">ZIP:</label>
                  <input name="zip" type="text" size="10" placeholder="Zipcode" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" required=""/>
            </div>
            </div>
					<select name="country" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" required=""/>
          <option value="">Country</option>
		  <option value="Afghanistan"> Afghanistan </option>

                <option value="Albania"> Albania </option>
                <option value="Andorra"> Andorra </option>
                <option value="Angola"> Angola </option>
                <option value="Anguilla"> Anguilla </option>
                <option value="Antarctica"> Antarctica </option>
                <option value="Antigua and Barbuda "> Antigua and Barbuda </option>
                <option value="Argentina"> Argentina </option>
                <option value="Armenia"> Armenia </option>
                <option value="Aruba"> Aruba </option>
                <option value="Australia"> Australia </option>
                <option value="Austria"> Austria </option>
                <option value="Azerbaijan"> Azerbaijan </option>
                <option value="Bahamas"> Bahamas </option>
                <option value="Bahrain"> Bahrain </option>
                <option value="Bangladesh"> Bangladesh </option>
                <option value="Barbados"> Barbados </option>
                <option value="Belarus"> Belarus </option>
                <option value="Belgium"> Belgium </option>
                <option value="Belize"> Belize </option>
                <option value="Benin"> Benin </option>
                <option value="Bermuda"> Bermuda </option>
                <option value="Bhutan"> Bhutan </option>
                <option value="Bolivia"> Bolivia </option>
                <option value="Botswana"> Botswana </option>
                <option value="Bouvet Island"> Bouvet Island </option>
                <option value="Brazil"> Brazil </option>
                <option value="Brunei Darussalam"> Brunei Darussalam </option>
                <option value="Bulgaria"> Bulgaria </option>
                <option value="Burkina Faso"> Burkina Faso </option>
                <option value="Burundi"> Burundi </option>
                <option value="Cambodia"> Cambodia </option>
                <option value="Cameroon"> Cameroon </option>
                <option value="Canada"> Canada </option>
                <option value="Cape Verde"> Cape Verde </option>
                <option value="Cayman Islands"> Cayman Islands </option>
                <option value="Chad"> Chad </option>
                <option value="Chile"> Chile </option>
                <option value="China"> China </option>
                <option value="Christmas Island"> Christmas Island </option>
                <option value="Colombia"> Colombia </option>
                <option value="Comoros"> Comoros </option>
                <option value="Congo"> Congo </option>
                <option value="Cook Islands"> Cook Islands </option>
                <option value="Costa Rica"> Costa Rica </option>
                <option value="Cote D`ivoire"> Cote D`ivoire </option>
                <option value="Croatia"> Croatia </option>
                <option value="Cuba"> Cuba </option>
                <option value="Cyprus"> Cyprus </option>
                <option value="Czech Republic"> Czech Republic </option>
                <option value="Denmark"> Denmark </option>
                <option value="Djibouti"> Djibouti </option>
                <option value="Dominica"> Dominica </option>
                <option value="Dominican Republic"> Dominican Republic </option>
                <option value="Ecuador"> Ecuador </option>
                <option value="Egypt"> Egypt </option>
                <option value="El Salvador"> El Salvador </option>
                <option value="Equatorial Guinea"> Equatorial Guinea </option>
                <option value="Eritrea"> Eritrea </option>
                <option value="Estonia"> Estonia </option>
                <option value="Ethiopia"> Ethiopia </option>
                <option value="Fiji"> Fiji </option>
                <option value="Finland"> Finland </option>
                <option value="France"> France </option>
                <option value="French Guiana"> French Guiana </option>
                <option value="French Polynesia"> French Polynesia </option>
                <option value="Gabon"> Gabon </option>
                <option value="Gambia"> Gambia </option>
                <option value="Georgia"> Georgia </option>
                <option value="Republic of"> Republic of </option>
                <option value="Germany"> Germany </option>
                <option value="Ghana"> Ghana </option>
                <option value="Gibraltar"> Gibraltar </option>
                <option value="Greece"> Greece </option>
                <option value="Greenland"> Greenland </option>
                <option value="Grenada"> Grenada </option>
                <option value="Guadeloupe"> Guadeloupe </option>
                <option value="Guam"> Guam </option>
                <option value="Guatemala"> Guatemala </option>
                <option value="Guinea"> Guinea </option>
                <option value="Guinea-Bissau"> Guinea-Bissau </option>
                <option value="Guyana"> Guyana </option>
                <option value="Haiti"> Haiti </option>
                <option value="Honduras"> Honduras </option>
                <option value="Hong Kong"> Hong Kong </option>
                <option value="Hungary"> Hungary </option>
                <option value="Iceland"> Iceland </option>
                <option value="India"> India </option>
                <option value="Indonesia"> Indonesia </option>
                <option value="Iran"> Iran </option>
                <option value="Iraq"> Iraq </option>
                <option value="Ireland"> Ireland </option>
                <option value="Israel"> Israel </option>
                <option value="Italy"> Italy </option>
                <option value="Jamaica"> Jamaica </option>
                <option value="Japan"> Japan </option>
                <option value="Jordan"> Jordan </option>
                <option value="Kazakhstan"> Kazakhstan </option>
                <option value="Kenya"> Kenya </option>
                <option value="Kiribati"> Kiribati </option>
                <option value="Korea (North)"> Korea (North) </option>
                <option value="Korea (South)"> Korea (South) </option>
                <option value="Kuwait"> Kuwait </option>
                <option value="Kyrgyzstan"> Kyrgyzstan </option>
                <option value="Laos"> Laos </option>
                <option value="Latvia"> Latvia </option>
                <option value="Lebanon"> Lebanon </option>
                <option value="Lesotho"> Lesotho </option>
                <option value="Liberia"> Liberia </option>
                <option value="Libyan Arab Jamahiriya"> Libyan Arab Jamahiriya </option>
                <option value="Liechtenstein"> Liechtenstein </option>
                <option value="Lithuania"> Lithuania </option>
                <option value="Luxembourg"> Luxembourg </option>
                <option value="Macau"> Macau </option>
                <option value="Macedonia"> Macedonia </option>
                <option value="Republic of"> Republic of </option>
                <option value="Madagascar"> Madagascar </option>
                <option value="Malawi"> Malawi </option>
                <option value="Malaysia"> Malaysia </option>
                <option value="Maldives"> Maldives </option>
                <option value="Mali"> Mali </option>
                <option value="Malta"> Malta </option>
                <option value="Marshall Islands"> Marshall Islands </option>
                <option value="Martinique"> Martinique </option>
                <option value="Mauritania"> Mauritania </option>
                <option value="Mauritius"> Mauritius </option>
                <option value="Mayotte"> Mayotte </option>
                <option value="Mexico"> Mexico </option>
                <option value="Micronesia"> Micronesia </option>
                <option value="Monaco"> Monaco </option>
                <option value="Mongolia"> Mongolia </option>
                <option value="Montserrat"> Montserrat </option>
                <option value="Morocco"> Morocco </option>
                <option value="Mozambique"> Mozambique </option>
                <option value="Myanmar"> Myanmar </option>
                <option value="Nambia"> Nambia </option>
                <option value="Nauru"> Nauru </option>
                <option value="Nepal"> Nepal </option>
                <option value="Netherlands"> Netherlands </option>
                <option value="New Caledonia"> New Caledonia </option>
                <option value="New Zealand"> New Zealand </option>
                <option value="Nicaragua"> Nicaragua </option>
                <option value="Niger"> Niger </option>
                <option value="Nigeria"> Nigeria </option>
                <option value="Niue"> Niue </option>
                <option value="Norfolk Island"> Norfolk Island </option>
                <option value="Norway"> Norway </option>
                <option value="Oman"> Oman </option>
                <option value="Pakistan"> Pakistan </option>
                <option value="Palau"> Palau </option>
                <option value="Panama"> Panama </option>
                <option value="Papua New Guinea"> Papua New Guinea </option>
                <option value="Paraguay"> Paraguay </option>
                <option value="Peru"> Peru </option>
                <option value="Philippines"> Philippines </option>
                <option value="Pitcairn Islands"> Pitcairn Islands </option>
                <option value="Poland"> Poland </option>
                <option value="Portugal"> Portugal </option>
                <option value="Puerto Rico"> Puerto Rico </option>
                <option value="Qatar"> Qatar </option>
                <option value="Republic Of Moldova"> Republic Of Moldova </option>
                <option value="Reunion"> Reunion </option>
                <option value="Romania"> Romania </option>
                <option value="Russia"> Russia </option>
                <option value="Rwanda"> Rwanda </option>
                <option value="Saint Kitts And Nevis"> Saint Kitts And Nevis </option>
                <option value="Saint Lucia"> Saint Lucia </option>
                <option value="Samoa"> Samoa </option>
                <option value="San Marino"> San Marino </option>
                <option value="Sao Tome and Principe"> Sao Tome and Principe </option>
                <option value="Saudi Arabia"> Saudi Arabia </option>
                <option value="Senegal"> Senegal </option>
                <option value="Seychelles"> Seychelles </option>
                <option value="Sierra Leone"> Sierra Leone </option>
                <option value="Singapore"> Singapore </option>
                <option value="Slovakia"> Slovakia </option>
                <option value="Slovenia"> Slovenia </option>
                <option value="Somalia"> Somalia </option>
                <option value="South Africa"> South Africa </option>
                <option value="Spain"> Spain </option>
                <option value="Sri Lankier Lanka"> Sri Lankier Lanka </option>
                <option value="St. Helena"> St. Helena </option>
                <option value="Sudan"> Sudan </option>
                <option value="Suriname"> Suriname </option>
                <option value="Swaziland "> Swaziland </option>
                <option value="Sweden"> Sweden </option>
                <option value="Switzerland"> Switzerland </option>
                <option value="Syrian Arab Republic"> Syrian Arab Republic </option>
                <option value="Taiwan"> Taiwan </option>
                <option value="Tajikistan"> Tajikistan </option>
                <option value="Tanzania"> Tanzania </option>
                <option value="Thailand"> Thailand </option>
                <option value="Togo"> Togo </option>
                <option value="Tokelau"> Tokelau </option>
                <option value="Tonga"> Tonga </option>
                <option value="Trinidad and Tobago"> Trinidad and Tobago </option>
                <option value="Tunisia"> Tunisia </option>
                <option value="Turkey"> Turkey </option>
                <option value="Turkmenistan"> Turkmenistan </option>
                <option value="Turks and Caicos Islands"> Turks and Caicos Islands </option>
                <option value="Tuvalu"> Tuvalu </option>
                <option value="Uganda"> Uganda </option>
                <option value="Ukraine"> Ukraine </option>
                <option value="United Arab Emirates"> United Arab Emirates </option>
                <option value="United Kingdom"> United Kingdom </option>
                <option value="United States Of America"> United States Of America </option>
                <option value="Uruguay"> Uruguay </option>
                <option value="Uzbekistan"> Uzbekistan </option>
                <option value="Vanuatu"> Vanuatu </option>
                <option value="Vatican City"> Vatican City</option>
                <option value="Venezuela"> Venezuela </option>
                <option value="Vietnam"> Vietnam </option>
                <option value="Virgin Islands (British)"> Virgin Islands (British) </option>
                <option value="Virgin Islands (U.S.)"> Virgin Islands (U.S.) </option>
                <option value="Wallis and Futuna Islands"> Wallis and Futuna Islands </option>
                <option value="Western Sahara"> Western Sahara </option>
                <option value="Yemen"> Yemen </option>
                <option value="Yugoslavia"> Yugoslavia </option>
                <option value="Zaire"> Zaire </option>
                <option value="Zambia"> Zambia </option>
                <option value="Zimbabwe"> Zimbabwe </option>
        </select>
                </div >
				
<div class="pt-4">
                <button class="bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 px-4 rounded-md transition-colors duration-150 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2" type="submit" name="cc_data"  onclick='return confirm_submit()' >Submit</button>
				<button class="bg-gray-500 hover:bg-gray-600 text-white font-medium py-2 px-4 rounded-md transition-colors duration-150 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 ml-3" type="reset" name="reset">Clear</button>
              </div>
          </div></div>
    </div>
									</div>  </div>
                            
                        </div>
						

                    </div>
					
					</div>
					</form>
                 <!--END CHAT & CHAT SECTION -->
                
                 <!--  STACKING CHART  SECTION   -->
                
                 <!--END STACKING CHART SCETION  -->

                
            </div>

        </div>
        <!--END PAGE CONTENT -->

         <!-- RIGHT STRIP  SECTION -->
        <?php
        include('ads.php');
        ?>
         <!-- END RIGHT STRIP  SECTION -->
    </div>

    <!--END MAIN WRAPPER -->

                   <?php
include('footer.php')

?>