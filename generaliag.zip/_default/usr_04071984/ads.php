﻿
         <!-- RIGHT STRIP  SECTION -->
        <div id="right" class="right-0 top-20 w-64 p-4 lg:block hidden">
            <div class="bg-gray-50 p-4 rounded-lg border border-gray-200">
               <img src="assets/img/ad.png" class="w-full" />
            </div>
         
        </div>
         <!-- END RIGHT STRIP  SECTION -->
         
         <!-- MOBILE AD STRIP (Centered) -->
        <div class="lg:hidden block w-full max-w-md mx-auto p-4 mt-4">
            <div class="bg-gray-50 p-4 rounded-lg border border-gray-200">
               <img src="assets/img/ad.png" class="w-full" />
            </div>
        </div>