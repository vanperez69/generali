<div class="grid grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3 mb-3 max-w-4xl mx-auto">
    <div class="text-center">
        <a href="main.php" class="block p-2 bg-gradient-to-br from-red-500 to-red-600 rounded-xl shadow-md hover:shadow-lg transform hover:-translate-y-1 transition-all duration-200 text-white">
            <div class="w-10 h-10 mx-auto mb-2 bg-white bg-opacity-20 rounded-full flex items-center justify-center">
                <i class="icon-home text-lg"></i>
            </div>
            <span class="block font-normal text-xs">Home</span>
        </a>
    </div>

    <div class="text-center">
        <a href="mssg.php" class="block p-2 bg-gradient-to-br from-red-500 to-red-600 rounded-xl shadow-md hover:shadow-lg transform hover:-translate-y-1 transition-all duration-200 text-white relative">
            <div class="w-10 h-10 mx-auto mb-2 bg-white bg-opacity-20 rounded-full flex items-center justify-center">
                <i class="icon-envelope text-lg"></i>
            </div>
            <span class="block font-normal text-xs">Messages</span>
            <?php 
            $id=$_SESSION['id']; 
            $sql = "SELECT COUNT(m_status) FROM $mail WHERE id='$id' AND m_status='unread'"; 
            $result = db_query($connect,$sql); 
            $row = db_fetch_row($result); 
            $total_records = ($row && isset($row[0])) ? $row[0] : 0;
            if($total_records > 0) { 
            ?>
                <span class="absolute -top-1 -right-1 bg-red-500 text-white text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center"><?php echo $total_records; ?></span>
            <?php } ?>
        </a>
    </div>

    <div class="text-center">
        <a href="view_transact.php" class="block p-2 bg-gradient-to-br from-red-500 to-red-600 rounded-xl shadow-md hover:shadow-lg transform hover:-translate-y-1 transition-all duration-200 text-white relative">
            <div class="w-10 h-10 mx-auto mb-2 bg-white bg-opacity-20 rounded-full flex items-center justify-center">
                <i class="icon-briefcase text-lg"></i>
            </div>
            <span class="block font-normal text-xs">Transactions</span>
            <?php 
            $id=$_SESSION['id']; 
            $sql = "SELECT COUNT(id) FROM $trans WHERE id='$id'"; 
            $result = db_query($connect,$sql); 
            $row = db_fetch_row($result); 
            $total_records = ($row && isset($row[0])) ? $row[0] : 0;
            if($total_records > 0) { 
            ?>
                <span class="absolute -top-1 -right-1 bg-red-500 text-white text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center"><?php echo $total_records; ?></span>
            <?php } ?>
        </a>
    </div>

    <div class="text-center">
        <a href="u_ben.php" class="block p-2 bg-gradient-to-br from-red-500 to-red-600 rounded-xl shadow-md hover:shadow-lg transform hover:-translate-y-1 transition-all duration-200 text-white relative">
            <div class="w-10 h-10 mx-auto mb-2 bg-white bg-opacity-20 rounded-full flex items-center justify-center">
                <i class="icon-book text-lg"></i>
            </div>
            <span class="block font-normal text-xs">Beneficiaries</span>
            <?php 
            $id=$_SESSION['id']; 
            $sql = "SELECT COUNT(id) FROM $ben_info WHERE id='$id'"; 
            $result = db_query($connect,$sql); 
            $row = db_fetch_row($result); 
            $total_records = ($row && isset($row[0])) ? $row[0] : 0;
            if($total_records > 0) { 
            ?>
                <span class="absolute -top-1 -right-1 bg-red-500 text-white text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center"><?php echo $total_records; ?></span>
            <?php } ?>
        </a>
    </div>

    <div class="text-center">
        <a href="edit_pass.php" class="block p-2 bg-gradient-to-br from-red-500 to-red-600 rounded-xl shadow-md hover:shadow-lg transform hover:-translate-y-1 transition-all duration-200 text-white">
            <div class="w-10 h-10 mx-auto mb-2 bg-white bg-opacity-20 rounded-full flex items-center justify-center">
                <i class="icon-user text-lg"></i>
            </div>
            <span class="block font-normal text-xs">Profile</span>
        </a>
    </div>

    <div class="text-center">
        <a href="u_check.php" class="block p-2 bg-gradient-to-br from-red-500 to-red-600 rounded-xl shadow-md hover:shadow-lg transform hover:-translate-y-1 transition-all duration-200 text-white">
            <div class="w-10 h-10 mx-auto mb-2 bg-white bg-opacity-20 rounded-full flex items-center justify-center">
                <i class="icon-money text-lg"></i>
            </div>
            <span class="block font-normal text-xs">Check</span>
        </a>
    </div>
</div>
