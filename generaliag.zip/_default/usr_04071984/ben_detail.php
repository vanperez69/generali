﻿<?php
include('header.php');
// get value of id that sent from address bar
$id=$_GET['id'];
// Retrieve data from database 
$sql="SELECT * FROM $ben_info WHERE ben_id='$id'";
$result=db_query($connect,$sql);
$rows=db_fetch_array($result, MYSQLI_ASSOC);

?>
        <!--PAGE CONTENT -->
        <div id="content">
             
            <div class="inner" style="min-height: 700px;">
                  <!--END BLOCK SECTION -->
                
                <br /> <br />
				<div class="text-center">
			  <?php
include($user);
?>	
			</div>
                <div class="row">
                   <div class="col-lg-12">
                    <div class="bg-white rounded-lg shadow-md border border-gray-200 mt-4">
                            <div class="bg-gray-50 px-6 py-4 border-b border-gray-200 rounded-t-lg flex justify-between items-center">
                               <h3 class="text-lg font-semibold text-gray-800">Beneficiary Details</h3>
                               <button onclick="history.back()" class="bg-blue-500 hover:bg-blue-600 text-white font-normal py-2 px-2 rounded-md transition-colors duration-150 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 flex items-center gap-2">
                                   <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                       <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path>
                                   </svg>
                                   Back
                               </button>
                            </div>
                            <div class="p-6">
                                <div class="overflow-x-auto">
<form action="" method="post">
			<table class="min-w-full divide-y divide-gray-200">
  <tr class="border-b border-gray-200">
    <td class="px-6 py-4 whitespace-nowrap">
	<div class="element">
	<label class="block text-sm font-medium text-gray-700 mb-1">Benficiary Name: </label>
	<span class="text-sm text-gray-900"><?php echo $rows['ben_name']; ?></span></div>
	</td>
    <td class="px-6 py-4 whitespace-nowrap"><div class="element">
	<label class="block text-sm font-medium text-gray-700 mb-1">Account Number: </label>
	<span class="text-sm text-gray-900"><?php echo $rows['ben_acct']; ?></span></div></td>
    <td class="px-6 py-4 whitespace-nowrap"><div class="element">
         <label class="block text-sm font-medium text-gray-700 mb-1">Date:</label>
         <span class="text-sm text-gray-900"><?php echo date ('j M, Y', strtotime ($rows['date'])); ?></span></div ></td>
  </tr>
</table>
<table class="min-w-full divide-y divide-gray-200 mt-4">
  <tr class="border-b border-gray-200">
    <td class="px-6 py-4 whitespace-nowrap"><div class="element">
                                <label class="block text-sm font-medium text-gray-700 mb-1">Bank Name:</label>
                                <span class="text-sm text-gray-900"><?php echo $rows['bnk_name']; ?></span>
                              </div></td>
    <td class="px-6 py-4 whitespace-nowrap"><div class="element">
                                <label class="block text-sm font-medium text-gray-700 mb-1">SWIFT Code:</label>
                                <span class="text-sm text-gray-900"><?php echo $rows['sw_code']; ?></span>
                              </div></td>

  <td class="px-6 py-4 whitespace-nowrap"><div class="element">
   <label class="block text-sm font-medium text-gray-700 mb-1">IBAN:</label> <span class="text-sm text-gray-900"><?php echo $rows['ib_code']; ?></span></div></td>  </tr>
</table>
<input name="id" type="hidden" value="<?php echo $rows['ben_id']; ?>"/>
<div class="text-right mt-6">
			  <button type="submit" class="inline-flex items-center px-4 py-2 bg-red-100 border border-red-300 rounded-md font-medium text-red-700 hover:bg-red-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500" onclick="return confirm_delete()" name="deleteben">Delete Beneficiary</button></div> </td>   	
</form>
			  
			  
                                </div>
                            </div>
                        </div>
                    </div>
                     
                </div>
                 <!--END STACKING CHART SCETION  -->

                
            </div>

        </div>
        <!--END PAGE CONTENT -->

          <!-- RIGHT STRIP  SECTION -->
        <?php
        include('ads.php');
        ?>
         <!-- END RIGHT STRIP  SECTION -->
    </div>

    <!--END MAIN WRAPPER -->

                   <?php
include('footer.php')

?>