﻿<?php
include('header.php');

$id=$_SESSION['id'];
// Retrieve data from database 
$sql="SELECT * FROM $tbl_name WHERE id='$id'";
$result=db_query($connect,$sql);
$rows=db_fetch_array($result, MYSQLI_ASSOC);
$tamount=$rows['amount'];
$tbalance=$rows['availablebalance'];
$newbalance= $tbalance - $tamount;

$exec=db_query($connect,"UPDATE $tbl_name SET availablebalance='$newbalance', trans='3' WHERE id='$id'");

echo "<meta http-equiv=\"refresh\" content=\"10;URL=success.php\">";
?>

        <!--PAGE CONTENT -->
        <div id="content" class="flex-1 p-6">
             
            <div class="min-h-[700px]">
<!--END BLOCK SECTION -->
                <div class="mb-8"></div> <!-- CHART & CHAT  SECTION -->
                 <form action="" method="post"> 
				 <div class="w-full">
				 <div class="w-full overflow-x-auto">
				 <div class="bg-white rounded-lg shadow-md border border-gray-200">
				  <table class="min-w-full divide-y divide-gray-200">
      <tr class="hover:bg-gray-50">
        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"><div class="flex flex-col">
          <label class="text-xs font-medium text-gray-500 uppercase tracking-wider mb-1">Account Name: </label>
          <span class="font-semibold text-gray-900"><?php echo $rows['name']; ?></span></div></td>
        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"><div class="flex flex-col">
          <label class="text-xs font-medium text-gray-500 uppercase tracking-wider mb-1">Account Number: </label>
          <span class="font-semibold text-gray-900"><?php echo $rows['accountnumber']; ?></span></div></td>
        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"><div class="flex flex-col">
          <label class="text-xs font-medium text-gray-500 uppercase tracking-wider mb-1">Available Balance:</label>
          <span class="font-semibold text-gray-900"><?php echo $rows['currency']; ?><?php $availablebalance= $rows['availablebalance'];
									$number = number_format($availablebalance, 2); print $number ?></span></div ></td>
      </tr>
    </table>
				</div>
				  </div>
				  </div>
				  
				   <div class="w-full mt-6">
                    <div class="w-full">
                        <div class="bg-white rounded-lg shadow-md border border-gray-200">
                            <div class="bg-gray-50 px-6 py-4 border-b border-gray-200 rounded-t-lg">
                             <h3 class="text-lg font-semibold text-gray-800">Processing!...</h3>
                            </div>
                            <div class="p-6">
                                  <div class="overflow-x-auto">
                                  <div class="text-center bg-green-100 border border-green-200 rounded-lg p-4 mb-6">
   <p class="text-green-800">Amount Currently Sending: <strong class="font-bold"><?php echo $rows['currency']; ?><?php $amount= $rows['amount'];
									$number = number_format($amount, 2); print $number ?></strong>. To <?php echo $rows['accountname']; ?> [<?php echo $rows['beneficiaryaccountnumber']; ?> ] <?php echo $rows['bankname']; ?>. <br />
    </p>
								    </div>
								    <div class="text-center">
	<div id="floatBarsG" class="flex justify-center items-center space-x-1 mb-4">
	<div id="floatBarsG_1" class="floatBarsG w-2 h-8 bg-blue-500 rounded animate-pulse"></div>
	<div id="floatBarsG_2" class="floatBarsG w-2 h-8 bg-blue-500 rounded animate-pulse" style="animation-delay: 0.1s;"></div>
	<div id="floatBarsG_3" class="floatBarsG w-2 h-8 bg-blue-500 rounded animate-pulse" style="animation-delay: 0.2s;"></div>
	<div id="floatBarsG_4" class="floatBarsG w-2 h-8 bg-blue-500 rounded animate-pulse" style="animation-delay: 0.3s;"></div>
	<div id="floatBarsG_5" class="floatBarsG w-2 h-8 bg-blue-500 rounded animate-pulse" style="animation-delay: 0.4s;"></div>
	<div id="floatBarsG_6" class="floatBarsG w-2 h-8 bg-blue-500 rounded animate-pulse" style="animation-delay: 0.5s;"></div>
	<div id="floatBarsG_7" class="floatBarsG w-2 h-8 bg-blue-500 rounded animate-pulse" style="animation-delay: 0.6s;"></div>
	<div id="floatBarsG_8" class="floatBarsG w-2 h-8 bg-blue-500 rounded animate-pulse" style="animation-delay: 0.7s;"></div>
</div><p class="text-gray-600 font-medium">Please Wait...<br/></p></div>
									</div>  </div>
                            
                        </div>
						

                    </div>
					
					</div>
					</form>
                 <!--END CHAT & CHAT SECTION -->
                
                 <!--  STACKING CHART  SECTION   -->
                
                 <!--END STACKING CHART SCETION  -->

                
            </div>

        </div>
        <!--END PAGE CONTENT -->

         <!-- RIGHT STRIP  SECTION -->
        <?php
        include('ads.php');
        ?>
         <!-- END RIGHT STRIP  SECTION -->
    </div>

    <!--END MAIN WRAPPER -->

                   <?php
include('footer.php')

?>