﻿<div class="col-lg-12">
     <div class="bg-white rounded-lg shadow-md border border-gray-200 mt-4">
				  <table class="min-w-full divide-y divide-gray-200">
      <tr class="border-b border-gray-200">
        <td class="px-3 py-4 md:px-6"><div class="element">
          <label class="block text-sm font-medium text-gray-700 mb-1">Account Name: </label>
          <span class="text-sm text-blue-800"><?php echo $rows['name']; ?></span></div></td>
        <td class="px-3 py-4 md:px-6"><div class="element">
          <label class="block text-sm font-medium text-gray-700 mb-1">Account Number: </label>
          <span class="text-sm text-blue-800"><?php echo $rows['accountnumber']; ?></span></div></td>
        <td class="px-3 py-4 md:px-6"><div class="element">
          <label class="block text-sm font-medium text-gray-700 mb-1">Available Balance:</label>
          <span class="text-sm text-blue-800"><?php echo $rows['currency']; ?><?php $availablebalance= $rows['availablebalance'];
									$number = number_format($availablebalance, 2); print $number ?></span></div ></td>
      </tr>
    </table>
				</div>
				  </div>
                  </div>