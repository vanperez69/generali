<?php
session_start();
include('../ad_panel/inc/config.php');
$id=$_SESSION['id'];
// Retrieve data from database 
$update = db_query($connect,"UPDATE $tbl_name SET lastlogin=NOW() WHERE id='$id'");


session_destroy();
echo "<meta http-equiv=\"refresh\" content=\"0;URL=index.php\">";
?>