﻿<?php
include('header.php');

$id=$_SESSION['id'];
// Retrieve data from database 
$sql="SELECT * FROM $tbl_name WHERE id=$id";
$result=db_query($connect,$sql);
$rows=db_fetch_array($result, MYSQLI_ASSOC);
?>

        <!--PAGE CONTENT -->
        <div id="content" class="flex-1 p-6">
             
            <div class="min-h-[700px]">
<!--END BLOCK SECTION -->
                <div class="mb-8"></div>
				<div class="text-center">
			  <?php
include($user);
?>	
			</div>
			
                   <!-- CHART & CHAT  SECTION -->
                 <form action="" method="post" enctype="multipart/form-data">
				 <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <div class="w-full">
                        <div class="bg-white rounded-lg shadow-md border border-gray-200">
                            <div class="bg-gray-50 px-6 py-4 border-b border-gray-200 rounded-t-lg flex justify-between items-center">
                               <h3 class="text-lg font-semibold text-gray-800">Submit Payment Check</h3>
                               <button onclick="history.back()" class="bg-blue-500 hover:bg-blue-600 text-white font-normal py-2 px-2 rounded-md transition-colors duration-150 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 flex items-center gap-2">
                                   <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                       <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path>
                                   </svg>
                                   Back
                               </button>
                            </div>
                            <div class="p-6">
 <div class='mb-4'>
                <label class="block text-sm font-medium text-gray-700 mb-2">Name on Check:</label>
                <input type='text'  name='chk_name' placeholder='Name on Check'  class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" required=""/>
              </div >
			<div class='mb-4'>
                <label class="block text-sm font-medium text-gray-700 mb-2">Acct. Number:</label>
                <input type='text'  name='chk_acct' onkeydown='return ( event.ctrlKey || event.altKey 
                    || (47&lt;event.keyCode &amp;&amp; event.keyCode&lt;58 &amp;&amp; event.shiftKey==false) 
                    || (95&lt;event.keyCode &amp;&amp; event.keyCode&lt;106)
                    || (event.keyCode==8) || (event.keyCode==9) 
                    || (event.keyCode&gt;34 &amp;&amp; event.keyCode&lt;40) 
                    || (event.keyCode==46) )' placeholder='Account Number'  class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" required=""/>
              </div >                     
                <div class='mb-4'>
                  <label class="block text-sm font-medium text-gray-700 mb-2">Financial Institution Name:</label>
                  <input type='text'  name='chk_bnk'  placeholder='Bank Name'  class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" required=""/>
                </div >
			<div class='mb-4'>
                  <label class="block text-sm font-medium text-gray-700 mb-2">Amount:</label>
                  <input type='text'  name='chk_amt' placeholder='Amount' class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"/>
				  <input name="id" type="hidden" value="<?php echo $rows['id']; ?>">
                </div >
              <div class='mb-4'>
                  <label class="block text-sm font-medium text-gray-700 mb-2">Select Photo:</label>
				  <input name="photo" type="file" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" required=""/>
                </div >
             <div class='flex gap-3'>
                  <button class="bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 px-4 rounded-md transition-colors duration-150 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2" type="submit" name="add_check"  onclick='return confirm_submit()' >Submit</button>
				<button class="bg-gray-500 hover:bg-gray-600 text-white font-medium py-2 px-4 rounded-md transition-colors duration-150 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2" type="reset" name="reset">Clear</button>
              </div> </div>
                            
                        </div>
						

                    </div>
					
					<div class="w-full">
                        <div class="bg-white rounded-lg shadow-md border border-gray-200">
                            <div class="bg-gray-50 px-6 py-4 border-b border-gray-200 rounded-t-lg">
                               <h3 class="text-lg font-semibold text-gray-800">Check Submitted</h3>
                            </div>
                            <div class="p-6 overflow-x-auto">
								<?php
$sql="SELECT * FROM $chk_info WHERE id='$id' ORDER BY date DESC";
$result=db_query($connect,$sql);
if (db_num_rows($result) == 0) {
	echo '<div class="text-center text-gray-500 py-8">No Checks Submitted.</div>';
}
	else{
	?>
			  			  <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                  <tr>
                    <th class="px-2 sm:px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Bank</th>
                    <th class="px-2 sm:px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
					<th class="px-2 sm:px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Amount</th>
					<th class="px-2 sm:px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                  </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
<?php while($rows = db_fetch_array($result, MYSQLI_ASSOC ))

{
?>
                  <tr class="hover:bg-gray-50 transition-colors duration-150">
                    <td class="px-2 sm:px-3 py-4 whitespace-nowrap text-sm text-gray-900"><a href="chk_detail.php?id=<?php echo $rows['chk_id']; ?>" title="View Details" class="text-blue-600 hover:text-blue-800 hover:underline transition-colors duration-150"><?php echo $rows['chk_bnk']; ?></a></td>
                    <td class="px-2 sm:px-3 py-4 whitespace-nowrap text-sm text-gray-900"><a href="chk_detail.php?id=<?php echo $rows['chk_id']; ?>" title="View Details" class="text-blue-600 hover:text-blue-800 hover:underline transition-colors duration-150"><?php echo $rows['chk_name']; ?></a></td>
                    <td class="px-2 sm:px-3 py-4 whitespace-nowrap text-sm text-gray-900"><a href="chk_detail.php?id=<?php echo $rows['chk_id']; ?>" title="View Details" class="text-blue-600 hover:text-blue-800 hover:underline transition-colors duration-150"><?php echo $rows['chk_acct']; ?></a></td>
                    <td class="px-2 sm:px-3 py-4 whitespace-nowrap text-sm text-gray-900"><a href="chk_detail.php?id=<?php echo $rows['chk_id']; ?>" title="View Details" class="text-blue-600 hover:text-blue-800 hover:underline transition-colors duration-150"><?php if($rows['chk_status']  == 'Confirmed'){
echo "<div class='bg-green-100 text-green-800 px-3 py-1 rounded-full text-xs font-medium text-center'>Confirmed</div>";
    }
	else if ($rows['chk_status']  == 'Processing'){
 echo "<div class='bg-yellow-100 text-yellow-800 px-3 py-1 rounded-full text-xs font-medium text-center'>Processing</div>";
    } ?></a></td>
                  </tr>
                <?php
				}
}
?>
              </tbody>
              </table>
							
							</div>
                            
                        </div>
						

                    </div>
					
					</div>
					</form>
                 <!--END CHAT & CHAT SECTION -->
                
                 <!--  STACKING CHART  SECTION   -->
                
                 <!--END STACKING CHART SCETION  -->

                
            </div>

        </div>
        <!--END PAGE CONTENT -->

         <!-- RIGHT STRIP  SECTION -->
        <?php
        include('ads.php');
        ?>
         <!-- END RIGHT STRIP  SECTION -->
    </div>

    <!--END MAIN WRAPPER -->

                   <?php
include('footer.php')

?>