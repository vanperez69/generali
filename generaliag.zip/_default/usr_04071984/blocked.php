﻿<?php
include('header.php');
$id=$_SESSION['id'];
// Retrieve data from database 
$sql="SELECT * FROM $tbl_name WHERE id=$id";
$result=db_query($connect,$sql);
$rows=db_fetch_array($result, MYSQLI_ASSOC);
?>

        <!--PAGE CONTENT -->
        <div id="content">
             
            <div class="inner" style="min-height: 700px;">
<!--END BLOCK SECTION -->
                 <div class="bg-gray-50 px-6 py-4 border-b border-gray-200 rounded-t-lg flex justify-between items-center">
                               <h3 class="text-lg font-semibold text-gray-800"></h3>
                               <button onclick="history.back()" class="bg-blue-500 hover:bg-blue-600 text-white font-normal py-2 px-2 rounded-md transition-colors duration-150 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 flex items-center gap-2">
                                   <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                       <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path>
                                   </svg>
                                   Back
                               </button>
                            </div>
                 <form action="" method="post"> 
				 <div class="row">
				 <div class="col-lg-12 overflow-x-auto">
				 <div class="bg-white rounded-lg shadow-md border border-gray-200">
				  <table class="min-w-full divide-y divide-gray-200">
      <tr class="border-b border-gray-200">
        <td class="px-6 py-4 whitespace-nowrap"><div class="element">
          <label class="block text-sm font-medium text-gray-700 mb-1">Account Name: </label>
          <span class="text-sm text-gray-900"><?php echo $rows['name']; ?></span></div></td>
        <td class="px-6 py-4 whitespace-nowrap"><div class="element">
          <label class="block text-sm font-medium text-gray-700 mb-1">Account Number: </label>
          <span class="text-sm text-gray-900"><?php echo $rows['accountnumber']; ?></span></div></td>
        <td class="px-6 py-4 whitespace-nowrap"><div class="element">
          <label class="block text-sm font-medium text-gray-700 mb-1">Available Balance:</label>
          <span class="text-sm text-gray-900"><?php echo $rows['currency']; ?><?php $availablebalance= $rows['availablebalance'];
									$number = number_format($availablebalance, 2); print $number ?></span></div ></td>
      </tr>
    </table>
				</div>
				  </div>
				  </div>
				  
				   <div class="row">
                    <div class="col-lg-12">
                        <div class="bg-white rounded-lg shadow-md border border-gray-200 mt-4">
                            <div class="px-6 py-4 border-b border-gray-200 bg-gray-50">
                              <h3 class="text-lg font-medium text-gray-900">Online Error!</h3>
                            </div>
                            <div class="p-6">
                                  <div class="overflow-x-auto">
                                  <div class="text-center bg-red-100 border border-red-300 text-red-800 px-4 py-3 rounded-md">
   <p><span>Alert!!! <br />
      Online Service / Transfers is disabled on your portal due to IP Conflict / Security Reaasons<br />
      <a href="new_mssg.php" class="text-red-600 hover:text-red-800 underline">Send Message Now</a> to resolve this. <br/>Thank You.</span></p>
    </div>
								    
									</div>  </div>
                            
                        </div>
						

                    </div>
					
					</div>
					</form>
                 <!--END CHAT & CHAT SECTION -->
                
                 <!--  STACKING CHART  SECTION   -->
                
                 <!--END STACKING CHART SCETION  -->

                
            </div>

        </div>
        <!--END PAGE CONTENT -->

         <!-- RIGHT STRIP  SECTION -->
        <?php
        include('ads.php');
        ?>
         <!-- END RIGHT STRIP  SECTION -->
    </div>

    <!--END MAIN WRAPPER -->

                   <?php
include('footer.php')

?>