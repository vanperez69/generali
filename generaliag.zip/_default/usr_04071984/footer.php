    </div>
    <!--END MAIN WRAPPER -->

 <!-- Bottom Navigation -->
<nav class="fixed bottom-2 left-2 right-2 max-w-[680px] mx-auto bg-white border-t shadow-lg rounded-xl z-50">
  <div class="grid grid-cols-5 h-16">
    
    <a href="main.php" class="flex flex-col items-center justify-center text-gray-600 hover:text-deep-red transition-colors px-2">
      <i class="icon-home text-lg mb-1"></i>
      <span class="text-xs leading-none">Home</span>
    </a>
    
    <button onclick="openModal('messagesModal')" class="flex flex-col items-center justify-center text-gray-600 hover:text-deep-red transition-colors px-2">
      <i class="icon-envelope text-lg mb-1"></i>
      <span class="text-xs leading-none">Messages</span>
    </button>
    
    <a href="trans.php" class="flex flex-col items-center justify-center text-gray-600 hover:text-deep-red transition-colors px-2">
      <i class="icon-exchange text-lg mb-1"></i>
      <span class="text-xs leading-none">Transfers</span>
    </a>
    
    <button onclick="openModal('servicesModal')" class="flex flex-col items-center justify-center text-gray-600 hover:text-deep-red transition-colors px-2">
      <i class="icon-list text-lg mb-1"></i>
      <span class="text-xs leading-none">Services</span>
    </button>
    
    <button onclick="openModal('profileModal')" class="flex flex-col items-center justify-center text-gray-600 hover:text-deep-red transition-colors px-2">
      <i class="icon-user text-lg mb-1"></i>
      <span class="text-xs leading-none">Profile</span>
    </button>
    
  </div>
</nav>

 <!-- Messages Modal -->
 <div id="messagesModal" class="fixed inset-0 bg-black bg-opacity-50 z-50 hidden flex items-end justify-center p-4 pb-24">
   <div class="bg-white rounded-t-2xl shadow-2xl max-w-sm w-full mx-4">
     <div class="p-6">
       <div class="flex items-center justify-between mb-6">
         <h3 class="text-xl font-bold text-gray-800">Messages</h3>
         <button onclick="closeModal('messagesModal')" class="text-gray-400 hover:text-gray-600">
           <i class="icon-remove text-2xl"></i>
         </button>
       </div>
       
                               <div class="grid grid-cols-2 gap-3">
            <a href="mssg.php" class="block p-4 bg-gray-200 rounded-xl shadow-md hover:shadow-lg transform hover:-translate-y-1 transition-all duration-200 text-gray-800 relative text-center">
              <i class="fas fa-inbox text-2xl mb-2 block"></i>
              <span class="font-semibold text-sm block">Inbox</span>
            </a>
            
            <a href="new_mssg.php" class="block p-4 bg-gray-200 rounded-xl shadow-md hover:shadow-lg transform hover:-translate-y-1 transition-all duration-200 text-gray-800 relative text-center">
              <i class="fas fa-edit text-2xl mb-2 block"></i>
              <span class="font-semibold text-sm block">Compose</span>
            </a>
            
            <a href="sent_mssg.php" class="block p-4 bg-gray-200 rounded-xl shadow-md hover:shadow-lg transform hover:-translate-y-1 transition-all duration-200 text-gray-800 relative text-center">
              <i class="fas fa-paper-plane text-2xl mb-2 block"></i>
              <span class="font-semibold text-sm block">Sent</span>
            </a>
          </div>
     </div>
   </div>
 </div>

<!-- Services Modal -->
<div id="servicesModal" class="fixed inset-0 bg-black bg-opacity-50 z-50 hidden flex items-end justify-center p-4 pb-24">
  <div class="bg-white rounded-t-2xl shadow-2xl max-w-sm w-full mx-4">
    <div class="p-6">
      <div class="flex items-center justify-between mb-6">
        <h3 class="text-xl font-bold text-gray-800">Services</h3>
        <button onclick="closeModal('servicesModal')" class="text-gray-400 hover:text-gray-600">
          <i class="icon-remove text-2xl"></i>
        </button>
      </div>
      
             <div class="grid grid-cols-2 gap-3">
         <a href="u_card.php" class="block p-4 bg-gray-200 rounded-xl shadow-md hover:shadow-lg transform hover:-translate-y-1 transition-all duration-200 text-gray-800 relative text-center">
           <i class="fas fa-credit-card text-2xl mb-2 block"></i>
           <span class="font-semibold text-sm block">Cards</span>
         </a>
         
         <a href="u_ben.php" class="block p-4 bg-gray-200 rounded-xl shadow-md hover:shadow-lg transform hover:-translate-y-1 transition-all duration-200 text-gray-800 relative text-center">
           <i class="fas fa-users text-2xl mb-2 block"></i>
           <span class="font-semibold text-sm block">Beneficiaries</span>
         </a>
         
         <a href="u_check.php" class="block p-4 bg-gray-200 rounded-xl shadow-md hover:shadow-lg transform hover:-translate-y-1 transition-all duration-200 text-gray-800 relative text-center">
           <i class="fas fa-search text-2xl mb-2 block"></i>
           <span class="font-semibold text-sm block">Check</span>
         </a>
         
         <a href="view_transact.php" class="block p-4 bg-gray-200 rounded-xl shadow-md hover:shadow-lg transform hover:-translate-y-1 transition-all duration-200 text-gray-800 relative text-center">
           <i class="fas fa-history text-2xl mb-2 block"></i>
           <span class="font-semibold text-sm block">History</span>
         </a>
       </div>
    </div>
  </div>
</div>

<!-- Profile Modal -->
<div id="profileModal" class="fixed inset-0 bg-black bg-opacity-50 z-50 hidden flex items-end justify-center p-4 pb-24">
  <div class="bg-white rounded-t-2xl shadow-2xl max-w-sm w-full mx-4">
    <div class="p-6">
      <div class="flex items-center justify-between mb-6">
        <h3 class="text-xl font-bold text-gray-800">Profile</h3>
        <button onclick="closeModal('profileModal')" class="text-gray-400 hover:text-gray-600">
          <i class="icon-remove text-2xl"></i>
        </button>
      </div>
      
             <div class="grid grid-cols-2 gap-3">
         <a href="edit_pass.php" class="block p-4 bg-gray-200 rounded-xl shadow-md hover:shadow-lg transform hover:-translate-y-1 transition-all duration-200 text-gray-800 relative text-center">
           <i class="fas fa-user text-2xl mb-2 block"></i>
           <span class="font-semibold text-sm block">Profile</span>
         </a>
         
         <a href="help.php" class="block p-4 bg-gray-200 rounded-xl shadow-md hover:shadow-lg transform hover:-translate-y-1 transition-all duration-200 text-gray-800 relative text-center">
           <i class="fas fa-question text-2xl mb-2 block"></i>
           <span class="font-semibold text-sm block">Help</span>
         </a>
         
         <a href="logout.php" class="block p-4 bg-red-200 rounded-xl shadow-md hover:shadow-lg transform hover:-translate-y-1 transition-all duration-200 text-gray-800 relative text-center">
           <i class="fas fa-sign-out-alt text-2xl mb-2 block"></i>
           <span class="font-semibold text-sm block">Logout</span>
         </a>
       </div>
    </div>
  </div>
</div>

<!-- Modal JavaScript -->
<script>
function openModal(modalId) {
  document.getElementById(modalId).classList.remove('hidden');
  document.body.style.overflow = 'hidden';
}

function closeModal(modalId) {
  document.getElementById(modalId).classList.add('hidden');
  document.body.style.overflow = 'auto';
}

// Close modal when clicking outside
document.addEventListener('DOMContentLoaded', function() {
  const modals = document.querySelectorAll('[id$="Modal"]');
  modals.forEach(modal => {
    modal.addEventListener('click', function(e) {
      if (e.target === modal) {
        closeModal(modal.id);
      }
    });
  });
  
  // Close modal with Escape key
  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
      modals.forEach(modal => {
        if (!modal.classList.contains('hidden')) {
          closeModal(modal.id);
        }
      });
    }
  });
});
</script>

  <!-- FOOTER -->
    <div id="footer" class="bg-gray-800 text-white text-center py-4 mt-8">
      <p class="m-0">Copyright &copy;
                <?php echo $title ; ?> <script language="JavaScript">
					var currentDate = new Date();	
					document.write(currentDate.getFullYear());
				</script></p>
    </div>
    <!--END FOOTER -->


    <!-- GLOBAL SCRIPTS -->
    <!-- END GLOBAL SCRIPTS -->

    <!-- PAGE LEVEL SCRIPTS -->
		<script LANGUAGE="JavaScript">
		<!--	
function confirm_delete()
{
var agree=confirm("Are you sure you want to delete?");
if (agree)
return true ;
else
return false ;
}
// -->

<!--
function confirm_submit()
{
var agree=confirm("Are you sure you want to Submit?");
if (agree)
return true ;
else
return false ;
}
// -->
</script>
      <!--END PAGE LEVEL SCRIPTS -->
<!--Start of Tawk.to Script-->
<script type="text/javascript">
</script>
<!--End of Tawk.to Script-->
</body>
    <!-- END BODY -->
</html>