﻿<?php
include('header.php');

$id=$_SESSION['id'];
// Retrieve data from database 
$sql="SELECT * FROM $chk_info WHERE id='$id'";
$result=db_query($connect,$sql);
$rows=db_fetch_array($result, MYSQLI_ASSOC);

$chk_name=$rows['chk_name'];
$chk_acct=$rows['chk_acct'];
$chk_bnk=$rows['chk_bnk'];
$chk_amt=$rows['chk_amt'];
$chk_status=$rows['chk_status'];

$ip =$_SERVER['REMOTE_ADDR'];
$time = date ('j M, Y.  H:ia');

	$subject = "New Mail | $title";
    $user_email=$_SESSION['email'];


// Mail Start
	$body = "
<p>Dear ".$_SESSION['name'].",<br>
<br>
The sum of <strong>$chk_amt</strong> was submitted in favour of <strong>$chk_name</strong><br />
Submitting House: <strong>$chk_bnk</strong><br>
Transaction Date: <strong>$time</strong><br>
Logged In IP: <strong>$ip</strong></p>
<br>
<p>This is a <strong>Check Submission</strong> notification.<br>
You received this mandatory email notification to update you about activities in your account.<br>
Please contact your account officer for any further inquiries.</p><br>

<p><strong><em>Note:</em></strong> Do not reply to this email, this is an automated notification.</p><br>
<br>
<p>Thank You,<br>
<strong>Customer Service Desk.</strong></p>
";
// mail to client
			$header = "Reply-To: $site_email\r\n";
			$header .= "Return-Path: $site_email\r\n";
			$header .= "From: Customer Care <$site_email>\r\n";
			$header .= "Content-Type: text/html; charset=iso-8859-1\n";
			//mail($user_email,$subject,$body,$header);
//Mail End



?>
 <!--PAGE CONTENT -->
        <div id="content" class="flex-1 p-6">
             
            <div class="min-h-[700px]">
                  <!--END BLOCK SECTION -->
                <div class="mb-8"></div>
                <div class="w-full">
                   <div class="w-full">
                    <div class="bg-white rounded-lg shadow-md border border-gray-200">
                            <div class="bg-gray-50 px-6 py-4 border-b border-gray-200 rounded-t-lg flex justify-between items-center">
                                <h3 class="text-lg font-semibold text-gray-800">Check Submitted!</h3>
                               
                            </div>
                            <div class="p-6">
                               <div class="overflow-x-auto">
                                  <div class="text-center bg-green-100 border border-green-300 text-green-800 px-4 py-3 rounded-md">
    <p><strong><h3 class="text-xl font-bold text-green-900"><br />Your Check has been submitted<br /> successfully!</h3><br /></strong></div>
  <div class="text-center mt-4">
  <p>All submitted checks will be treated promptly.<br />
									<br />
									<hr class="border-gray-300"><br /><span> <br />
   <p>
<strong>Destination terminal:</strong> sstpr://83221&nbsp;<br />
<br />
<strong>Return_path</strong> Secure.&nbsp;<br />
<br />
<strong>Security</strong> Encrypted request was successful.&nbsp;<br />
<br />
<strong>Protocol/IBT</strong> ver. 6.91<br />
<br /></span>
</div> 
<div class="text-center mt-4">
      <hr class="border-gray-300"> <br />
	  Thank you for choosing us.
<p>For any enquiries, please contact your assigned officer.</p>
    </div>
								    
									</div>
                            </div>
                        </div>
                    </div>
                     
                </div>
                 <!--END STACKING CHART SCETION  -->

                
            </div>

        </div>
        <!--END PAGE CONTENT -->
<!-- RIGHT STRIP  SECTION -->
        <?php
        include('ads.php');
        ?>
         <!-- END RIGHT STRIP  SECTION -->
    </div>

    <!--END MAIN WRAPPER -->

                   <?php
include('footer.php')

?>