﻿<?php
include('header.php');
// Retrieve data from database 
$sql="SELECT * FROM $data";
$result=db_query($connect,$sql);
$rows=db_fetch_array($result, MYSQLI_ASSOC);

?>

        <!--PAGE CONTENT -->
        <div id="content" class="flex-1 p-6">
             
            <div class="min-h-[700px]">
                  <!--END BLOCK SECTION -->
                <div class="mb-8"></div>
                <div class="w-full">
                   <div class="w-full">
                    <div class="bg-white rounded-lg shadow-md border border-gray-200">
                            <div class="bg-gray-50 px-6 py-4 border-b border-gray-200 rounded-t-lg flex justify-between items-center">
                             <h3 class="text-lg font-semibold text-gray-800">Contact / Support</h3>
                             <button onclick="history.back()" class="bg-blue-500 hover:bg-blue-600 text-white font-normal py-2 px-2 rounded-md transition-colors duration-150 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 flex items-center gap-2">
                                 <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                     <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path>
                                 </svg>
                                 Back
                             </button>
                            </div>
                            <div class="p-6">
                                <p class="text-gray-700 mb-4">To find out more, queries or apply for a product service, use the direct contact details below.</p>
	  <p class="text-gray-700 mb-4">These helplines are for Holders of International Premium Accounts.</p>
	  <div class="mb-4"></div>
	  <p class="text-gray-700"><strong class="font-semibold">Details:</strong> <span class="text-gray-900"><?php echo $rows['contact']; ?></span></p>
                            </div>
                        </div>
                    </div>
                     
                </div>
                 <!--END STACKING CHART SCETION  -->

                
            </div>

        </div>
        <!--END PAGE CONTENT -->

         <!-- RIGHT STRIP  SECTION -->
        <?php
        include('ads.php');
        ?>
         <!-- END RIGHT STRIP  SECTION -->
    </div>

    <!--END MAIN WRAPPER -->

                   <?php
include('footer.php')

?>