﻿<?php
include('header.php');
// get value of id that sent from address bar
$id=$_SESSION['id'];
// Retrieve data from database 
$sql="SELECT * FROM $tbl_name WHERE id=$id";
$result=db_query($connect,$sql);
$rows=db_fetch_array($result, MYSQLI_ASSOC);

?>

        <!--PAGE CONTENT -->
        <div id="content" class="flex-1 p-6">
             
            <div class="min-h-[700px]">
                  <!--END BLOCK SECTION -->
            <div class="mb-8"></div>
				<div class="text-center">
			  <?php
include($user);
?>	
			</div>
			<div class="mb-8"></div>
			<form action="" method="post"> 
                <div class="w-full">
                   <div class="w-full">
                    <div class="bg-white rounded-lg shadow-md border border-gray-200">
                            <div class="bg-gray-50 px-6 py-4 border-b border-gray-200 rounded-t-lg flex justify-between items-center">
                               <h3 class="text-lg font-semibold text-gray-800">Compose Message</h3>
                               <button onclick="history.back()" class="bg-blue-500 hover:bg-blue-600 text-white font-normal py-2 px-2 rounded-md transition-colors duration-150 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 flex items-center gap-2">
                                   <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                       <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path>
                                   </svg>
                                   Back
                               </button>
                            </div>
                            <div class="p-6">
                                <div class="overflow-x-auto">
<div class="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-6">
  <div class="">
	<label class="block text-sm font-medium text-gray-700 mb-2">From: </label>
	<input name="m_from" type="text" value="<?php echo $rows['name']; ?>" readonly="readonly" class="w-full px-3 py-2 border border-gray-300 rounded-md bg-gray-50 text-gray-500" /></div>
    <div class="">
	<label class="block text-sm font-medium text-gray-700 mb-2">To: </label>
	<input name="m_to" type="text" value="Accounts Officer" readonly="readonly" class="w-full px-3 py-2 border border-gray-300 rounded-md bg-gray-50 text-gray-500"  /></div>
	<div class="">
	<label class="block text-sm font-medium text-gray-700 mb-2">Date: </label>
	<input type="text" value="<?php $date =date ('j M, Y'); print $date; ?>" readonly="readonly" class="w-full px-3 py-2 border border-gray-300 rounded-md bg-gray-50 text-gray-500"  /></div>
  </div>
<div class="mb-4">
  <label class="block text-sm font-medium text-gray-700 mb-2">Subject:</label>
  <input type="text"  name="m_subject"  placeholder="Subject" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" required=""/>
</div>
<div class="mb-6">
                            <label class="block text-sm font-medium text-gray-700 mb-2">Message: </label>
                            <textarea id="wysihtml5" name="m_message"  cols="55" rows="10" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" required="" placeholder="Hi,"></textarea>
							<input name="id" type="hidden" value="<?php echo $rows['id']; ?>"/>
              </div >
			  <div class="text-right">
			  <button type="submit" class="bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 px-4 rounded-md transition-colors duration-150 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2" name="sendmssg" onclick="return confirm_submit()" >Send Message</button></div>
			  
                                </div>
                            </div>
                        </div>
                    </div>
                     
                </div>
				</form>
                 <!--END STACKING CHART SCETION  -->

                
            </div>

        </div>
        <!--END PAGE CONTENT -->

         <!-- RIGHT STRIP  SECTION -->
        <?php
        include('ads.php');
        ?>
         <!-- END RIGHT STRIP  SECTION -->
    </div>

    <!--END MAIN WRAPPER -->

                   <?php
include('footer.php')

?>