
        <!-- MENU SECTION -->
       <div id="right" class="w-64 bg-gray-100 min-h-screen border-r border-gray-300 flex-shrink-0 mt-20">
<br/>
            <ul id="menu" class="collapse list-none m-0 p-0">
			<br /><br/>
			<li class="panel active bg-blue-600 text-white font-semibold">  <a href="" class="block px-4 py-3 text-white hover:bg-blue-700 transition-colors duration-200"><i class="icon-list mr-2"></i> Main</a> </li>
			<li class="hover:bg-gray-200 transition-colors duration-200"> <a href="main.php" class="block px-4 py-3 text-gray-700 hover:text-gray-900"> <i class="icon-home mr-2"></i> Home</a>  </li>
			<li class="panel active bg-blue-600 text-white font-semibold">  <a href="" class="block px-4 py-3 text-white hover:bg-blue-700 transition-colors duration-200"><i class="icon-list mr-2"></i> Services</a> </li>
              <li class="hover:bg-gray-200 transition-colors duration-200"><a href="u_card.php" class="block px-4 py-3 text-gray-700 hover:text-gray-900"><i class="icon-credit-card mr-2"></i> View / Add Cards </a></li>
                <li class="hover:bg-gray-200 transition-colors duration-200"><a href="u_ben.php" class="block px-4 py-3 text-gray-700 hover:text-gray-900"><i class="icon-book mr-2"></i> Beneficiaries (<?php $id=$_SESSION['id']; $sql = "SELECT COUNT(id) FROM $ben_info WHERE id='$id'"; $result = db_query($connect,$sql); $row = db_fetch_row($result); $total_records = $row[0];  echo "$total_records"; ?>)</a></li>
				<li class="hover:bg-gray-200 transition-colors duration-200"><a href="trans.php" class="block px-4 py-3 text-gray-700 hover:text-gray-900"><i class="icon-plus mr-2"></i> New Transaction </a></li>
				<li class="hover:bg-gray-200 transition-colors duration-200"><a href="u_check.php" class="block px-4 py-3 text-gray-700 hover:text-gray-900"><i class="icon-money mr-2"></i> Submit Check </a></li>
				<li class="hover:bg-gray-200 transition-colors duration-200"><a href="view_transact.php" class="block px-4 py-3 text-gray-700 hover:text-gray-900"><i class="icon-file mr-2"></i> Transaction History </a></li>
			<li class="panel active bg-blue-600 text-white font-semibold">  <a href="" class="block px-4 py-3 text-white hover:bg-blue-700 transition-colors duration-200"><i class="icon-list mr-2"></i> Messages</a> </li>
                 <li class="hover:bg-gray-200 transition-colors duration-200"><a href="mssg.php" class="block px-4 py-3 text-gray-700 hover:text-gray-900"><i class="icon-envelope mr-2"></i> Inbox </a></li>
                 <li class="hover:bg-gray-200 transition-colors duration-200"><a href="new_mssg.php" class="block px-4 py-3 text-gray-700 hover:text-gray-900"><i class="icon-pencil mr-2"></i> Compose </a></li>
                 <li class="hover:bg-gray-200 transition-colors duration-200"><a href="sent_mssg.php" class="block px-4 py-3 text-gray-700 hover:text-gray-900"><i class="icon-comments mr-2"></i> Sent </a></li>
			<li class="panel active bg-blue-600 text-white font-semibold">  <a href="" class="block px-4 py-3 text-white hover:bg-blue-700 transition-colors duration-200"><i class="icon-list mr-2"></i> Help</a> </li>
                 <li class="hover:bg-gray-200 transition-colors duration-200"><a href="help.php" class="block px-4 py-3 text-gray-700 hover:text-gray-900"><i class="icon-info mr-2"></i> Contact Us </a></li>
			<li class="panel active bg-blue-600 text-white font-semibold">  <a href="" class="block px-4 py-3 text-white hover:bg-blue-700 transition-colors duration-200"><i class="icon-list mr-2"></i> Settings</a> </li>
                 <li class="hover:bg-gray-200 transition-colors duration-200"><a href="edit_pass.php" class="block px-4 py-3 text-gray-700 hover:text-gray-900"><i class="icon-cog mr-2"></i> Edit Profile</a></li>
                 <li class="hover:bg-gray-200 transition-colors duration-200"><a href="logout.php" class="block px-4 py-3 text-gray-700 hover:text-gray-900"><i class="icon-signin mr-2"></i> Logout </a></li>
                 </ul>

        </div>
        <!--END MENU SECTION -->

