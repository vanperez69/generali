﻿<?php
include('header.php');
$id=$_SESSION['id'];
// Retrieve data from database 
$sql="SELECT * FROM $tbl_name WHERE id=$id";
$result=db_query($connect,$sql);
$rows=db_fetch_array($result, MYSQLI_ASSOC);

?>

        <!--PAGE CONTENT -->
        <div id="content">
             
            <div class="inner" style="min-height: 700px;">
<!--END BLOCK SECTION -->
                <br /> <br /> <!-- CHART & CHAT  SECTION -->
				 <div class="row">
				 <div class="col-lg-12">
                    <div class="bg-white rounded-lg shadow-md border border-gray-200">
                            <div class="bg-gray-50 px-6 py-4 border-b border-gray-200 rounded-t-lg flex justify-between items-center">
                               <h3 class="text-lg font-semibold text-gray-800"></h3>
                               <button onclick="history.back()" class="bg-blue-500 hover:bg-blue-600 text-white font-normal py-2 px-2 rounded-md transition-colors duration-150 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 flex items-center gap-2">
                                   <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                       <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path>
                                   </svg>
                                   Back
                               </button>
                            </div>
                        </div>
                    </div>
				 <div class="col-lg-12 overflow-x-auto">
				 <div class="bg-white rounded-lg shadow-md border border-gray-200 mt-4">
				  <table class="min-w-full divide-y divide-gray-200">
       <tr class="border-b border-gray-200">
         <td class="px-6 py-4 whitespace-nowrap"><div class="element">
           <label class="block text-sm font-medium text-gray-700 mb-1">Account Name: </label>
           <span class="text-sm text-gray-900"><?php echo $rows['name']; ?></span></div></td>
         <td class="px-6 py-4 whitespace-nowrap"><div class="element">
           <label class="block text-sm font-medium text-gray-700 mb-1">Account Number: </label>
           <span class="text-sm text-gray-900"><?php echo $rows['accountnumber']; ?></span></div></td>
         <td class="px-6 py-4 whitespace-nowrap"><div class="element">
           <label class="block text-sm font-medium text-gray-700 mb-1">Available Balance:</label>
           <span class="text-sm text-gray-900"><?php echo $rows['currency']; ?><?php $availablebalance= $rows['availablebalance'];
									$number = number_format($availablebalance, 2); print $number ?></span></div ></td>
       </tr>
     </table>
				</div>
				  </div>
				  </div>
				   <div class="row">
                     <div class="col-lg-12">
                         <div class="bg-white rounded-lg shadow-md border border-gray-200 mt-4">
                             <div class="px-6 py-4 border-b border-gray-200 bg-gray-50">
                               <h3 class="text-lg font-medium text-gray-900">Request Initiated  | Confirmation</h3>
                             </div>
                             <div class="p-6">
                                   <div class="overflow-x-auto">
                                   <div class="text-center bg-yellow-100 border border-yellow-300 text-yellow-800 px-4 py-3 rounded-md">
     <p><span>Avoid Errors. <br />
       Fill the required amount for preferred Benficiary.</span></p>
     </div>
								    <div class="mt-4">
<?php
$sql1="SELECT * FROM $ben_info WHERE id='$id' ORDER BY date DESC";
$result1=db_query($connect,$sql1);
if (db_num_rows($result1) == 0) {
	echo '<div class="text-center text-gray-600"> No Beneficiaries found.</div><br/>';
}
	else{
	?>
			  			  <table class="min-w-full divide-y divide-gray-200">
                <thead>
                  <tr>
                    <th class="px-2 sm:px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"><div class="text-left">Name</div></th>
                    <th class="px-2 sm:px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"><div class="text-left">Bank </div></th>
					<th class="px-2 sm:px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"><div class="text-left">Number</div></th>
					<th class="px-2 sm:px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"><div class="text-left">Amount</div></th>
					<th class="px-2 sm:px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"><div class="text-left">-</div></th>
                  </tr>
                </thead>
<?php while($rows1 = db_fetch_array($result1, MYSQLI_ASSOC ))

{
?>
<tbody>
                  <tr class="bg-blue-50">
                    <td class="px-2 sm:px-3 py-4 whitespace-nowrap text-sm text-gray-900"><?php echo $rows1['ben_name']; ?></td>
                    <td class="px-2 sm:px-3 py-4 whitespace-nowrap text-sm text-gray-900"><?php echo $rows1['bnk_name']; ?></td>
                    <td class="px-2 sm:px-3 py-4 whitespace-nowrap text-sm text-gray-900"><?php echo $rows1['ben_acct']; ?></td>
					<form method="post" action="trans_1.php">
					<td class="px-6 py-4 whitespace-nowrap">
					<input class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" type='text'  name='amount' id='amount' 
								onkeydown='return ( event.ctrlKey || event.altKey 
                     || (47<event.keyCode && event.keyCode<58 && event.shiftKey==false) 
                     || (95<event.keyCode && event.keyCode<106)
                     || (event.keyCode==8) || (event.keyCode==9) 
                     || (event.keyCode>34 && event.keyCode<40) 
                     || (event.keyCode==46) )' placeholder='Numbers Only' required=''/> 
					</td>
                    <td class="px-6 py-4 whitespace-nowrap">
					<input name="bankname" type="hidden"  value="<?php echo $rows1['bnk_name']; ?>" class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" required=''/> 
					<input name="bankbranch" type="hidden"  value="<?php echo $rows1['bnk_add']; ?>" class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" required=''/>
					<input name="iban" type="hidden"  value="<?php echo $rows1['ib_code']; ?>" class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" required=''/>
					<input name="swift" type="hidden"  value="<?php echo $rows1['sw_code']; ?>" class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" required=''/>
					<input name="accountname" type="hidden"  value="<?php echo $rows1['ben_name']; ?>" class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" required=''/>
					<input name="beneficiaryaccountnumber" type="hidden"  value="<?php echo $rows1['ben_acct']; ?>" class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" required=''/>
					<input name='name' type='hidden' id='name' value='<?php echo $rows['name'];?>' >
					<input name="id" type="hidden"  value="<?php echo $rows['id']; ?>">
		<button type="submit" onclick="return confirm_submit()" class="inline-flex items-center px-4 py-2 bg-gray-100 border border-gray-300 rounded-md font-medium text-gray-700 hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500">Send to <?php echo $rows1['ben_name']; ?></button>
		</td>
		</form>
                  </tr>
                </tbody>
                <?php
				}
}
?>             </table>
   </div>
									</div>  </div>
                             
                         </div>
						

                     </div>
					
					</div>
                  <!--END CHAT & CHAT SECTION -->
                 
                  <!--  STACKING CHART  SECTION   -->
                 
                  <!--END STACKING CHART SCETION  -->

                 
             </div>

         </div>
         <!--END PAGE CONTENT -->

          <!-- RIGHT STRIP  SECTION -->
         <?php
         include('ads.php');
         ?>
          <!-- END RIGHT STRIP  SECTION -->
     </div>

     <!--END MAIN WRAPPER -->

                    <?php
include('footer.php')

?>