﻿<?php
include('header.php');
?>

        <!--PAGE CONTENT -->
        <div id="content" class="flex-1 p-6">
             
            <div class="min-h-[700px]">
                  <!--END BLOCK SECTION -->
                <div class="mb-8"></div>
                <div class="w-full">
                   <div class="w-full">
                    <div class="bg-white rounded-lg shadow-md border border-gray-200">
                            <div class="bg-gray-50 px-6 py-4 border-b border-gray-200 rounded-t-lg flex justify-between items-center">
                               <h3 class="text-lg font-semibold text-gray-800">Inbox Messages</h3>
                               <button onclick="history.back()" class="bg-blue-500 hover:bg-blue-600 text-white font-normal py-2 px-2 rounded-md transition-colors duration-150 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 flex items-center gap-2">
                                   <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                       <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path>
                                   </svg>
                                   Back
                               </button>
                            </div>
                            <div class="p-6">
                                <div class="overflow-x-auto">
<?php
$id=$_SESSION['id'];
$sql="SELECT * FROM $mail  WHERE id='$id' AND m_type='inbox' ORDER BY m_date DESC ";
$result=db_query($connect,$sql);						
if (db_num_rows($result) == 0) {
	echo '<div class="text-center text-gray-500 py-8">No Messages found.</div>';
}
	else{

?>  <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                  <tr>
				  <th class="px-2 sm:px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
				     <th class="px-2 sm:px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Subject</th>
                    <th class="hidden sm:table-cell px-2 sm:px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">From</th>
					<th class="px-2 sm:px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Message</th>
                    <th class="hidden md:table-cell px-2 sm:px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Type</th>
					<th class="hidden md:table-cell px-2 sm:px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                  </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
<?php while($rows = db_fetch_array($result, MYSQLI_ASSOC ))

{
?>
                  <tr class="hover:bg-gray-50 transition-colors duration-150">
				  <td class="px-2 sm:px-3 py-4 whitespace-nowrap text-sm text-gray-900"><?php echo date ('j M, Y', strtotime ($rows['m_date'])); ?></td>
				    <td class="px-2 sm:px-3 py-4 whitespace-nowrap text-sm text-gray-900"><a href="mssg_detail.php?id=<?php echo $rows['mssg_id']; ?>" title="View Message" class="text-blue-600 hover:text-blue-800 hover:underline transition-colors duration-150"><?php echo $rows['m_subject']; ?></a></td>
				  <td class="hidden sm:table-cell px-2 sm:px-3 py-4 whitespace-nowrap text-sm text-gray-900"><?php echo $rows['m_from']; ?></td>
				  <td class="px-2 sm:px-3 py-4 text-sm text-gray-900"><a href="mssg_detail.php?id=<?php echo $rows['mssg_id']; ?>" title="View Message" class="text-blue-600 hover:text-blue-800 hover:underline transition-colors duration-150"><?php echo substr($rows['m_message'],0,40); ?>...</a></td>
                    <td class="hidden md:table-cell px-2 sm:px-3 py-4 whitespace-nowrap text-sm text-gray-900"><?php echo $rows['m_type']; ?></td>
                  	<td class="hidden md:table-cell px-2 sm:px-3 py-4 whitespace-nowrap text-sm text-gray-900"><?php echo $rows['m_status']; ?></td>
					</tr>
                <?php
}
}
?>

              </tbody>
              </table>
			  <div class="text-right mt-6">
			  <button type="submit" class="bg-gray-500 hover:bg-gray-600 text-white font-medium py-2 px-4 rounded-md transition-colors duration-150 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2" onclick="window.print();return false;">Print</button></div>
			  
                                </div>
                            </div>
                        </div>
                    </div>
                     
                </div>
                 <!--END STACKING CHART SCETION  -->

                
            </div>

        </div>
        <!--END PAGE CONTENT -->

         <!-- RIGHT STRIP  SECTION -->
        <?php
        include('ads.php');
        ?>
         <!-- END RIGHT STRIP  SECTION -->
    </div>

    <!--END MAIN WRAPPER -->

                   <?php
include('footer.php')

?>