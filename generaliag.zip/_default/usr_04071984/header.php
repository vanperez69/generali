<?php
session_start();
require_once('../ad_panel/inc/config.php'); 
	
	// set inactive timing to 30minutes of idileness
	$inactive = 30*30;
	 
	if (isset($_SESSION["timeout"])) {
	    // calculate the session's "time to live"
	    $sessionTTL = time() - (int)$_SESSION["timeout"];
	    if ($sessionTTL > $inactive) {
	        session_destroy();
	        header("Location: index.php");
			exit();
	    }
	}
	 
	$_SESSION["timeout"] = time();
	
	
if(!isset($_SESSION['userid'])){
     header( 'Location: index.php' );
}
?>
<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9"> <![endif]-->
<!--[if !IE]><!--> <html lang="en"> <!--<![endif]-->
<!-- BEGIN HEAD -->
<head>
    <meta charset="UTF-8" />
<title>Signed In | <?php echo $_SESSION['name']; ?> - <?php echo $title ; ?></title>
     <meta content="width=device-width, initial-scale=1.0" name="viewport" />
     <!--[if IE]>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <![endif]-->
    <!-- GLOBAL STYLES -->
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="assets/plugins/Font-Awesome/css/font-awesome.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<link rel="stylesheet" href="assets/plugins/daterangepicker/daterangepicker-bs3.css" />
<link rel="stylesheet" href="assets/plugins/datepicker/css/datepicker.css" />
<link rel="stylesheet" href="assets/plugins/timepicker/css/bootstrap-timepicker.min.css" />
<link rel="stylesheet" href="assets/plugins/switch/static/stylesheets/bootstrap-switch.css" />
    <link rel="stylesheet" href="assets/plugins/magic/magic.css" />
<link rel="shortcut icon" href="assets/img/favicon.png">
     <link rel="stylesheet" href="assets/plugins/wysihtml5/dist/bootstrap-wysihtml5-0.0.2.css" />
    <link rel="stylesheet" href="assets/css/bootstrap-wysihtml5-hack.css" />
     <style>
                        ul.wysihtml5-toolbar > li {
                            position: relative;
                        }
                        
                        /* Custom layout fixes for Tailwind */
                        @media (max-width: 1024px) {
                            #left {
                                position: fixed;
                                left: -100%;
                                transition: left 0.3s ease;
                                z-index: 40;
                                top: 80px;
                            }
                            #left.show {
                                left: 0;
                            }
                            #content {
                                margin-left: 0 !important;
                                width: 100% !important;
                            }
                            #menu_icons {
                                margin-left: 0 !important;
                                width: 100% !important;
                            }
                        }
                        
                        /* Large screen layout */
                        @media (min-width: 1025px) {
                            #left {
                                position: relative !important;
                                left: 0 !important;
                                display: block !important;
                                width: 256px !important;
                                flex-shrink: 0 !important;
                                visibility: visible !important;
                                opacity: 1 !important;
                            }
                            #content {
                                margin-left: 0 !important;
                                flex: 1;
                            }
                            #menu_icons {
                                margin-left: 0 !important;
                                width: 100% !important;
                            }
                        }
                        
                        /* Ensure proper flexbox behavior */
                        #wrap {
                            min-height: 100vh;
                        }
                        
                        /* Force menu visibility on large screens */
                        @media (min-width: 1025px) {
                            #left {
                                transform: none !important;
                                transition: none !important;
                            }
                        }
                        
                        /* Fix header positioning */
                        #top {
                            position: relative;
                            z-index: 50;
                        }
                        
                        /* Ensure proper content flow */
                        .inner {
                            width: 100%;
                        }
                        
                        /* Fix menu icons positioning to prevent overlap with header */
                        #menu_icons {
                            position: relative;
                            z-index: 10;
                            margin-top: 20px;
                        }
                        
                        /* Fix mobile menu positioning */
                        @media (max-width: 1024px) {
                            #left.show {
                                position: fixed;
                                top: 80px;
                                left: 0;
                                width: 280px;
                                z-index: 40;
                            }
                            
                            /* Ensure logo and profile are on same row in mobile */
                            nav {
                                display: flex;
                                justify-content: space-between;
                                align-items: center;
                            }
                            
                            header {
                                flex-shrink: 0;
                            }
                            
                            .float-right {
                                display: flex;
                                align-items: center;
                                gap: 0.5rem;
                            }
                        }
                    </style>
   
    <!--END GLOBAL STYLES -->

    <!-- PAGE LEVEL STYLES -->
    <link href="assets/css/layout2.css" rel="stylesheet" />
       <link href="assets/plugins/flot/examples/examples.css" rel="stylesheet" />
       <link rel="stylesheet" href="assets/plugins/timeline/timeline.css" />
     <link rel="stylesheet" href="assets/plugins/wysihtml5/dist/bootstrap-wysihtml5-0.0.2.css" />
    <link rel="stylesheet" href="assets/css/bootstrap-wysihtml5-hack.css" />
    <!-- END PAGE LEVEL  STYLES -->
     <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->
</head>

    <!-- END HEAD -->

    <!-- BEGIN BODY -->
<body class="pt-20">

    <!-- MAIN WRAPPER -->
    <div id="wrap" class="w-full flex">
        

        <!-- HEADER SECTION -->
        <div id="top" class="w-full">
                 <nav class="bg-gray-100 text-black fixed top-0 left-0 right-0 z-50 pt-3 px-3">
                 <!-- LOGO SECTION -->
                 <header class="inline-block">

                      <a href="index" class="inline-block">
                     &nbsp; <img src="assets/img/header_small.png" alt="" class="w-200 h-10"/>
                          
                         </a>
                  </header>
                  <!-- END LOGO SECTION -->
                <div class="float-right text-right mb-2">
                      <!-- USER PROFILE SECTION -->
                     <div class="text-right">
                         <div class="flex items-center justify-end space-x-1 mb-2">
                            <?php 
				if ($_SESSION['pic']) { 
				$img_name = $_SESSION['pic'];
				$imagepath = "<img width='30' height='30' src='../ad_panel/images/$img_name' class='rounded-full border-2 border-gray-300'>"; 
						
echo $imagepath ; 
	}
	else {
echo "<img width='30' height='30' src='../ad_panel/images/no_image.png' class='rounded-full border-2 border-gray-300'>" ; 
}	
	?> <a href="edit_pass.php" class="text-black hover:text-gray-600 transition-colors duration-200 font-medium"><?php echo $_SESSION['name']; ?></a>
                         </div>
                         
                         <!-- DATE/TIME SECTION -->
                         <div class="flex items-center justify-end space-x-1 text-sm text-gray-600">
                             <script>
var mydate=new Date()
var theYear=mydate.getFullYear()
var day=mydate.getDay()
var month=mydate.getMonth()
var daym=mydate.getDate()
if (daym<10)
daym="0"+daym
var dayarray=new Array("Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday")
var montharray=new Array("January","February","March","April","May","June","July","August","September","October","November","December")
document.write(dayarray[day]+", "+montharray[month]+" "+daym+", "+theYear)
                             </script>
                         </div>
                     </div>        
                </div>

            </nav>

        <!-- END HEADER SECTION -->

