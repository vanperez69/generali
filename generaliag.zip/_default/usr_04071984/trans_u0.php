﻿<?php
include('header.php');
$id=$_SESSION['id'];
// Retrieve data from database 
$sql="SELECT * FROM $tbl_name WHERE id=$id";
$result=db_query($connect,$sql);
$rows=db_fetch_array($result, MYSQLI_ASSOC);

?>
        <!--PAGE CONTENT -->
        <div id="content">
             
            <div class="inner" style="min-height: 700px;">
<!--END BLOCK SECTION -->
                <br /> <br /> <!-- CHART & CHAT  SECTION -->
				 <div class="row">
				 <div class="col-lg-12">
                    <div class="bg-white rounded-lg shadow-md border border-gray-200">
                            <div class="bg-gray-50 px-6 py-4 border-b border-gray-200 rounded-t-lg flex justify-between items-center">
                               <h3 class="text-lg font-semibold text-gray-800"></h3>
                               <button onclick="history.back()" class="bg-blue-500 hover:bg-blue-600 text-white font-normal py-2 px-2 rounded-md transition-colors duration-150 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 flex items-center gap-2">
                                   <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                       <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path>
                                   </svg>
                                   Back
                               </button>
                            </div>
                        </div>
                    </div>
				 <div class="col-lg-12 overflow-x-auto">
				 <div class="bg-white rounded-lg shadow-md border border-gray-200 mt-4">
				  <table class="min-w-full divide-y divide-gray-200">
      <tr class="border-b border-gray-200">
        <td class="px-6 py-4 whitespace-nowrap"><div class="element">
          <label class="block text-sm font-medium text-gray-700 mb-1">Account Name: </label>
          <span class="text-sm text-gray-900"><?php echo $rows['name']; ?></span></div></td>
        <td class="px-6 py-4 whitespace-nowrap"><div class="element">
          <label class="block text-sm font-medium text-gray-700 mb-1">Account Number: </label>
          <span class="text-sm text-gray-900"><?php echo $rows['accountnumber']; ?></span></div></td>
        <td class="px-6 py-4 whitespace-nowrap"><div class="element">
          <label class="block text-sm font-medium text-gray-700 mb-1">Available Balance:</label>
          <span class="text-sm text-gray-900"><?php echo $rows['currency']; ?><?php $availablebalance= $rows['availablebalance'];
									$number = number_format($availablebalance, 2); print $number ?></span></div ></td>
      </tr>
    </table>
				</div>
				  </div>
				  </div>
				  <form action="trans_u.php" method="post">
					
				   <div class="row">
                    <div class="col-lg-12">
                        <div class="bg-white rounded-lg shadow-md border border-gray-200 mt-4">
                            <div class="px-6 py-4 border-b border-gray-200 bg-gray-50">
                              <h3 class="text-lg font-medium text-gray-900">Request Initiated  | Confirmation</h3>
                            </div>
                            <div class="p-6">
                                  <div class="overflow-x-auto">
                                  <div class="text-center bg-yellow-100 border border-yellow-300 text-yellow-800 px-4 py-3 rounded-md">
    <p><span>Avoid Errors. <br />
      Fill the required information correctly to avoid errors and delays <br />
      in your request execution!</span></p>
    </div>
	   <div class="text-left mt-4">
      <table class="min-w-full divide-y divide-gray-200">
        <tbody>
          <tr>
            <td class="align-top px-6 py-4"><div class="element">
                <label class="block text-sm font-medium text-gray-700 mb-1">Customer ID: </label>
                <span><input type="text" value="<?php echo $rows['userid']; ?>" readonly="readonly" class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" /></span></div >
                <div class="element mt-4">
                  <label class="block text-sm font-medium text-gray-700 mb-1">Financial Institution Name:</label>
                  <input id="bankname" type="text"  name="bankname"  placeholder="Bank Name" class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" required=''/> 
                </div >
              <div class="element mt-4">
                  <label class="block text-sm font-medium text-gray-700 mb-1">Address:</label>
                  <input type="text"  name="bankbranch" id="bankbranch"  placeholder="Bank Address" class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" required=''/> 
                </div >
              <div class="element mt-4">
                  <label class="block text-sm font-medium text-gray-700 mb-1">IBAN:</label>
                  <input type="text"  name="iban" id="iban"  placeholder="IBAN" class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" />
                </div >
             </td>
            <td class="align-top px-6 py-4">
			<div class="element">
                  <label class="block text-sm font-medium text-gray-700 mb-1">Swift/Routing Number:</label>
                  <input type="text"  name="swift" id="swift"  placeholder="Swift/Routing Number" class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" />
                </div >
			<div class="element mt-4">
                <label class="block text-sm font-medium text-gray-700 mb-1">Holder's Name:</label>
                <input type="text"  name="accountname" id="accountname" placeholder="Account Holder"  class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" required=''/> 
              </div >
			<div class="element mt-4">
                <label class="block text-sm font-medium text-gray-700 mb-1">Acct. Number:</label>
                <input type="text"  name="beneficiaryaccountnumber" id="beneficiaryaccountnumber" placeholder="Account Number"  class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" required=''/> 
              </div >
                     <div class="element mt-4">
                  <label class="block text-sm font-medium text-gray-700 mb-1">Amount:</label>
                  <input type="text"  name="amount" id="amount" 
								onkeydown="return ( event.ctrlKey || event.altKey 
                    || (47&lt;event.keyCode &amp;&amp; event.keyCode&lt;58 &amp;&amp; event.shiftKey==false) 
                    || (95&lt;event.keyCode &amp;&amp; event.keyCode&lt;106)
                    || (event.keyCode==8) || (event.keyCode==9) 
                    || (event.keyCode&gt;34 &amp;&amp; event.keyCode&lt;40) 
                    || (event.keyCode==46) )" placeholder="Numbers Only" class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" required=''/> 
					<input name="id" type="hidden" id="id" value="<?php echo $rows['id']; ?>" >
					<input name="name" type="hidden" id="name" value="<?php echo $rows['name']; ?>" >
                </div >
              </td>
          </tr>
        </tbody>
      </table><div class="element mt-6">
                  <button type="submit" class="inline-flex items-center px-4 py-2 bg-gray-100 border border-gray-300 rounded-md font-medium text-gray-700 hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500" onclick="return confirm_submit()" >Confirm Request</button>
              </div>
    </div>
									</div>  </div>
                            
                        </div>
						

                    </div>
					
					</div>
					</form>
                 <!--END CHAT & CHAT SECTION -->
                
                 <!--  STACKING CHART  SECTION   -->
                
                 <!--END STACKING CHART SCETION  -->

                
            </div>

        </div>
        <!--END PAGE CONTENT -->

         <!-- RIGHT STRIP  SECTION -->
        <div id="right">

         <br /><br />
            <div class="bg-gray-100 rounded-lg p-4 border border-gray-200">
               <img src="assets/img/ad.png" />
            </div>
         
        </div>
         <!-- END RIGHT STRIP  SECTION -->
    </div>

    <!--END MAIN WRAPPER -->

                   <?php
include('footer.php')

?>