﻿<?php
include('header.php');

$id=$_SESSION['id'];
// Retrieve data from database 
$sql="SELECT * FROM $tbl_name WHERE id=$id";
$result=db_query($connect,$sql);
$rows=db_fetch_array($result, MYSQLI_ASSOC);

$balance=$rows['availablebalance'];
$currency=$rows['currency'];
$bankname=$rows['bankname'];
$accountname=$rows['accountname'];
$amount=$rows['amount'];
$phone=$rows['phone'];

$p_amount = number_format($amount, 2);
$av_balance = number_format($balance, 2);
$ip =$_SERVER['REMOTE_ADDR'];
$time = date ('j M, Y.  H:ia');

	$subject = "New Mail | $title";
    $user_email=$_SESSION['email'];


// Mail Start
	$body = "
<p>Dear ".$_SESSION['name'].",<br>
<br>
The sum of <strong>$currency$p_amount</strong> was Sent to <strong>$accountname</strong><br />
Receiving House: <strong>$bankname</strong><br>
Available Balance: <strong>$currency$av_balance</strong><br>
Transaction Date: <strong>$time</strong><br>
Logged In IP: <strong>$ip</strong></p>
<br>
<p>This is a <strong>Transaction Successful</strong> notification.<br>
You received this mandatory email notification to update you about activities in your account.<br>
Please contact your account officer for any further inquiries.</p><br>

<p><strong><em>Note:</em></strong> Do not reply to this email, this is an automated notification.</p><br>
<br>
<p>Thank You,<br>
<strong>Customer Service Desk.</strong></p>
";
// mail to client
			$header = "Reply-To: $site_email\r\n";
			$header .= "Return-Path: $site_email\r\n";
			$header .= "From: Customer Care <$site_email>\r\n";
			$header .= "Content-Type: text/html; charset=iso-8859-1\n";
			//mail($user_email,$subject,$body,$header);
//Mail End


echo "<meta http-equiv=\"refresh\" content=\"5;URL=main.php\">";

?>
        <!--PAGE CONTENT -->
        <div id="content">
             
            <div class="inner" style="min-height: 700px;">
<!--END BLOCK SECTION -->
                <br /> <br /> <!-- CHART & CHAT  SECTION -->
                 <form action="" method="post"> 
				 <div class="row">
                    <div class="col-lg-12">
                        <div class="bg-white rounded-lg shadow-md border border-gray-200">
                            <div class="px-6 py-4 border-b border-gray-200 bg-gray-50">
                              <h3 class="text-lg font-medium text-gray-900">Online Confirmation.!</h3>
                            </div>
                            <div class="p-6">
                                  <div class="overflow-x-auto">
                                  <div class="text-center bg-green-100 border border-green-300 text-green-800 px-4 py-3 rounded-md">
    <p><strong>Transaction Successful!</strong></div>
  <div class="text-center mt-4">
  <p>The sum of <strong><?php echo $rows['currency']; ?><?php $amount= $rows['amount'];
									$number = number_format($amount, 2); print $number ?></strong>.<br />
									<br />
									Was Sent To <strong><?php echo $rows['accountname']; ?> [<?php echo $rows['beneficiaryaccountnumber']; ?> ]</strong> at <?php echo $rows['bankname']; ?>.<br /><span> <br />
   <p>
<strong>Destination terminal:</strong> sstpr://83217&nbsp;<br />
<br />
<strong>Fail_return_path</strong> Secure.&nbsp;<br />
<br />
<strong>Security</strong> Encrypted request was successful.&nbsp;<br />
<br />
<strong>Protocol/IBT</strong> ver. 6.91<br />
<br /></span>
</div> 
<div class="text-center mt-4">
      <hr class="border-gray-300"> <br />
	  Thank you for choosing us.
<p>For any enquiries, please contact your assigned officer.</p>
    </div>
								    
									</div> <div class="text-right mt-6">
			  <button type="submit" class="inline-flex items-center px-4 py-2 bg-gray-100 border border-gray-300 rounded-md font-medium text-gray-700 hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500" onclick="window.print();return false;">Print</button></div>
			   </div>
                            
                        </div>
						

                    </div>
					
					</div>
					</form>
                 <!--END CHAT & CHAT SECTION -->
                
                 <!--  STACKING CHART  SECTION   -->
                
                 <!--END STACKING CHART SCETION  -->

                
            </div>

        </div>
        <!--END PAGE CONTENT -->

         <!-- RIGHT STRIP  SECTION -->
        <div id="right">

         <br /><br />
            <div class="bg-gray-100 rounded-lg p-4 border border-gray-200">
               <img src="assets/img/ad.png" />
            </div>
         
        </div>
         <!-- END RIGHT STRIP  SECTION -->
    </div>

    <!--END MAIN WRAPPER -->

                   <?php
include('footer.php')

?>