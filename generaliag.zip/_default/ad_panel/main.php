<?php
require_once('header.php');
?>
   <div class="w-full bg-white rounded-lg p-2">
    <div class="mb-2">
        <h1 class="text-xl font-bold text-gray-800 border-b-2 border-primary pb-2">Admin Dashboard</h1>
    </div>
    </div>
               
                <div class="grid grid-cols-1 xl:grid-cols-2 gap-4 sm:gap-6 lg:gap-8">
                    <div class="bg-white rounded-lg shadow-sm p-4 sm:p-6">
                        <div class="text-lg sm:text-xl font-semibold text-gray-800 mb-4 border-b border-gray-200 pb-2">Recent Accounts</div>
                        <?php
                        $sql="SELECT * FROM $tbl_name ORDER BY id DESC LIMIT 5";
                        $result=db_query($connect,$sql);
                        if (db_num_rows($result) == 0) {
                            echo '<div class="text-center text-gray-500 py-4"> No User Accounts Created.</div><br/>';
                        } else {
                        ?>
                        <div class="overflow-x-auto -mx-4 sm:mx-0">
                            <div class="inline-block min-w-full align-middle">
                                <div class="overflow-hidden shadow ring-1 ring-black ring-opacity-5 md:rounded-lg">
                                    <table class="min-w-full divide-y divide-gray-300">
                                        <thead class="bg-gray-50">
                                            <tr>
                                                <th class="px-2 sm:px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Photo</th>
                                                <th class="px-2 sm:px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                                                <th class="hidden sm:table-cell px-2 sm:px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Balance</th>
                                            </tr>
                                        </thead>
                                        <tbody class="bg-white divide-y divide-gray-200">
                                            <?php while($rows = db_fetch_array($result, MYSQLI_ASSOC)) { ?>
                                            <tr class="hover:bg-gray-50 transition duration-150">
                                                <td class="px-2 sm:px-3 py-3">
                                                    <a href="user_details.php?id=<?php echo $rows['id']; ?>" title="View Details" class="block">
                                                        <?php 
                                                        if ($rows['pic']) { 
                                                            $img_name = $rows['pic'];
                                                            $imagepath = "<img class='w-8 h-8 sm:w-10 sm:h-10 rounded-full object-cover border-2 border-gray-200' src='images/$img_name'>"; 
                                                            echo $imagepath; 
                                                        } else {
                                                            echo "<img class='w-8 h-8 sm:w-10 sm:h-10 rounded-full object-cover border-2 border-gray-200' src='images/no_image.png'>";
                                                        }	
                                                        ?>
                                                    </a>
                                                </td>
                                                <td class="px-2 sm:px-3 py-3 text-sm text-gray-900">
                                                    <div class="max-w-xs truncate">
                                                        <a href="user_details.php?id=<?php echo $rows['id']; ?>" title="View Details" class="text-primary hover:text-primary-dark font-medium transition duration-200">
                                                            <?php echo $rows['name']; ?>
                                                        </a>
                                                    </div>
                                                </td>
                                                <td class="hidden sm:table-cell px-2 sm:px-3 py-3 text-sm text-gray-700">
                                                    <div class="max-w-xs truncate">
                                                        <?php echo $rows['currency']; ?>
                                                        <?php 
                                                        $availablebalance = $rows['availablebalance'];
                                                        $number = number_format($availablebalance, 2); 
                                                        print $number; 
                                                        ?>
                                                    </div>
                                                </td>
                                            </tr>
                                            <?php } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div class="text-right mt-4">
                            <a href="view_users.php" class="bg-blue-600 hover:bg-blue-700 text-white text-sm sm:text-base font-medium py-2 px-3 sm:px-4 rounded-lg transition duration-200">View More</a>
                        </div>
                    </div>
                    <?php } ?>
                    
                    <div class="bg-white rounded-lg shadow-sm p-4 sm:p-6">
                        <div class="text-lg sm:text-xl font-semibold text-gray-800 mb-4 border-b border-gray-200 pb-2">Recent Messages</div>
                        <?php
                        $sql="SELECT * FROM $mail ORDER BY m_date DESC LIMIT 5";
                        $result=db_query($connect,$sql);
                        if (db_num_rows($result) == 0) {
                            echo '<div class="text-center text-gray-500 py-4"> No Recent Messages.</div><br/>';
                        } else {
                        ?>
                        <div class="overflow-x-auto -mx-4 sm:mx-0">
                            <div class="inline-block min-w-full align-middle">
                                <div class="overflow-hidden shadow ring-1 ring-black ring-opacity-5 md:rounded-lg">
                                    <table class="min-w-full divide-y divide-gray-300">
                                        <thead class="bg-gray-50">
                                            <tr>
                                                <th class="px-2 sm:px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Subject</th>
                                                <th class="hidden sm:table-cell px-2 sm:px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">From</th>
                                                <th class="px-2 sm:px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                                            </tr>
                                        </thead>
                                        <tbody class="bg-white divide-y divide-gray-200">
                                            <?php while($rows = db_fetch_array($result, MYSQLI_ASSOC)) { ?>
                                            <tr class="hover:bg-gray-50 transition duration-150">
                                                <td class="px-2 sm:px-3 py-3 text-sm text-gray-900">
                                                    <div class="max-w-xs truncate">
                                                        <a href="mssg_detail.php?id=<?php echo $rows['mssg_id']; ?>" title="View Message" class="text-primary hover:text-primary-dark font-medium transition duration-200">
                                                            <?php echo substr($rows['m_subject'],0,30); ?>...
                                                        </a>
                                                    </div>
                                                </td>
                                                <td class="hidden sm:table-cell px-2 sm:px-3 py-3 text-sm text-gray-900">
                                                    <div class="max-w-xs truncate">
                                                        <a href="mssg_detail.php?id=<?php echo $rows['mssg_id']; ?>" title="View Message" class="text-primary hover:text-primary-dark font-medium transition duration-200">
                                                            <?php echo $rows['m_from']; ?>
                                                        </a>
                                                    </div>
                                                </td>
                                                <td class="px-2 sm:px-3 py-3 text-sm text-gray-700">
                                                    <?php echo date ('j M, Y', strtotime ($rows['m_date'])); ?>
                                                </td>
                                            </tr>
                                            <?php } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div class="text-right mt-4">
                            <a href="mssg.php" class="bg-blue-600 hover:bg-blue-700 text-white text-sm sm:text-base font-medium py-2 px-3 sm:px-4 rounded-lg transition duration-200">View More</a>
                        </div>
                    </div>
                    <?php } ?>
                </div>
            </div>
        </div>
        
            </div>
        </div>


	<?php
include('footer.php')

?>
