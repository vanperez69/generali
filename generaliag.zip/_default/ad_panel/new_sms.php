<?php
include('header.php');
// get value of id that sent from address bar
$id=$_GET['id'];
// Retrieve data from database 
$sql="SELECT * FROM $tbl_name WHERE id='$id'";
$result=db_query($connect,$sql);
$rows=db_fetch_array($result, MYSQLI_ASSOC);

?>

    <div class="full_w" align="right">
      <div class="button"> <a href="javascript:history.back(1)">Click To Go Back</a></div>
	   <div align="center">
    <?php
include($forms);
?>
</div>
             </div>
    <div class="clear"></div>
<div class="full_w">
              <div class="h_title">Compose New SMS to <?php echo $rows['name']; ?>. </div>
			  <div align="center"><br>
			</div>
			<form action="" method="post">
			  <table>
                <tr>
                  <td>Type your message here</td></tr>
                 <tr> <td>Sending to this number <strong><?php echo $rows['phone']; ?>.</strong> Sender: <strong><?php echo $sender ?></strong> </td></tr>
                
              </table>
			  
			  <div class="element">
                            <label><em>160 Characters Only:</em> </label>
							<input name="phone" type="hidden" value="<?php echo $rows['phone']; ?>"/>
                            <textarea maxlength="160" name="message" id="message" cols="20" rows="2" class="textarea"  /></textarea><em><strong>READ THIS:</strong> Use "Notepad" to edit write up for easy sending.</em>
              </div >
						   	<div class="element" align="right">
	<button type="submit" class="add" name="sms" id="sms"onclick="return confirm_submit()" >Send SMS</button>
				<button type="reset" class="cancel" name="reset">Clear</button></div>
</form>
</div>
 
  </div>
		<div class="clear"></div>
</div>

	<?php
include('footer.php')

?>
