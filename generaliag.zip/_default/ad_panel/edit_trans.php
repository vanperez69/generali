<?php
include('header.php');
// get value of id that sent from address bar
$id=$_GET['id'];
// Retrieve data from database 
$sql="SELECT * FROM $trans WHERE trans_id='$id'";
$result=db_query($connect,$sql);
$rows=db_fetch_array($result, MYSQLI_ASSOC);

?>

<div class="w-full bg-white rounded-lg shadow-md p-6">
    <div class="flex justify-end mb-4">
        <a href="javascript:history.back(1)" class="bg-gray-600 hover:bg-gray-700 text-white font-medium py-2 px-4 rounded-lg transition duration-200">
            Click To Go Back
        </a>
        <div class="ml-4">
            <?php include($forms); ?>
        </div>
    </div>
    
    <div class="bg-gray-50 rounded-lg p-6">
        <h2 class="text-xl font-bold text-gray-800 border-b-2 border-primary pb-2 mb-6">
            Edit Transaction by <?php echo $rows['name']; ?>.
        </h2>
        
        <form action="" method="post" class="space-y-6">
            <!-- First Row -->
            <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div class="flex flex-col">
                    <input name="id" type="hidden" value="<?php echo $rows['trans_id']; ?>"/>
                    <input name="user" type="hidden" value="<?php echo $rows['id']; ?>"/>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Depositor Name:</label>
                    <input type="text" name="name" id="name" value="<?php echo $rows['name']; ?>" required="" 
                           class="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"/>
                </div>
                
                <div class="flex flex-col">
                    <label class="block text-sm font-medium text-gray-700 mb-2">Type:</label>
                    <select name="t_type" required="" 
                            class="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent">
                        <option value="<?php echo $rows['t_type']; ?>" selected="selected"><?php echo $rows['t_type']; ?></option>
                        <option value="Deposit">Deposit</option>
                        <option value="Withdrawal">Withdrawal</option>
                        <option value="ATM">ATM</option>
                        <option value="Check">Check</option>
                        <option value="Online">Online</option>
                        <option value="POS">POS</option>
                    </select>
                </div>
                
                <div class="flex flex-col">
                    <label class="block text-sm font-medium text-gray-700 mb-2">Date:</label>
                    <input type="text" class="datepicker" name="date" id="date" value="<?php echo $rows['date']; ?>" required="" 
                           class="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"/>
                </div>
            </div>
            
            <!-- Second Row -->
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div class="flex flex-col">
                    <label class="block text-sm font-medium text-gray-700 mb-2">Amount:</label>
                    <input type="text" name="balance" id="balance" 
                          oninput="
            this.value = this.value
                .replace(/[^0-9.]/g, '')            // allow only digits & .
                .replace(/(\..*)\./g, '$1')         // prevent more than one .
                .replace(/^(\d{11})(\d+)/, '$1')    // limit 11 digits before decimal
                .replace(/^(\d+)\.(\d{0,2}).*$/, '$1.$2'); // allow only 2 decimals
       "
                           value="<?php echo $rows['balance']; ?>" required="" 
                           class="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"/>
                </div>
                
                <div class="flex flex-col">
                    <label class="block text-sm font-medium text-gray-700 mb-2">Debit:</label>
                    <input type="text" name="debit" id="debit" 
                          oninput="
            this.value = this.value
                .replace(/[^0-9.]/g, '')            // allow only digits & .
                .replace(/(\..*)\./g, '$1')         // prevent more than one .
                .replace(/^(\d{11})(\d+)/, '$1')    // limit 11 digits before decimal
                .replace(/^(\d+)\.(\d{0,2}).*$/, '$1.$2'); // allow only 2 decimals
       "
                           value="<?php echo $rows['debit']; ?>" required="" 
                           class="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"/>
                </div>
            </div>
            
            <!-- Third Row -->
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div class="flex flex-col">
                    <label class="block text-sm font-medium text-gray-700 mb-2">Description:</label>
                    <textarea name="t_description" id="textarea" cols="30" rows="5" 
                              class="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent resize-none"><?php echo $rows['t_description']; ?></textarea>
                </div>
                
                <div class="flex flex-col justify-between">
                    <input name="currency" type="hidden" value="<?php echo $rows['currency']; ?>"/>
                    <div class="flex justify-end">
                        <button type="submit" name="edittransact" id="add" onclick="return confirm_submit()" 
                                class="bg-primary hover:bg-primary-dark text-white font-medium py-2 px-6 rounded-lg transition duration-200">
                            Edit Transaction
                        </button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>

    </div>
</div>
<?php
include('footer.php')
?>
