<?php
include('header.php');
// Retrieve data from database 
$sql="SELECT * FROM $data";
$result=db_query($connect,$sql);
$rows=db_fetch_array($result, MYSQLI_ASSOC);

?>
<div class="w-full bg-white rounded-lg p-2">
    <div class="flex justify-end mb-2">
        <a href="javascript:history.back(1)" class="bg-gray-600 hover:bg-gray-700 text-white font-medium py-2 px-4 rounded-lg transition duration-200">
            Click To Go Back
        </a>
    </div>
    
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <!-- View Details Section -->
        <div class="bg-gray-50 rounded-lg p-6">
            <h2 class="text-xl font-bold text-gray-800 border-b-2 border-primary pb-2 mb-4">View Details</h2>
            
            <form action="">
                <div class="space-y-4">
                    <div class="flex flex-col sm:flex-row sm:items-center">
                        <label class="block text-sm font-medium text-gray-700 mb-2 sm:mb-0 sm:w-1/3">Personal Transaction Key:</label>
                        <span class="text-gray-900 font-medium"><?php echo $rows['trans_code']; ?></span>
                    </div>
                    
                    <div class="flex flex-col sm:flex-row sm:items-center">
                        <label class="block text-sm font-medium text-gray-700 mb-2 sm:mb-0 sm:w-1/3">Tax Clearance Code:</label>
                        <span class="text-gray-900 font-medium"><?php echo $rows['tax_code']; ?></span>
                    </div>
                    
                    <div class="flex flex-col sm:flex-row sm:items-center">
                        <label class="block text-sm font-medium text-gray-700 mb-2 sm:mb-0 sm:w-1/3">IMF Clearance Code:</label>
                        <span class="text-gray-900 font-medium"><?php echo $rows['imf_code']; ?></span>
                    </div>
                    
                    <div class="flex flex-col sm:flex-row sm:items-center">
                        <label class="block text-sm font-medium text-gray-700 mb-2 sm:mb-0 sm:w-1/3">Anti-Terrorism Clearance Code:</label>
                        <span class="text-gray-900 font-medium"><?php echo $rows['ter_code']; ?></span>
                    </div>
                    
                    <div class="flex flex-col sm:flex-row sm:items-start">
                        <label class="block text-sm font-medium text-gray-700 mb-2 sm:mb-0 sm:w-1/3">Contact Details:</label>
                        <span class="text-gray-900 font-medium"><?php echo $rows['contact']; ?></span>
                    </div>
                </div>
            </form>
        </div>
        
        <!-- Edit Access Codes Section -->
        <div class="bg-gray-50 rounded-lg p-6">
            <h2 class="text-xl font-bold text-gray-800 border-b-2 border-primary pb-2 mb-4">Edit Access Codes</h2>
            
            <?php include($forms); ?>
            
            <form action="" method="post" class="space-y-4">
                <div class="flex flex-col sm:flex-row sm:items-center">
                    <label class="block text-sm font-medium text-gray-700 mb-2 sm:mb-0 sm:w-1/3">Personal Transaction Key:</label>
                    <input type="text" name="trans_code" id="trans_code" placeholder="Personal Transaction Key" required="" 
                           class="flex-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent">
                </div>
                
                <div class="flex flex-col sm:flex-row sm:items-center">
                    <label class="block text-sm font-medium text-gray-700 mb-2 sm:mb-0 sm:w-1/3">Tax Clearance Code:</label>
                    <input type="text" name="tax_code" id="tax_code" placeholder="Tax Clearance Code" required="" 
                           class="flex-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent">
                </div>
                
                <div class="flex flex-col sm:flex-row sm:items-center">
                    <label class="block text-sm font-medium text-gray-700 mb-2 sm:mb-0 sm:w-1/3">IMF Clearance Code:</label>
                    <input type="text" name="imf_code" id="imf_code" placeholder="IMF Clearance Code" required="" 
                           class="flex-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent">
                </div>
                
                <div class="flex flex-col sm:flex-row sm:items-center">
                    <label class="block text-sm font-medium text-gray-700 mb-2 sm:mb-0 sm:w-1/3">Anti-Terrorism Clearance Code:</label>
                    <input type="text" name="ter_code" id="ter_code" placeholder="Anti-Terrorism Code:" required="" 
                           class="flex-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent">
                </div>
                
                <div class="flex flex-col sm:flex-row sm:items-start">
                    <label class="block text-sm font-medium text-gray-700 mb-2 sm:mb-0 sm:w-1/3">Contact Details:</label>
                    <textarea name="contact" id="textarea" cols="30" rows="5" placeholder="Enter Telephone, Email & Address Details" 
                              class="flex-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"></textarea>
                    <input name="id" type="hidden" id="id" value="<?php echo $rows['id']; ?>">
                </div>
                
                <div class="flex justify-end">
                    <button type="submit" name="editdata" id="editdata" onclick="return confirm_submit()" 
                            class="bg-primary hover:bg-primary-dark text-white font-medium py-2 px-6 rounded-lg transition duration-200">
                        Edit Details
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
</div>
</div>

<?php
include('footer.php')
?>
