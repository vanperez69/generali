<div id="nav" class="bg-white border-b border-gray-200 shadow-sm">
    <div class="container mx-auto px-4">
        <ul class="flex flex-wrap items-center justify-start space-x-1 py-3">
            <li class="upp">
                <a href="main.php" class="inline-flex items-center px-4 py-2 text-sm font-medium text-gray-700 hover:text-primary hover:bg-gray-50 rounded-md transition duration-200 ease-in-out">
                    Home
                </a>
            </li>
            <li class="upp">
                <a href="view_users.php" class="inline-flex items-center px-4 py-2 text-sm font-medium text-gray-700 hover:text-primary hover:bg-gray-50 rounded-md transition duration-200 ease-in-out">
                    Accounts 
                    <span class="ml-2 inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                        <?php $sql = "SELECT COUNT(id) FROM $tbl_name"; $result = db_query($connect,$sql); $row = db_fetch_row($result); $total_records = $row[0]; echo "$total_records"; ?>
                    </span>
                </a>
            </li>
            <li class="upp">
                <a href="view_cards.php" class="inline-flex items-center px-4 py-2 text-sm font-medium text-gray-700 hover:text-primary hover:bg-gray-50 rounded-md transition duration-200 ease-in-out">
                    Cards 
                    <span class="ml-2 inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                        <?php $sql = "SELECT COUNT(id) FROM $c_info"; $result = db_query($connect,$sql); $row = db_fetch_row($result); $total_records = $row[0]; echo "$total_records"; ?>
                    </span>
                </a>
            </li>
            <li class="upp">
                <a href="reg.php" class="inline-flex items-center px-4 py-2 text-sm font-medium text-gray-700 hover:text-primary hover:bg-gray-50 rounded-md transition duration-200 ease-in-out">
                    Registrations 
                    <span class="ml-2 inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                        <?php $sql = "SELECT COUNT(id) FROM $sign_up"; $result = db_query($connect,$sql); $row = db_fetch_row($result); $total_records = $row[0]; echo "$total_records"; ?>
                    </span>
                </a>
            </li>
            <li class="upp">
                <a href="mssg.php" class="inline-flex items-center px-4 py-2 text-sm font-medium text-gray-700 hover:text-primary hover:bg-gray-50 rounded-md transition duration-200 ease-in-out">
                    Messages 
                    <span class="ml-2 inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                        <?php $sql = "SELECT COUNT(id) FROM $mail"; $result = db_query($connect,$sql); $row = db_fetch_row($result); $total_records = $row[0]; echo "$total_records"; ?>
                    </span>
                </a>
            </li>
            <li class="upp">
                <a href="view_transact.php" class="inline-flex items-center px-4 py-2 text-sm font-medium text-gray-700 hover:text-primary hover:bg-gray-50 rounded-md transition duration-200 ease-in-out">
                    Transactions 
                    <span class="ml-2 inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                        <?php $sql = "SELECT COUNT(id) FROM $trans"; $result = db_query($connect,$sql); $row = db_fetch_row($result); $total_records = $row[0]; echo "$total_records"; ?>
                    </span>
                </a>
            </li>
            <li class="upp">
                <a href="edit_pass.php" class="inline-flex items-center px-4 py-2 text-sm font-medium text-gray-700 hover:text-primary hover:bg-gray-50 rounded-md transition duration-200 ease-in-out">
                    Admin Details
                </a>
            </li>
        </ul>
    </div>
</div>