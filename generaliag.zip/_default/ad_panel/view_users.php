<?php
require_once('header.php');

?>
			
<div class="w-full bg-white rounded-lg p-2">
    <div class="mb-2">
        <h1 class="text-xl font-bold text-gray-800 border-b-2 border-primary pb-2">All User Accounts</h1>
    </div>
    
    <?php
    include($forms);
    ?>	
    
    <div class="border-t border-gray-200 my-6"></div>
    
    <?php
    $num_rec_per_page=10;
    if (isset($_GET["page"])) { $page  = $_GET["page"]; } else { $page=1; }; 
    $start_from = ($page-1) * $num_rec_per_page;

    $sql="SELECT * FROM $tbl_name ORDER BY id DESC LIMIT $start_from, $num_rec_per_page";
    $result=db_query($connect,$sql);
    if (db_num_rows($result) == 0) {
        echo '<div class="text-center text-gray-500 py-8 text-lg">No User Accounts found.</div>';
    }
    else{
    ?>
    
    <form name="deleteuserform" action="" method="post">
        <div class="flex flex-wrap gap-2 sm:gap-3 mb-4 sm:mb-6">
            <button name="deleteusers" type="submit" id="delete" onclick="return confirm_delete()" 
                    class="bg-red-600 hover:bg-red-700 text-white text-sm sm:text-base font-medium py-2 px-3 sm:px-4 rounded-lg transition duration-200">
                Delete Selected
            </button>
            <a onclick="javascript:checkAll('deleteuserform', true);" href="javascript:void();" 
               class="bg-blue-600 hover:bg-blue-700 text-white text-sm sm:text-base font-medium py-2 px-3 sm:px-4 rounded-lg transition duration-200">
                Select All
            </a>
            <a onclick="javascript:checkAll('deleteuserform', false);" href="javascript:void();" 
               class="bg-gray-600 hover:bg-gray-700 text-white text-sm sm:text-base font-medium py-2 px-3 sm:px-4 rounded-lg transition duration-200">
                De-Select All
            </a>
        </div>
        
        <div class="overflow-x-auto -mx-6 sm:mx-0">
            <div class="inline-block min-w-full align-middle">
                <div class="overflow-hidden shadow ring-1 ring-black ring-opacity-5 md:rounded-lg">
                    <table class="min-w-full divide-y divide-gray-300">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-2 sm:px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-12">-</th>
                                <th class="px-2 sm:px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Photo</th>
                                <th class="px-2 sm:px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                                <th class="hidden md:table-cell px-2 sm:px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Address</th>
                                <th class="px-2 sm:px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Balance</th>
                                <th class="px-2 sm:px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Edit</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <?php while($rows = db_fetch_array($result, MYSQLI_ASSOC)) { ?>
                            <tr class="hover:bg-gray-50 transition duration-150">
                                <td class="px-2 sm:px-3 py-4 whitespace-nowrap w-12">
                                    <input name="deleteusersselect[<?php echo $rows['id']; ?>]" type="checkbox" 
                                           id="checkbox[<?php echo $rows['id']; ?>]" value="<?php echo $rows['id']; ?>" 
                                           class="h-4 w-4 text-primary focus:ring-primary border-gray-300 rounded">
                                </td>
                                <td class="px-2 sm:px-3 py-4 whitespace-nowrap">
                                    <a href="user_details.php?id=<?php echo $rows['id']; ?>" title="View Details" 
                                       class="text-primary hover:text-primary-dark transition duration-200">
                                        <?php 
                                        if ($rows['pic']) { 
                                            $img_name = $rows['pic'];
                                            $imagepath = "<img class='w-8 h-8 sm:w-10 sm:h-10 md:w-12 md:h-12 rounded-full object-cover border-2 border-gray-200' src='images/$img_name'>"; 
                                            echo $imagepath ; 
                                        }
                                        else {
                                            echo "<img class='w-8 h-8 sm:w-10 sm:h-10 md:w-12 md:h-12 rounded-full object-cover border-2 border-gray-200' src='images/no_image.png'>" ; 
                                        }	
                                        ?>
                                    </a>
                                </td>
                                <td class="px-2 sm:px-3 py-4 text-sm text-gray-900">
                                    <div class="max-w-xs truncate">
                                        <a href="user_details.php?id=<?php echo $rows['id']; ?>" title="View Details" 
                                           class="text-primary hover:text-primary-dark font-medium transition duration-200">
                                            <?php echo $rows['name']; ?>
                                        </a>
                                    </div>
                                </td>
                                <td class="hidden md:table-cell px-2 sm:px-3 py-4 text-sm text-gray-900">
                                    <div class="max-w-xs truncate">
                                        <a href="user_details.php?id=<?php echo $rows['id']; ?>" title="View Details" 
                                           class="text-primary hover:text-primary-dark transition duration-200">
                                            <?php echo $rows['address']; ?>, <?php echo $rows['city']; ?>, <?php echo $rows['country']; ?>
                                        </a>
                                    </div>
                                </td>
                                <td class="px-2 sm:px-3 py-4 whitespace-nowrap text-sm text-gray-900">
                                    <?php echo $rows['currency']; ?><?php $availablebalance= $rows['availablebalance'];
                                    $number = number_format($availablebalance, 2); print $number ?>
                                </td>
                                <td class="px-2 sm:px-3 py-4 whitespace-nowrap">
                                    <a href="edit_user.php?id=<?php echo $rows['id']; ?>" title="Edit" 
                                       class="text-primary hover:text-primary-dark font-medium transition duration-200 text-sm sm:text-base">Edit</a>
                                </td>
                            </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </form>
    
    <?php } ?>
    
    <!-- Pagination -->
    <div class="mt-8 flex justify-center">
        <nav class="flex items-center space-x-1">
            <?php 
            $rs_sql = "SELECT * FROM $tbl_name"; 
            $rs_result = db_query($connect,$rs_sql);
            $total_records = db_num_rows($rs_result);
            $total_pages = ceil($total_records / $num_rec_per_page); 

            echo "<a href='view_users.php?page=1' class='px-3 py-2 text-sm font-medium text-gray-500 bg-white border border-gray-300 rounded-l-md hover:bg-gray-50 hover:text-gray-700 transition duration-200'>First &laquo;</a>";

            for ($i=1; $i<=$total_pages; $i++) { 
                $activeClass = ($i == $page) ? 'bg-primary text-white border-primary' : 'text-gray-500 bg-white border-gray-300 hover:bg-gray-50 hover:text-gray-700';
                echo "<a href='view_users.php?page=".$i."' class='px-3 py-2 text-sm font-medium border-t border-b ".$activeClass." transition duration-200'>".$i."</a>"; 
            }; 
            
            echo "<a href='view_users.php?page=$total_pages' class='px-3 py-2 text-sm font-medium text-gray-500 bg-white border border-gray-300 rounded-r-md hover:bg-gray-50 hover:text-gray-700 transition duration-200'>Last &raquo;</a>"; 
            ?>
        </nav>
    </div>
</div>
</div>
</div>
<?php
include('footer.php')
?>
