<?php
/**
 * JSON Database Viewer
 * Browse and manage your JSON database visually
 */

require_once('inc/config.php');

$dbFile = 'database/qqunion_database.json';
$json = file_get_contents($dbFile);
$database = json_decode($json, true);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>JSON Database Viewer</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
            background: #f5f5f5;
            padding: 20px;
        }
        .container {
            max-width: 1400px;
            margin: 0 auto;
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            border-radius: 8px 8px 0 0;
        }
        .header h1 { margin-bottom: 10px; }
        .header p { opacity: 0.9; }
        .tabs {
            display: flex;
            background: #f8f9fa;
            border-bottom: 2px solid #e9ecef;
            overflow-x: auto;
        }
        .tab {
            padding: 15px 25px;
            cursor: pointer;
            border: none;
            background: none;
            font-size: 14px;
            font-weight: 500;
            color: #6c757d;
            white-space: nowrap;
            transition: all 0.3s;
        }
        .tab:hover { background: #e9ecef; }
        .tab.active {
            background: white;
            color: #667eea;
            border-bottom: 3px solid #667eea;
        }
        .tab-content {
            padding: 30px;
            display: none;
        }
        .tab-content.active { display: block; }
        .stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-bottom: 30px;
        }
        .stat-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            border-radius: 8px;
            text-align: center;
        }
        .stat-number {
            font-size: 36px;
            font-weight: bold;
            margin-bottom: 5px;
        }
        .stat-label {
            font-size: 14px;
            opacity: 0.9;
        }
        .table-wrapper {
            overflow-x: auto;
            border-radius: 8px;
            border: 1px solid #e9ecef;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            background: white;
        }
        th {
            background: #f8f9fa;
            padding: 15px;
            text-align: left;
            font-weight: 600;
            color: #495057;
            border-bottom: 2px solid #e9ecef;
            position: sticky;
            top: 0;
        }
        td {
            padding: 12px 15px;
            border-bottom: 1px solid #e9ecef;
            color: #212529;
        }
        tr:hover { background: #f8f9fa; }
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #6c757d;
        }
        .empty-state svg {
            width: 64px;
            height: 64px;
            margin-bottom: 15px;
            opacity: 0.5;
        }
        .badge {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: 500;
        }
        .badge-success { background: #d4edda; color: #155724; }
        .badge-warning { background: #fff3cd; color: #856404; }
        .badge-danger { background: #f8d7da; color: #721c24; }
        .badge-info { background: #d1ecf1; color: #0c5460; }
        .actions {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
        }
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 500;
            transition: all 0.3s;
        }
        .btn-primary {
            background: #667eea;
            color: white;
        }
        .btn-primary:hover { background: #5568d3; }
        .btn-danger {
            background: #dc3545;
            color: white;
        }
        .btn-danger:hover { background: #c82333; }
        .truncate {
            max-width: 200px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🗄️ JSON Database Viewer</h1>
            <p>Browse and manage your database records</p>
        </div>

        <div class="stats">
            <?php
            $tables = ['admin', 'users', 'trans', 'mail', 'ben_info', 'chk_info', 'c_info', 'sign_up', 'data'];
            $totalRecords = 0;
            foreach ($tables as $table) {
                $count = count($database[$table]);
                $totalRecords += $count;
            }
            ?>
            <div class="stat-card">
                <div class="stat-number"><?php echo $totalRecords; ?></div>
                <div class="stat-label">Total Records</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?php echo count($tables); ?></div>
                <div class="stat-label">Tables</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?php echo round(filesize($dbFile) / 1024, 2); ?> KB</div>
                <div class="stat-label">Database Size</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?php echo date('H:i', filemtime($dbFile)); ?></div>
                <div class="stat-label">Last Updated</div>
            </div>
        </div>

        <div class="tabs">
            <?php foreach ($tables as $index => $table): ?>
                <button class="tab <?php echo $index === 0 ? 'active' : ''; ?>" 
                        onclick="showTab('<?php echo $table; ?>')">
                    <?php echo ucfirst(str_replace('_', ' ', $table)); ?>
                    <span class="badge badge-info"><?php echo count($database[$table]); ?></span>
                </button>
            <?php endforeach; ?>
            <button class="tab" onclick="showTab('meta')">
                Metadata
            </button>
        </div>

        <?php foreach ($tables as $index => $table): ?>
            <div id="<?php echo $table; ?>" class="tab-content <?php echo $index === 0 ? 'active' : ''; ?>">
                <div class="actions">
                    <button class="btn btn-primary" onclick="location.reload()">
                        🔄 Refresh
                    </button>
                </div>

                <?php if (empty($database[$table])): ?>
                    <div class="empty-state">
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                                  d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4"></path>
                        </svg>
                        <h3>No Records Found</h3>
                        <p>This table is empty</p>
                    </div>
                <?php else: ?>
                    <div class="table-wrapper">
                        <table>
                            <thead>
                                <tr>
                                    <?php
                                    $keys = array_keys($database[$table][0]);
                                    foreach ($keys as $key): ?>
                                        <th><?php echo ucfirst(str_replace('_', ' ', $key)); ?></th>
                                    <?php endforeach; ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($database[$table] as $row): ?>
                                    <tr>
                                        <?php foreach ($keys as $key): ?>
                                            <td>
                                                <?php 
                                                $value = $row[$key] ?? '-';
                                                if (strlen($value) > 100) {
                                                    echo '<div class="truncate" title="' . htmlspecialchars($value) . '">';
                                                    echo htmlspecialchars(substr($value, 0, 100)) . '...';
                                                    echo '</div>';
                                                } else {
                                                    echo htmlspecialchars($value);
                                                }
                                                ?>
                                            </td>
                                        <?php endforeach; ?>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>

        <div id="meta" class="tab-content">
            <h2>Database Metadata</h2>
            <div class="table-wrapper" style="margin-top: 20px;">
                <table>
                    <thead>
                        <tr>
                            <th>Table</th>
                            <th>Last ID</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($database['_meta']['last_ids'] as $table => $lastId): ?>
                            <tr>
                                <td><?php echo ucfirst(str_replace('_', ' ', $table)); ?></td>
                                <td><?php echo $lastId; ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <div style="margin-top: 30px; padding: 20px; background: #f8f9fa; border-radius: 8px;">
                <p><strong>Version:</strong> <?php echo $database['_meta']['version']; ?></p>
                <p><strong>Last Updated:</strong> <?php echo $database['_meta']['last_updated']; ?></p>
                <p><strong>Database File:</strong> <?php echo $dbFile; ?></p>
            </div>
        </div>
    </div>

    <script>
        function showTab(tabName) {
            // Hide all tab contents
            document.querySelectorAll('.tab-content').forEach(content => {
                content.classList.remove('active');
            });
            
            // Remove active class from all tabs
            document.querySelectorAll('.tab').forEach(tab => {
                tab.classList.remove('active');
            });
            
            // Show selected tab content
            document.getElementById(tabName).classList.add('active');
            
            // Add active class to clicked tab
            event.target.classList.add('active');
        }
    </script>
</body>
</html>