<?php
include('header.php');
// get value of id that sent from address bar
$id=$_GET['id'];

// Retrieve data from database 
$sql="SELECT * FROM $sign_up WHERE id='$id'";
$result=db_query($connect,$sql);
$rows=db_fetch_array($result, MYSQLI_ASSOC);

?>
<form action="" method="post">
    <div class="w-full bg-white rounded-lg shadow-md p-4 sm:p-6">
        <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
            <a href="javascript:history.back(1)" class="bg-gray-600 hover:bg-gray-700 text-white text-sm sm:text-base font-medium py-2 px-3 sm:px-4 rounded-lg transition duration-200 w-full sm:w-auto text-center">
                Click To Go Back
            </a>
            <div class="w-full sm:w-auto">
                <?php include($forms); ?>
            </div>
        </div>
        
        <div class="mb-6">
            <h1 class="text-xl sm:text-2xl font-bold text-gray-800 border-b-2 border-primary pb-2">
                Registration Information for <?php echo $rows['firstname']; ?> <?php echo $rows['lastname']; ?>
            </h1>
        </div>
        
        <div class="grid grid-cols-1 xl:grid-cols-2 gap-4 sm:gap-6">
            <!-- Personal Information Section -->
            <div class="bg-gray-50 rounded-lg p-4 sm:p-6">
                <h2 class="text-lg sm:text-xl font-bold text-gray-800 border-b-2 border-primary pb-2 mb-4">Personal Information</h2>
                
                <div class="space-y-3">
                    <div class="flex flex-col">
                        <strong class="text-gray-700 text-sm sm:text-base mb-1">Full Name:</strong>
                        <span class="text-gray-900 text-sm sm:text-base break-words">
                            <?php echo $rows['firstname']; ?> <?php echo $rows['lastname']; ?>
                        </span>
                    </div>
                    
                    <div class="flex flex-col">
                        <strong class="text-gray-700 text-sm sm:text-base mb-1">Email Address:</strong>
                        <span class="text-gray-900 text-sm sm:text-base break-words">
                            <?php echo $rows['email']; ?>
                        </span>
                    </div>
                    
                    <div class="flex flex-col">
                        <strong class="text-gray-700 text-sm sm:text-base mb-1">Phone Number:</strong>
                        <span class="text-gray-900 text-sm sm:text-base break-words">
                            <?php echo $rows['phone']; ?>
                        </span>
                    </div>
                    
                    <div class="flex flex-col">
                        <strong class="text-gray-700 text-sm sm:text-base mb-1">Username:</strong>
                        <span class="text-gray-900 text-sm sm:text-base break-words">
                            <?php echo $rows['username']; ?>
                        </span>
                    </div>
                    
                    <div class="flex flex-col">
                        <strong class="text-gray-700 text-sm sm:text-base mb-1">Password:</strong>
                        <span class="text-gray-900 text-sm sm:text-base break-words">
                            <?php echo $rows['password']; ?>
                        </span>
                    </div>
                    
                    <div class="flex flex-col">
                        <strong class="text-gray-700 text-sm sm:text-base mb-1">Date Of Birth:</strong>
                        <span class="text-gray-900 text-sm sm:text-base break-words">
                            <?php echo date ('j M, Y', strtotime ($rows['dateofbirth'])); ?>
                        </span>
                    </div>
                </div>
                
                <input name="id" type="hidden" id="id" value="<?php echo $rows['id']; ?>">
            </div>
            
            <!-- Address & Additional Information Section -->
            <div class="bg-gray-50 rounded-lg p-4 sm:p-6">
                <h2 class="text-lg sm:text-xl font-bold text-gray-800 border-b-2 border-primary pb-2 mb-4">Address & Additional Information</h2>
                
                <div class="space-y-3">
                    <div class="flex flex-col">
                        <strong class="text-gray-700 text-sm sm:text-base mb-1">Address:</strong>
                        <span class="text-gray-900 text-sm sm:text-base break-words">
                            <?php echo $rows['address']; ?>, <?php echo $rows['city']; ?>
                        </span>
                    </div>
                    
                    <div class="flex flex-col">
                        <strong class="text-gray-700 text-sm sm:text-base mb-1">State:</strong>
                        <span class="text-gray-900 text-sm sm:text-base break-words">
                            <?php echo $rows['state']; ?>
                        </span>
                    </div>
                    
                    <div class="flex flex-col">
                        <strong class="text-gray-700 text-sm sm:text-base mb-1">Country:</strong>
                        <span class="text-gray-900 text-sm sm:text-base break-words">
                            <?php echo $rows['country']; ?>
                        </span>
                    </div>
                    
                    <div class="flex flex-col">
                        <strong class="text-gray-700 text-sm sm:text-base mb-1">ID Number:</strong>
                        <span class="text-gray-900 text-sm sm:text-base break-words">
                            <?php echo $rows['idcard']; ?>
                        </span>
                    </div>
                    
                    <div class="flex flex-col">
                        <strong class="text-gray-700 text-sm sm:text-base mb-1">Agree Terms:</strong>
                        <span class="text-gray-900 text-sm sm:text-base break-words">
                            <?php echo $rows['agree']; ?>
                        </span>
                    </div>
                    
                    <div class="flex flex-col">
                        <strong class="text-gray-700 text-sm sm:text-base mb-1">Date Submitted:</strong>
                        <span class="text-gray-900 text-sm sm:text-base break-words">
                            <?php echo date ('j M, Y', strtotime ($rows['date'])); ?>
                        </span>
                    </div>
                </div>
                
                <div class="flex justify-end mt-6">
                    <button type="submit" onclick="return confirm_delete()" name="deleteregs" 
                            class="bg-red-600 hover:bg-red-700 text-white text-sm sm:text-base font-medium py-2 px-3 sm:px-4 rounded-lg transition duration-200">
                        Delete Registration
                    </button>
                </div>
            </div>
        </div>
    </div>
</form>

<?php
include('footer.php')
?>
