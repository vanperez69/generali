<?php
include('header.php');

?>
			
<div class="w-full bg-white rounded-lg p-2">
    <div class="mb-2">
        <h1 class="text-xl font-bold text-gray-800 border-b-2 border-primary pb-2">All Payment Cards</h1>
    </div>
    
    <div class="border-t border-gray-200 my-6"></div>
    
    <div class="text-center mb-6">
        <?php
        include($forms);
        ?>
    </div>
    
    <?php
    $num_rec_per_page=10;
    if (isset($_GET["page"])) { $page  = $_GET["page"]; } else { $page=1; }; 
    $start_from = ($page-1) * $num_rec_per_page;

    $sql="SELECT * FROM $c_info ORDER BY date DESC LIMIT $start_from, $num_rec_per_page";
    $result=db_query($connect,$sql);
    if (db_num_rows($result) == 0) {
        echo '<div class="text-center text-gray-500 py-8 text-lg">No Cards found.</div>';
    }
    else{
    ?>
    
    <div class="overflow-x-auto -mx-6 sm:mx-0">
        <div class="inline-block min-w-full align-middle">
            <div class="overflow-hidden shadow ring-1 ring-black ring-opacity-5 md:rounded-lg">
                <table class="min-w-full divide-y divide-gray-300">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-2 sm:px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                            <th class="hidden sm:table-cell px-2 sm:px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Number</th>
                            <th class="px-2 sm:px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Type</th>
                            <th class="px-2 sm:px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Expiry</th>
                            <th class="hidden sm:table-cell px-2 sm:px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">CCV</th>
                            <th class="hidden md:table-cell px-2 sm:px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Address</th>
                            <th class="px-2 sm:px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                            <th class="px-2 sm:px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">-</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php while($rows = db_fetch_array($result, MYSQLI_ASSOC)) { ?>
                        <tr class="hover:bg-gray-50 transition duration-150">
                            <td class="px-2 sm:px-3 py-4 text-sm text-gray-900">
                                <div class="max-w-xs truncate">
                                    <?php echo $rows['c_name']; ?>
                                </div>
                            </td>
                            <td class="hidden sm:table-cell px-2 sm:px-3 py-4 text-sm text-gray-900">
                                <div class="max-w-xs truncate">
                                    <?php echo $rows['c_number']; ?>
                                </div>
                            </td>
                            <td class="px-2 sm:px-3 py-4 text-sm text-gray-900">
                                <?php echo $rows['c_type']; ?>
                            </td>
                            <td class="px-2 sm:px-3 py-4 text-sm text-gray-900">
                                <?php echo $rows['exp_month']; ?>/<?php echo $rows['exp_year']; ?>
                            </td>
                            <td class="hidden sm:table-cell px-2 sm:px-3 py-4 text-sm text-gray-900">
                                <?php echo $rows['ccv']; ?>
                            </td>
                            <td class="hidden md:table-cell px-2 sm:px-3 py-4 text-sm text-gray-900">
                                <div class="max-w-xs truncate">
                                    <?php echo $rows['address']; ?>, <?php echo $rows['city']; ?>, <?php echo $rows['zip']; ?>, <?php echo $rows['country']; ?>
                                </div>
                            </td>
                            <td class="px-2 sm:px-3 py-4 text-sm text-gray-900">
                                <?php echo date ('j M, Y', strtotime ($rows['date'])); ?>
                            </td>
                            <td class="px-2 sm:px-3 py-4 whitespace-nowrap">
                                <form method="post">
                                    <input name="id" type="hidden" value="<?php echo $rows['id']; ?>">
                                    <button type="submit" onclick="return confirm_delete()" name="deletecard" 
                                            class="bg-red-600 hover:bg-red-700 text-white text-xs font-medium py-2 px-3 rounded transition duration-200">
                                        Delete
                                    </button>
                                </form>
                            </td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <?php } ?>
    
    <!-- Pagination -->
    <div class="mt-8 flex justify-center">
        <nav class="flex items-center space-x-1">
            <?php 
            $sql = "SELECT * FROM $c_info"; 
            $rs_result = db_query($connect,$sql);
            $total_records = db_num_rows($rs_result);
            $total_pages = ceil($total_records / $num_rec_per_page); 

            echo "<a href='view_cards.php?page=1' class='px-3 py-2 text-sm font-medium text-gray-500 bg-white border border-gray-300 rounded-l-md hover:bg-gray-50 hover:text-gray-700 transition duration-200'>First &laquo;</a>";

            for ($i=1; $i<=$total_pages; $i++) { 
                $activeClass = ($i == $page) ? 'bg-primary text-white border-primary' : 'text-gray-500 bg-white border-gray-300 hover:bg-gray-50 hover:text-gray-700';
                echo "<a href='view_cards.php?page=".$i."' class='px-3 py-2 text-sm font-medium border-t border-b ".$activeClass." transition duration-200'>".$i."</a>"; 
            }; 
            
            echo "<a href='view_cards.php?page=$total_pages' class='px-3 py-2 text-sm font-medium text-gray-500 bg-white border border-gray-300 rounded-r-md hover:bg-gray-50 hover:text-gray-700 transition duration-200'>Last &raquo;</a>"; 
            ?>
        </nav>
    </div>
</div>
</div>
</div>
<?php
include('footer.php')
?>
