<?php
include('header.php');
$admin_id=$_SESSION['admin_id'];
// Retrieve data from database 
$sql="SELECT * FROM $admin WHERE admin_id=$admin_id";
$result=db_query($connect,$sql);
$rows=db_fetch_array($result, MYSQLI_ASSOC);
?>

<div class="w-full bg-white rounded-lg p-2">
    <div class="flex justify-end mb-2">
        <a href="javascript:history.back(1)" class="bg-gray-600 hover:bg-gray-700 text-white font-medium py-2 px-4 rounded-lg transition duration-200">
            Click To Go Back
        </a>
    </div>
    
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <!-- View Details Section -->
        <div class="bg-gray-50 rounded-lg p-6">
            <h2 class="text-xl font-bold text-gray-800 border-b-2 border-primary pb-2 mb-4">View Details</h2>
            
            <form class="space-y-4">
                <div class="flex flex-col sm:flex-row sm:items-center">
                    <label class="block text-sm font-medium text-gray-700 mb-2 sm:mb-0 sm:w-1/3">Account Name:</label>
                    <span class="text-gray-900 font-medium"><?php echo $rows['name']; ?></span>
                </div>
                
                <div class="flex flex-col sm:flex-row sm:items-center">
                    <label class="block text-sm font-medium text-gray-700 mb-2 sm:mb-0 sm:w-1/3">Username:</label>
                    <span class="text-gray-900 font-medium"><?php echo $rows['userid']; ?></span>
                </div>
                
                <div class="flex flex-col sm:flex-row sm:items-center">
                    <label class="block text-sm font-medium text-gray-700 mb-2 sm:mb-0 sm:w-1/3">Password:</label>
                    <span class="text-gray-900 font-medium"><?php echo $rows['accesscode']; ?></span>
                </div>
            </form>
        </div>
        
        <!-- Edit Admin Details Section -->
        <div class="bg-gray-50 rounded-lg p-6">
            <h2 class="text-xl font-bold text-gray-800 border-b-2 border-primary pb-2 mb-4">Edit Admin Details</h2>
            
            <div class="text-center mb-4">
                <?php include($forms); ?>
            </div>
            
            <form action="" method="post" class="space-y-4">
                <div class="bg-yellow-50 border-l-4 border-yellow-400 p-4 mb-4">
                    <p class="text-sm text-yellow-700">*Ensure to Use entries you will remember and always keep your password private.</p>
                </div>
                
                <div class="flex flex-col sm:flex-row sm:items-center">
                    <label class="block text-sm font-medium text-gray-700 mb-2 sm:mb-0 sm:w-1/3">Account Name:</label>
                    <input type="text" name="name" id="name" placeholder="Account Name" required="" 
                           class="flex-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent">
                </div>
                
                <div class="flex flex-col sm:flex-row sm:items-center">
                    <label class="block text-sm font-medium text-gray-700 mb-2 sm:mb-0 sm:w-1/3">Username:</label>
                    <input type="text" name="userid" id="userid" placeholder="Username" required="" 
                           class="flex-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent">
                </div>
                
                <div class="flex flex-col sm:flex-row sm:items-center">
                    <label class="block text-sm font-medium text-gray-700 mb-2 sm:mb-0 sm:w-1/3">Password:</label>
                    <input type="text" name="accesscode" id="accesscode" placeholder="Password" required="" 
                           class="flex-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent">
                    <input name="admin_id" type="hidden" id="admin_id" value="<?php echo $rows['admin_id']; ?>">
                </div>
                
                <div class="flex justify-end">
                    <button type="submit" name="editadmin" id="add" onclick="return confirm_submit()" 
                            class="bg-primary hover:bg-primary-dark text-white font-medium py-2 px-6 rounded-lg transition duration-200">
                        Edit Admin Details
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
</div>
</div>

<?php
include('footer.php')
?>
