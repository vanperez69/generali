<?php
include('header.php');
// get value of id that sent from address bar
$id=$_GET['id'];

// Retrieve data from database 
$sql="SELECT * FROM $tbl_name WHERE id='$id'";
$result=db_query($connect,$sql);
$rows=db_fetch_array($result, MYSQLI_ASSOC);

?>
<form action="" method="post" enctype="multipart/form-data">
    <div class="w-full bg-white rounded-lg shadow-md p-4 sm:p-6">
         <div class="flex justify-end mb-4">
            <a href="javascript:history.back(1)" class="bg-gray-600 hover:bg-gray-700 text-white font-medium py-2 px-4 rounded-lg transition duration-200">
            Click To Go Back
        </a>
        <div class="ml-4">
            <?php include($forms); ?>
        </div>
        </div>
        
        <div class="grid grid-cols-1 xl:grid-cols-2 gap-4 sm:gap-6">
            <!-- Customer Information Section -->
            <div class="bg-gray-50 rounded-lg p-4 sm:p-6">
                <h2 class="text-lg sm:text-xl font-bold text-gray-800 border-b-2 border-primary pb-2 mb-4">Customer Information</h2>
                
                <div class="space-y-4">
                    <div class="text-center">
                        <?php 
                        if ($rows['pic']) { 
                            $img_name = $rows['pic'];
                            $imagepath = "<img class='w-24 h-24 sm:w-32 sm:h-32 md:w-40 md:h-40 rounded-full object-cover border-4 border-gray-200 mx-auto' src='images/$img_name'>"; 
                            echo $imagepath ; 
                        }
                        else {
                            echo "<img class='w-24 h-24 sm:w-32 sm:h-32 md:w-40 md:h-40 rounded-full object-cover border-4 border-gray-200 mx-auto' src='images/no_image.png'>" ; 
                        }	
                        ?>
                    </div>
                    
                    <div class="text-center">
                        <input name="photo" type="file" class="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-primary file:text-white hover:file:bg-primary-dark" />
                        <button type="submit" name="pic_update" onclick="return confirm_submit()" 
                                class="mt-2 bg-primary hover:bg-primary-dark text-white text-sm sm:text-base font-medium py-2 px-3 sm:px-4 rounded-lg transition duration-200">
                            Update Photo
                        </button>
                    </div>
                    
                    <div class="space-y-3">
                        <div class="flex flex-col">
                            <strong class="text-gray-700 text-sm sm:text-base mb-1">Full Name:</strong>
                            <span class="text-gray-900 text-sm sm:text-base break-words"><?php echo $rows['name']; ?></span>
                        </div>
                        
                        <div class="flex flex-col">
                            <strong class="text-gray-700 text-sm sm:text-base mb-1">Address:</strong>
                            <span class="text-gray-900 text-sm sm:text-base break-words"><?php echo $rows['address']; ?>, <?php echo $rows['city']; ?>, <?php echo $rows['country']; ?></span>
                        </div>
                        
                        <div class="flex flex-col">
                            <strong class="text-gray-700 text-sm sm:text-base mb-1">Email Address:</strong>
                            <span class="text-gray-900 text-sm sm:text-base break-words"><?php echo $rows['email']; ?></span>
                        </div>
                        
                        <div class="flex flex-col">
                            <strong class="text-gray-700 text-sm sm:text-base mb-1">Phone Number:</strong>
                            <span class="text-gray-900 text-sm sm:text-base break-words"><?php echo $rows['phone']; ?></span>
                        </div>
                        
                        <div class="flex flex-col">
                            <strong class="text-gray-700 text-sm sm:text-base mb-1">Customer ID:</strong>
                            <span class="text-gray-900 text-sm sm:text-base break-words"><?php echo $rows['userid']; ?></span>
                        </div>
                        
                        <div class="flex flex-col">
                            <strong class="text-gray-700 text-sm sm:text-base mb-1">Password:</strong>
                            <span class="text-gray-900 text-sm sm:text-base break-words"><?php echo $rows['password']; ?></span>
                        </div>
                        
                        <div class="flex flex-col">
                            <strong class="text-gray-700 text-sm sm:text-base mb-1">OTP Code:</strong>
                            <span class="text-gray-900 text-sm sm:text-base break-words"><?php echo $rows['userotp']; ?></span>
                        </div>
                        
                        <div class="flex flex-col">
                            <strong class="text-gray-700 text-sm sm:text-base mb-1">Account Number:</strong>
                            <span class="text-gray-900 text-sm sm:text-base break-words"><?php echo $rows['accountnumber']; ?></span>
                        </div>
                        
                        <div class="flex flex-col">
                            <strong class="text-gray-700 text-sm sm:text-base mb-1">Account Type:</strong>
                            <span class="text-gray-900 text-sm sm:text-base break-words"><?php echo $rows['a_type']; ?></span>
                        </div>
                        
                        <div class="flex flex-col">
                            <strong class="text-gray-700 text-sm sm:text-base mb-1">Available Balance:</strong>
                            <span class="text-gray-900 text-sm sm:text-base break-words"><?php echo $rows['currency']; ?><?php $availablebalance= $rows['availablebalance'];
                            $number = number_format($availablebalance, 2); print $number ?></span>
                        </div>
                        
                        <div class="flex flex-col">
                            <strong class="text-gray-700 text-sm sm:text-base mb-1">Transfer Settings:</strong>
                            <span class="text-gray-900 text-sm sm:text-base">
                                <?php if($rows['trans']  == 0){
                                    echo "<span class='inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800'>Successful After Code Request(s).</span>";
                                }
                                else if ($rows['trans']  == 1){
                                    echo "<span class='inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800'>Successful. Only once.</span>";
                                } 
                                else if ($rows['trans']  == 2){
                                    echo "<span class='inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800'>Transfer Disabled.</span>";
                                }
                                else if ($rows['trans']  == 3){
                                    echo "<span class='inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800'>Transfer Unsuccessful.</span>";
                                } ?>
                            </span>
                        </div>
                        
                        <div class="flex flex-col">
                            <strong class="text-gray-700 text-sm sm:text-base mb-1">Last Login:</strong>
                            <span class="text-gray-900 text-sm sm:text-base break-words">
                                <?php if($rows['lastlogin']  == null){
                                    echo "Never Logged In";
                                }
                                else{
                                    echo date ('j M, Y', strtotime ($rows['lastlogin']));
                                }?>
                            </span>
                        </div>
                    </div>
                    
                    <input name="id" type="hidden" id="id" value="<?php echo $rows['id']; ?>">
                    
                    <div class="flex flex-col sm:flex-row gap-2 justify-end">
                        <a href="edit_user.php?id=<?php echo $rows['id']; ?>" 
                           class="bg-primary hover:bg-primary-dark text-white text-sm sm:text-base font-medium py-2 px-3 sm:px-4 rounded-lg transition duration-200 text-center">
                            Edit Account
                        </a>
                        <button type="submit" onclick="return confirm_delete()" name="deleteuser" 
                                class="bg-red-600 hover:bg-red-700 text-white text-sm sm:text-base font-medium py-2 px-3 sm:px-4 rounded-lg transition duration-200">
                            Delete Account
                        </button>
                    </div>
                </div>
            </div>
            
            <!-- Recent Deposit Section -->
            <div class="bg-gray-50 rounded-lg p-4 sm:p-6">
                <h2 class="text-lg sm:text-xl font-bold text-gray-800 border-b-2 border-primary pb-2 mb-4">Recent Deposit</h2>
                
                <div class="space-y-3 mb-4">
                    <div class="flex flex-col">
                        <strong class="text-gray-700 text-sm sm:text-base mb-1">Depositor:</strong>
                        <span class="text-gray-900 text-sm sm:text-base break-words"><?php echo $rows['sender']; ?></span>
                    </div>
                    
                    <div class="flex flex-col">
                        <strong class="text-gray-700 text-sm sm:text-base mb-1">Amount Deposited:</strong>
                        <span class="text-gray-900 text-sm sm:text-base break-words"><?php echo $rows['currency']; ?><?php $credit= $rows['credit'];
                        $number = number_format($credit, 2); print $number ?></span>
                    </div>
                    
                    <div class="flex flex-col">
                        <strong class="text-gray-700 text-sm sm:text-base mb-1">Date Deposited:</strong>
                        <span class="text-gray-900 text-sm sm:text-base break-words"><?php echo date ('j M, Y', strtotime ($rows['datesent'])); ?></span>
                    </div>
                </div>
                
                <form action="" method="post" class="space-y-4">
                    <div class="flex flex-col">
                        <strong class="text-gray-700 text-sm sm:text-base mb-2">Depositor:</strong>
                        <input type="text" name="sender" id="sender" value="<?php echo $rows['sender']; ?>" 
                               class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent text-sm sm:text-base"/>
                    </div>
                    
                    <div class="flex flex-col">
                        <strong class="text-gray-700 text-sm sm:text-base mb-2">Amount:</strong>
                        <input type="text" name="credit"
       oninput="
            this.value = this.value
                .replace(/[^0-9.]/g, '')            // allow only digits & .
                .replace(/(\..*)\./g, '$1')         // prevent more than one .
                .replace(/^(\d{11})(\d+)/, '$1')    // limit 11 digits before decimal
                .replace(/^(\d+)\.(\d{0,2}).*$/, '$1.$2'); // allow only 2 decimals
       "
       value="<?php $credit= $rows['credit']; $number = number_format($credit, 2); print $number ?>"
       class="w-full px-3 py-2 border border-gray-300 rounded-md 
              focus:outline-none focus:ring-2 focus:ring-blue-500 
              focus:border-transparent"/>
                    </div>
                    
                    <div class="flex flex-col">
                        <strong class="text-gray-700 text-sm sm:text-base mb-2">Date:</strong>
                        <input type="text" class="datepicker" name="datesent" value="<?php echo date ('j M, Y', strtotime ($rows['datesent'])); ?>" 
                               class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent text-sm sm:text-base"/>
                        <input name="id" type="hidden" value="<?php echo $rows['id']; ?>">
                    </div>
                    
                    <div class="flex justify-end">
                        <button type="submit" onclick="return confirm_submit()" name="edit_deposit" 
                                class="bg-primary hover:bg-primary-dark text-white text-sm sm:text-base font-medium py-2 px-3 sm:px-4 rounded-lg transition duration-200">
                            Edit Deposit
                        </button>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- Online Transfer Attempt Section -->
        <div class="bg-gray-50 rounded-lg p-4 sm:p-6 mt-4 sm:mt-6">
            <h2 class="text-lg sm:text-xl font-bold text-gray-800 border-b-2 border-primary pb-2 mb-4">Online Transfer Attempt</h2>
            
            <div class="space-y-3">
                <div class="flex flex-col">
                    <strong class="text-gray-700 text-sm sm:text-base mb-1">Account Name:</strong>
                    <span class="text-gray-900 text-sm sm:text-base break-words"><?php if($rows['accountname']  == null){ echo "Nil"; } else{ echo $rows['accountname']; }?></span>
                </div>
                
                <div class="flex flex-col">
                    <strong class="text-gray-700 text-sm sm:text-base mb-1">Beneficiary Account Number:</strong>
                    <span class="text-gray-900 text-sm sm:text-base break-words"><?php if($rows['beneficiaryaccountnumber']  == null){ echo "Nil"; } else{ echo $rows['beneficiaryaccountnumber']; }?></span>
                </div>
                
                <div class="flex flex-col">
                    <strong class="text-gray-700 text-sm sm:text-base mb-1">Bank Name:</strong>
                    <span class="text-gray-900 text-sm sm:text-base break-words"><?php if($rows['bankname']  == null){ echo "Nil"; } else{ echo $rows['bankname']; }?></span>
                </div>
                
                <div class="flex flex-col">
                    <strong class="text-gray-700 text-sm sm:text-base mb-1">Bank Address:</strong>
                    <span class="text-gray-900 text-sm sm:text-base break-words"><?php if($rows['bankbranch']  == null){ echo "Nil"; } else{ echo $rows['bankbranch']; }?></span>
                </div>
                
                <div class="flex flex-col">
                    <strong class="text-gray-700 text-sm sm:text-base mb-1">Swift Code:</strong>
                    <span class="text-gray-900 text-sm sm:text-base break-words"><?php if($rows['swift']  == null){ echo "Nil"; } else{ echo $rows['swift']; }?></span>
                </div>
                
                <div class="flex flex-col">
                    <strong class="text-gray-700 text-sm sm:text-base mb-1">IBAN:</strong>
                    <span class="text-gray-900 text-sm sm:text-base break-words"><?php if($rows['iban']  == null){ echo "Nil"; } else{ echo $rows['iban']; }?></span>
                </div>
            </div>
        </div>
        
        <!-- Beneficiaries Section -->
        <div class="bg-gray-50 rounded-lg p-4 sm:p-6 mt-4 sm:mt-6">
            <h2 class="text-lg sm:text-xl font-bold text-gray-800 border-b-2 border-primary pb-2 mb-4">Beneficiaries</h2>
            
            <?php
            $sql="SELECT * FROM $ben_info WHERE id='$id' ORDER BY date DESC";
            $result=db_query($connect,$sql);
            if (db_num_rows($result) == 0) {
                echo '<div class="text-center text-gray-500 py-8 text-lg">No Beneficiaries found.</div>';
            }
            else{
            ?>
            
            <div class="overflow-x-auto -mx-4 sm:mx-0">
                <div class="inline-block min-w-full align-middle">
                    <div class="overflow-hidden shadow ring-1 ring-black ring-opacity-5 md:rounded-lg">
                        <table class="min-w-full divide-y divide-gray-300">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th class="px-2 sm:px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Bank</th>
                                    <th class="px-2 sm:px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                                    <th class="px-2 sm:px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Number</th>
                                    <th class="hidden md:table-cell px-2 sm:px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Address</th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                                <?php while($rows = db_fetch_array($result, MYSQLI_ASSOC)) { ?>
                                <tr class="hover:bg-gray-50 transition duration-150">
                                    <td class="px-2 sm:px-3 py-4 text-sm text-gray-900">
                                        <div class="max-w-xs truncate">
                                            <a href="ben_detail.php?id=<?php echo $rows['ben_id']; ?>" title="View Details" 
                                               class="text-primary hover:text-primary-dark font-medium transition duration-200">
                                                <?php echo $rows['bnk_name']; ?>
                                            </a>
                                        </div>
                                    </td>
                                    <td class="px-2 sm:px-3 py-4 text-sm text-gray-900">
                                        <div class="max-w-xs truncate">
                                            <a href="ben_detail.php?id=<?php echo $rows['ben_id']; ?>" title="View Details" 
                                               class="text-primary hover:text-primary-dark font-medium transition duration-200">
                                                <?php echo $rows['ben_name']; ?>
                                            </a>
                                        </div>
                                    </td>
                                    <td class="px-2 sm:px-3 py-4 text-sm text-gray-900">
                                        <div class="max-w-xs truncate">
                                            <a href="ben_detail.php?id=<?php echo $rows['ben_id']; ?>" title="View Details" 
                                               class="text-primary hover:text-primary-dark font-medium transition duration-200">
                                                <?php echo $rows['ben_acct']; ?>
                                            </a>
                                        </div>
                                    </td>
                                    <td class="hidden md:table-cell px-2 sm:px-3 py-4 text-sm text-gray-900">
                                        <div class="max-w-xs truncate">
                                            <a href="ben_detail.php?id=<?php echo $rows['ben_id']; ?>" title="View Details" 
                                               class="text-primary hover:text-primary-dark transition duration-200">
                                                <?php echo substr($rows['bnk_add'],0,20); ?>...
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            
            <?php } ?>
        </div>
        
        <!-- Messages Section -->
        <div class="bg-gray-50 rounded-lg p-4 sm:p-6 mt-4 sm:mt-6">
            <h2 class="text-lg sm:text-xl font-bold text-gray-800 border-b-2 border-primary pb-2 mb-4">Messages</h2>
            
            <?php
            $sql="SELECT * FROM $mail WHERE id='$id' ORDER BY m_date DESC";
            $result=db_query($connect,$sql);
            if (db_num_rows($result) == 0) {
                echo '<div class="text-center text-gray-500 py-8 text-lg">No Messages found.</div>';
            }
            else{
            ?>
            
            <div class="overflow-x-auto -mx-4 sm:mx-0">
                <div class="inline-block min-w-full align-middle">
                    <div class="overflow-hidden shadow ring-1 ring-black ring-opacity-5 md:rounded-lg">
                        <table class="min-w-full divide-y divide-gray-300">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th class="px-2 sm:px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Subject</th>
                                    <th class="hidden sm:table-cell px-2 sm:px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">From</th>
                                    <th class="px-2 sm:px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                                <?php while($rows = db_fetch_array($result, MYSQLI_ASSOC)) { ?>
                                <tr class="hover:bg-gray-50 transition duration-150">
                                    <td class="px-2 sm:px-3 py-4 text-sm text-gray-900">
                                        <div class="max-w-xs truncate">
                                            <a href="mssg_detail.php?id=<?php echo $rows['mssg_id']; ?>" title="View Message" 
                                               class="text-primary hover:text-primary-dark font-medium transition duration-200">
                                                <?php echo substr($rows['m_subject'],0,20); ?>...
                                            </a>
                                        </div>
                                    </td>
                                    <td class="hidden sm:table-cell px-2 sm:px-3 py-4 text-sm text-gray-900">
                                        <div class="max-w-xs truncate">
                                            <a href="mssg_detail.php?id=<?php echo $rows['mssg_id']; ?>" title="View Message" 
                                               class="text-primary hover:text-primary-dark font-medium transition duration-200">
                                                <?php echo $rows['m_from']; ?>
                                            </a>
                                        </div>
                                    </td>
                                    <td class="px-2 sm:px-3 py-4 text-sm text-gray-900">
                                        <?php echo date ('j M, Y', strtotime ($rows['m_date'])); ?>
                                    </td>
                                </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            
            <?php } ?>
            
            <!-- Send Message Button - Always Visible -->
            <div class="flex justify-end mt-4">
                <a href="new_mssg.php?id=<?php $id=$_GET['id']; echo $id; ?>" 
                   class="bg-primary hover:bg-primary-dark text-white text-sm sm:text-base font-medium py-2 px-3 sm:px-4 rounded-lg transition duration-200">
                    Send Message
                </a>
            </div>
        </div>
        
        <!-- Transaction History Section -->
        <div class="bg-gray-50 rounded-lg p-4 sm:p-6 mt-4 sm:mt-6">
            <h2 class="text-lg sm:text-xl font-bold text-gray-800 border-b-2 border-primary pb-2 mb-4">Transaction History</h2>
            
            <?php
            $sql="SELECT * FROM $trans WHERE id='$id' ORDER BY date DESC";
            $result=db_query($connect,$sql);
            if (db_num_rows($result) == 0) {
                echo '<div class="text-center text-gray-500 py-8 text-lg">No Transaction found.</div>';
            }
            else{
            ?>
            
            <div class="overflow-x-auto -mx-4 sm:mx-0">
                <div class="inline-block min-w-full align-middle">
                    <div class="overflow-hidden shadow ring-1 ring-black ring-opacity-5 md:rounded-lg">
                        <table class="min-w-full divide-y divide-gray-300">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th class="px-2 sm:px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Type</th>
                                    <th class="hidden sm:table-cell px-2 sm:px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Description</th>
                                    <th class="px-2 sm:px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Amount</th>
                                    <th class="px-2 sm:px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Leg. Balance</th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                                <?php while($rows = db_fetch_array($result, MYSQLI_ASSOC)) { ?>
                                <tr class="hover:bg-gray-50 transition duration-150">
                                    <td class="px-2 sm:px-3 py-4 text-sm text-gray-900">
                                        <div class="max-w-xs truncate">
                                            <a href="trans_detail.php?id=<?php echo $rows['trans_id']; ?>" title="View Transaction" 
                                               class="text-primary hover:text-primary-dark font-medium transition duration-200">
                                                <?php echo $rows['t_type']; ?>
                                            </a>
                                        </div>
                                    </td>
                                    <td class="hidden sm:table-cell px-2 sm:px-3 py-4 text-sm text-gray-900">
                                        <div class="max-w-xs truncate">
                                            <a href="trans_detail.php?id=<?php echo $rows['trans_id']; ?>" title="View Transaction" 
                                               class="text-primary hover:text-primary-dark transition duration-200">
                                                <?php echo substr($rows['t_description'],0,20); ?>...
                                            </a>
                                        </div>
                                    </td>
                                    <td class="px-2 sm:px-3 py-4 text-sm text-gray-900">
                                        <?php echo $rows['currency']; ?><?php $debit =$rows['debit'];
                                        $number = number_format($debit, 2); print $number ?>
                                    </td>
                                    <td class="px-2 sm:px-3 py-4 text-sm text-gray-900">
                                        <?php echo $rows['currency']; ?><?php $balance= $rows['balance'];
                                        $number = number_format($balance, 2); print $number ?>
                                    </td>
                                </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            
            <?php } ?>
            
            <!-- New Transaction Button - Always Visible -->
            <div class="flex justify-end mt-4">
                <a href="new_transact.php?id=<?php $id=$_GET['id']; echo $id; ?>" 
                   class="bg-primary hover:bg-primary-dark text-white text-sm sm:text-base font-medium py-2 px-3 sm:px-4 rounded-lg transition duration-200">
                    New Transaction
                </a>
            </div>
        </div>
    </div>
</form>

<?php
include('footer.php')
?>
