 <!-- Bottom Navigation -->
<nav class="fixed bottom-2 left-1/2 transform -translate-x-1/2 w-full max-w-[680px] bg-white border-t shadow-lg rounded-lg z-50">
    <div class="flex justify-around items-center h-16 px-4">
       <a href="main.php" class="flex flex-col items-center text-gray-600 hover:text-deep-red transition-colors">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m3 12 2-2m0 0 7-7 7 7M5 10v10a1 1 0 0 0 1 1h3m10-11 2 2m-2-2v10a1 1 0 0 1-1 1h-3m-6 0a1 1 0 0 0 1-1v-4a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v4a1 1 0 0 0 1 1m-6 0h6"></path>
            </svg>
            <span class="text-xs mt-1">Home</span>
        </a>
        <a href="reg.php" class="flex flex-col items-center text-gray-600 hover:text-deep-red transition-colors">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h3.75M9 15h3.75M9 18h3.75m3 .75H18a2.25 2.25 0 0 0 2.25-2.25V6.108c0-1.135-.845-2.098-1.976-2.192a48.424 48.424 0 0 0-1.123-.08m-5.801 0c-.065.21-.1.433-.1.664 0 .414.336.75.75.75h4.5a.75.75 0 0 0 .75-.75 2.25 2.25 0 0 0-.1-.664m-5.8 0A2.251 2.251 0 0 1 13.5 2.25H15c1.012 0 1.867.668 2.15 1.586m-5.8 0c-.376.023-.75.05-1.124.08C9.095 4.01 8.25 4.973 8.25 6.108V8.25m0 0H4.875c-.621 0-1.125.504-1.125 1.125v11.25c0 .621.504 1.125 1.125 1.125h9.75c.621 0 1.125-.504 1.125-1.125V9.375c0-.621-.504-1.125-1.125-1.125H8.25ZM6.75 12h.008v.008H6.75V12Zm0 3h.008v.008H6.75V15Zm0 3h.008v.008H6.75V18Z"></path>
                </svg>
                <span class="text-xs mt-1">Registrations</span>
            </a>
        <a href="view_users.php" class="flex flex-col items-center text-gray-600 hover:text-deep-red transition-colors">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19.128a9.38 9.38 0 0 0 2.625.372 9.337 9.337 0 0 0 4.121-.952 4.125 4.125 0 0 0-7.533-2.493M15 19.128v-.003c0-1.113-.285-2.16-.786-3.07M15 19.128v.106A12.318 12.318 0 0 1 8.624 21c-2.331 0-4.512-.645-6.374-1.766l-.001-.109a6.375 6.375 0 0 1 11.964-3.07M12 6.375a3.375 3.375 0 1 1-6.75 0 3.375 3.375 0 0 1 6.75 0Zm8.25 2.25a2.625 2.625 0 1 1-5.25 0 2.625 2.625 0 0 1 5.25 0Z"></path>
            </svg>
            <span class="text-xs mt-1">Users</span>
        </a>
        <a href="logout.php" class="flex flex-col items-center text-gray-600 hover:text-deep-red transition-colors">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.75 9V5.25A2.25 2.25 0 0 0 13.5 3h-6a2.25 2.25 0 0 0-2.25 2.25v13.5A2.25 2.25 0 0 0 7.5 21h6a2.25 2.25 0 0 0 2.25-2.25V15M12 9l-3 3m0 0 3 3m-3-3h12.75"></path>
            </svg>
            <span class="text-xs mt-1">Logout</span>
        </a>
    </div>
</nav>
 
 <!-- Footer -->
        <div id="footer" class="bg-white border-t border-gray-200 py-4 px-6">
            <div class="flex flex-col sm:flex-row justify-between items-center">
                <div class="left mb-2 sm:mb-0">
                    <p class="text-gray-600"><?php echo $a_title ?> | Da Netseer</p>
                </div>
                <div class="right">
                    <p class="text-gray-600">Copyright &copy; <script language="JavaScript">
                        var currentDate = new Date();	
                        document.write(currentDate.getFullYear());
                    </script></p>
                </div>
            </div>
        </div>
    </div>

</body>
</html>