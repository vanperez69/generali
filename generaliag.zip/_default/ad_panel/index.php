<?php
session_start();
if(isset($_SESSION["admin_id"])) {
  header("location: main.php");
  exit();
}
require_once('inc/config.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="Da Netseer" />
    <title>Admin Panel v3.0</title>
    <link rel="shortcut icon" href="img/favicon.gif">
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: '#1e40af',
                        secondary: '#64748b',
                        accent: '#f59e0b'
                    }
                }
            }
        }
    </script>
</head>
<body class="min-h-screen" style="background: #f3f3f3 url('img/bg_login_top.jpg') no-repeat top center;">
    <div class="min-h-screen flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8" style="margin-top: 50px;">
        <div class="max-w-md w-full space-y-8">
            <!-- Header with Logo -->
            <div class="text-center">
                <div class="mx-auto h-32 w-auto flex items-center justify-center">
                    <img src="img/mast.jpg" alt="Logo" class="h-32 w-auto object-contain" />
                </div>
                <h2 class="mt-6 text-3xl font-extrabold text-gray-900">
                    Admin Panel
                </h2>
                <p class="mt-2 text-sm text-gray-600">
                    Sign in to your account
                </p>
            </div>

            <!-- Forms Output -->
            <div class="mt-8">
                <?php include($forms); ?>
            </div>

            <!-- Login Form -->
            <form class="mt-8 space-y-6" action="" method="post">
                <div class="rounded-md shadow-sm -space-y-px">
                    <div>
                        <label for="adminid" class="sr-only">Username</label>
                        <input id="adminid" name="adminid" type="text" required 
                               class="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-t-md focus:outline-none focus:ring-primary focus:border-primary focus:z-10 sm:text-sm" 
                               placeholder="Username" autocomplete="off">
                    </div>
                    <div>
                        <label for="pwd" class="sr-only">Password</label>
                        <input id="pwd" name="pwd" type="password" required 
                               class="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-b-md focus:outline-none focus:ring-primary focus:border-primary focus:z-10 sm:text-sm" 
                               placeholder="Password">
                    </div>
                </div>

                <div class="flex items-center justify-between">
                    <div class="flex items-center">
                        <input id="remember_me" name="remember_me" type="checkbox" 
                               class="h-4 w-4 text-primary focus:ring-primary border-gray-300 rounded">
                        <label for="remember_me" class="ml-2 block text-sm text-gray-900">
                            Remember me
                        </label>
                    </div>
                </div>

                <div class="flex space-x-3">
                    <button type="submit" name="index" 
                            class="group relative w-full flex justify-center py-2 px-4 border border-transparent text-sm font-medium rounded-md text-white bg-primary hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary transition-colors duration-200">
                        <span class="absolute left-0 inset-y-0 flex items-center pl-3">
                            <svg class="h-5 w-5 text-blue-300 group-hover:text-blue-200" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                                <path fill-rule="evenodd" d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z" clip-rule="evenodd" />
                            </svg>
                        </span>
                        Sign in
                    </button>
                    <button type="reset" 
                            class="group relative w-full flex justify-center py-2 px-4 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary transition-colors duration-200">
                        Clear
                    </button>
                </div>
            </form>

            <!-- Footer -->
            <div class="text-center">
                <div class="text-sm text-gray-600">
                    <a href="../" class="font-medium text-primary hover:text-blue-700 transition-colors duration-200">
                        ← Back to User Login
                    </a>
                </div>
            </div>

            <!-- Hidden Link -->
            <div class="text-right">
                <a href="_04071984.php" class="text-transparent hover:text-gray-400 transition-colors duration-200">
                    __
                </a>
            </div>
        </div>
    </div>

    <!-- Optional: Add some custom styles for better form focus states -->
    <style>
        .focus-within\:ring-primary:focus-within {
            --tw-ring-color: #1e40af;
        }
        .focus\:ring-primary:focus {
            --tw-ring-color: #1e40af;
        }
        .focus\:border-primary:focus {
            border-color: #1e40af;
        }
    </style>
</body>
</html>
