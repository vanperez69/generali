<?php
include('header.php');
// get value of id that sent from address bar
$id=$_GET['id'];
// Retrieve data from database 
$sql="SELECT * FROM $mail WHERE mssg_id='$id'";
$result=db_query($connect,$sql);
$rows=db_fetch_array($result, MYSQLI_ASSOC);

?>

<div class="w-full bg-white rounded-lg shadow-md p-6">
    <div class="flex justify-end mb-4">
        <a href="javascript:history.back(1)" class="bg-gray-600 hover:bg-gray-700 text-white font-medium py-2 px-4 rounded-lg transition duration-200">
            Click To Go Back
        </a>
        <div class="ml-4">
            <?php include($forms); ?>
        </div>
    </div>
    
    <div class="bg-gray-50 rounded-lg p-6">
        <h2 class="text-xl font-bold text-gray-800 border-b-2 border-primary pb-2 mb-6">
            Reading message sent to <?php echo $rows['m_to']; ?>.
        </h2>
        
        <form action="" method="post" class="space-y-6">
            <!-- Header Row -->
            <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div class="flex flex-col">
                    <label class="block text-sm font-medium text-gray-700 mb-2">From:</label>
                    <span class="px-3 py-2 bg-gray-100 border border-gray-300 rounded-md text-gray-900">
                        <?php echo $rows['m_from']; ?>
                    </span>
                </div>
                
                <div class="flex flex-col">
                    <label class="block text-sm font-medium text-gray-700 mb-2">Date:</label>
                    <span class="px-3 py-2 bg-gray-100 border border-gray-300 rounded-md text-gray-900">
                        <?php echo date ('j M, Y', strtotime ($rows['m_date'])); ?>
                    </span>
                </div>
                
                <div class="flex flex-col">
                    <label class="block text-sm font-medium text-gray-700 mb-2">To:</label>
                    <span class="px-3 py-2 bg-gray-100 border border-gray-300 rounded-md text-gray-900">
                        <?php echo $rows['m_to']; ?>
                    </span>
                </div>
            </div>
            
            <!-- Subject -->
            <div class="flex flex-col">
                <label class="block text-sm font-medium text-gray-700 mb-2">Subject:</label>
                <span class="px-3 py-2 bg-gray-100 border border-gray-300 rounded-md text-gray-900">
                    <?php echo $rows['m_subject']; ?>
                </span>
            </div>
            
            <!-- Message -->
            <div class="flex flex-col">
                <label class="block text-sm font-medium text-gray-700 mb-2">Message:</label>
                <span class="px-3 py-2 bg-gray-100 border border-gray-300 rounded-md text-gray-900 min-h-[100px]">
                    <?php echo $rows['m_message']; ?>
                </span>
                <input name="id" type="hidden" id="id" value="<?php echo $rows['mssg_id']; ?>">
                <input name="user" type="hidden" value="<?php echo $rows['id']; ?>">
            </div>
            
            <!-- Action Buttons -->
            <div class="flex flex-col sm:flex-row gap-2 justify-end">
                <a href="edit_mssg.php?id=<?php echo $rows['mssg_id']; ?>" 
                   class="bg-primary hover:bg-primary-dark text-white font-medium py-2 px-4 rounded-lg transition duration-200 text-center">
                    Edit Message
                </a>
                <button type="submit" onclick="return confirm_delete()" name="deletemessage" 
                        class="bg-red-600 hover:bg-red-700 text-white font-medium py-2 px-4 rounded-lg transition duration-200">
                    Delete Message
                </button>
            </div>
        </form>
    </div>
</div>

    </div>
</div>
<?php
include('footer.php')
?>
