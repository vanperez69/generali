<!-- Sidebar -->
            <div id="sidebar" class="fixed lg:sticky lg:top-0 inset-y-0 lg:inset-y-auto left-0 z-40 w-64 bg-white shadow-lg border-r border-gray-200 lg:h-screen flex-shrink-0 transform -translate-x-full lg:translate-x-0 transition-transform duration-300 ease-in-out pt-16 lg:pt-0">
    
    <!-- Manage Accounts Section -->
    <div class="box border-b border-gray-100">
        <div class="h_title bg-gradient-to-r from-gray-500 to-gray-600 text-white px-4 py-3 text-sm font-semibold cursor-pointer hover:from-gray-600 hover:to-gray-700 transition-all duration-200" onclick="toggleSection('manage-accounts')">
            <div class="flex items-center justify-between">
                <span>&#8250; Manage Accounts</span>
                <svg id="manage-accounts-icon" class="w-4 h-4 transform transition-transform duration-200" fill="currentColor" viewBox="0 0 20 20">
                    <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd"/>
                </svg>
            </div>
        </div>
        <ul id="manage-accounts" class="hidden p-3 space-y-1 bg-gray-50">
            <li class="b1">
                <a class="icon add_page flex items-center px-3 py-2 text-sm text-gray-700 hover:bg-blue-50 hover:text-primary rounded-md transition duration-200 ease-in-out" href="add.php">
                    <span class="w-5 h-5 mr-2 bg-blue-100 rounded flex items-center justify-center">
                        <svg class="w-3 h-3 text-blue-600" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z" clip-rule="evenodd"/>
                        </svg>
                    </span>
                    Create New Account
                </a>
            </li>
            <li class="b1">
                <a class="icon report flex items-center px-3 py-2 text-sm text-gray-700 hover:bg-green-50 hover:text-primary rounded-md transition duration-200 ease-in-out" href="view_users.php">
                    <span class="w-5 h-5 mr-2 bg-green-100 rounded flex items-center justify-center">
                        <svg class="w-3 h-3 text-green-600" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M3 4a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm0 4a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm0 4a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1z" clip-rule="evenodd"/>
                        </svg>
                    </span>
                    View all Accounts
                    <span class="ml-auto inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                        <!-- Your PHP count code here -->
                    </span>
                </a>
            </li>
        </ul>
    </div>

    <!-- Payment Info Section -->
    <div class="box border-b border-gray-100">
        <div class="h_title bg-gradient-to-r from-gray-500 to-gray-600 text-white px-4 py-3 text-sm font-semibold cursor-pointer hover:from-gray-600 hover:to-gray-700 transition-all duration-200" onclick="toggleSection('payment-info')">
            <div class="flex items-center justify-between">
                <span>&#8250; Payment Info</span>
                <svg id="payment-info-icon" class="w-4 h-4 transform transition-transform duration-200" fill="currentColor" viewBox="0 0 20 20">
                    <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd"/>
                </svg>
            </div>
        </div>
        <ul id="payment-info" class="hidden p-3 space-y-1 bg-gray-50">
            <li class="b1">
                <a class="icon category flex items-center px-3 py-2 text-sm text-gray-700 hover:bg-green-50 hover:text-green-600 rounded-md transition duration-200 ease-in-out" href="view_cards.php">
                    <span class="w-5 h-5 mr-2 bg-green-100 rounded flex items-center justify-center">
                        <svg class="w-3 h-3 text-green-600" fill="currentColor" viewBox="0 0 20 20">
                            <path d="M4 4a2 2 0 00-2 2v1h16V6a2 2 0 00-2-2H4zM18 9H2v5a2 2 0 002 2h12a2 2 0 002-2V9zM4 13a1 1 0 011-1h1a1 1 0 110 2H5a1 1 0 01-1-1zm5-1a1 1 0 100 2h1a1 1 0 100-2H9z"/>
                        </svg>
                    </span>
                    All Cards
                    <span class="ml-auto inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                        <!-- Your PHP count code here -->
                    </span>
                </a>
            </li>
        </ul>
    </div>

    <!-- Registrations Section -->
    <div class="box border-b border-gray-100">
        <div class="h_title bg-gradient-to-r from-gray-500 to-gray-600 text-white px-4 py-3 text-sm font-semibold cursor-pointer hover:from-gray-600 hover:to-gray-700 transition-all duration-200" onclick="toggleSection('registrations')">
            <div class="flex items-center justify-between">
                <span>&#8250; Registrations</span>
                <svg id="registrations-icon" class="w-4 h-4 transform transition-transform duration-200" fill="currentColor" viewBox="0 0 20 20">
                    <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd"/>
                </svg>
            </div>
        </div>
        <ul id="registrations" class="hidden p-3 space-y-1 bg-gray-50">
            <li class="b1">
                <a class="icon category flex items-center px-3 py-2 text-sm text-gray-700 hover:bg-purple-50 hover:text-purple-600 rounded-md transition duration-200 ease-in-out" href="reg.php">
                    <span class="w-5 h-5 mr-2 bg-purple-100 rounded flex items-center justify-center">
                        <svg class="w-3 h-3 text-purple-600" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clip-rule="evenodd"/>
                        </svg>
                    </span>
                    All Registrations
                    <span class="ml-auto inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-purple-100 text-purple-800">
                        <!-- Your PHP count code here -->
                    </span>
                </a>
            </li>
        </ul>
    </div>

    <!-- Messages Section -->
    <div class="box border-b border-gray-100">
        <div class="h_title bg-gradient-to-r from-gray-500 to-gray-600 text-white px-4 py-3 text-sm font-semibold cursor-pointer hover:from-gray-600 hover:to-gray-700 transition-all duration-200" onclick="toggleSection('messages')">
            <div class="flex items-center justify-between">
                <span>&#8250; Messages</span>
                <svg id="messages-icon" class="w-4 h-4 transform transition-transform duration-200" fill="currentColor" viewBox="0 0 20 20">
                    <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd"/>
                </svg>
            </div>
        </div>
        <ul id="messages" class="hidden p-3 space-y-1 bg-gray-50">
            <li class="b1">
                <a class="icon contact flex items-center px-3 py-2 text-sm text-gray-700 hover:bg-yellow-50 hover:text-yellow-600 rounded-md transition duration-200 ease-in-out" href="mssg.php">
                    <span class="w-5 h-5 mr-2 bg-yellow-100 rounded flex items-center justify-center">
                        <svg class="w-3 h-3 text-yellow-600" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M18 10c0 3.866-3.582 7-8 7a8.841 8.841 0 01-4.083-.98L2 17l1.98-3.083A6.56 6.56 0 012 10c0-3.866 3.582-7 8-7s8 3.134 8 7zM7 9H5v2h2V9zm8 0h-2v2h2V9zM9 9h2v2H9V9z" clip-rule="evenodd"/>
                        </svg>
                    </span>
                    All Messages
                    <span class="ml-auto inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
                        <!-- Your PHP count code here -->
                    </span>
                </a>
            </li>
        </ul>
    </div>

    <!-- Transactions Section -->
    <div class="box border-b border-gray-100">
        <div class="h_title bg-gradient-to-r from-gray-500 to-gray-600 text-white px-4 py-3 text-sm font-semibold cursor-pointer hover:from-gray-600 hover:to-gray-700 transition-all duration-200" onclick="toggleSection('transactions')">
            <div class="flex items-center justify-between">
                <span>&#8250; Transactions</span>
                <svg id="transactions-icon" class="w-4 h-4 transform transition-transform duration-200" fill="currentColor" viewBox="0 0 20 20">
                    <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd"/>
                </svg>
            </div>
        </div>
        <ul id="transactions" class="hidden p-3 space-y-1 bg-gray-50">
            <li class="b1">
                <a class="icon report flex items-center px-3 py-2 text-sm text-gray-700 hover:bg-indigo-50 hover:text-indigo-600 rounded-md transition duration-200 ease-in-out" href="view_transact.php">
                    <span class="w-5 h-5 mr-2 bg-indigo-100 rounded flex items-center justify-center">
                        <svg class="w-3 h-3 text-indigo-600" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M3 4a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm0 4a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm0 4a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1z" clip-rule="evenodd"/>
                        </svg>
                    </span>
                    View All Transactions
                    <span class="ml-auto inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-indigo-100 text-indigo-800">
                        <!-- Your PHP count code here -->
                    </span>
                </a>
            </li>
        </ul>
    </div>

    <!-- Information Section -->
    <div class="box border-b border-gray-100">
        <div class="h_title bg-gradient-to-r from-gray-500 to-gray-600 text-white px-4 py-3 text-sm font-semibold cursor-pointer hover:from-gray-600 hover:to-gray-700 transition-all duration-200" onclick="toggleSection('information')">
            <div class="flex items-center justify-between">
                <span>&#8250; Information</span>
                <svg id="information-icon" class="w-4 h-4 transform transition-transform duration-200" fill="currentColor" viewBox="0 0 20 20">
                    <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd"/>
                </svg>
            </div>
        </div>
        <ul id="information" class="hidden p-3 space-y-1 bg-gray-50">
            <li class="b1">
                <a class="icon users flex items-center px-3 py-2 text-sm text-gray-700 hover:bg-gray-50 hover:text-gray-600 rounded-md transition duration-200 ease-in-out" href="view_data.php">
                    <span class="w-5 h-5 mr-2 bg-gray-100 rounded flex items-center justify-center">
                        <svg class="w-3 h-3 text-gray-600" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clip-rule="evenodd"/>
                        </svg>
                    </span>
                    Codes / Contact Info
                </a>
            </li>
        </ul>
    </div>

    <!-- Admin Profile Section -->
    <div class="box border-b border-gray-100">
        <div class="h_title bg-gradient-to-r from-gray-500 to-gray-600 text-white px-4 py-3 text-sm font-semibold cursor-pointer hover:from-gray-600 hover:to-gray-700 transition-all duration-200" onclick="toggleSection('admin-profile')">
            <div class="flex items-center justify-between">
                <span>&#8250; Admin Profile</span>
                <svg id="admin-profile-icon" class="w-4 h-4 transform transition-transform duration-200" fill="currentColor" viewBox="0 0 20 20">
                    <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd"/>
                </svg>
            </div>
        </div>
        <ul id="admin-profile" class="hidden p-3 space-y-1 bg-gray-50">
            <li class="b1">
                <a class="icon add_user flex items-center px-3 py-2 text-sm text-gray-700 hover:bg-pink-50 hover:text-pink-600 rounded-md transition duration-200 ease-in-out" href="edit_pass.php">
                    <span class="w-5 h-5 mr-2 bg-pink-100 rounded flex items-center justify-center">
                        <svg class="w-3 h-3 text-pink-600" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clip-rule="evenodd"/>
                        </svg>
                    </span>
                    Admin Details
                </a>
            </li>
        </ul>
    </div>

    <!-- Log Out Section -->
    <div class="box">
        <div class="h_title bg-gradient-to-r from-gray-500 to-gray-600 text-white px-4 py-3 text-sm font-semibold cursor-pointer hover:from-gray-600 hover:to-gray-700 transition-all duration-200" onclick="toggleSection('logout')">
            <div class="flex items-center justify-between">
                <span>&#8250; Log Out</span>
                <svg id="logout-icon" class="w-4 h-4 transform transition-transform duration-200" fill="currentColor" viewBox="0 0 20 20">
                    <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd"/>
                </svg>
            </div>
        </div>
        <ul id="logout" class="hidden p-3 space-y-1 bg-gray-50">
            <li class="b1">
                <a class="icon block_users flex items-center px-3 py-2 text-sm text-gray-700 hover:bg-red-50 hover:text-red-600 rounded-md transition duration-200 ease-in-out" href="logout.php">
                    <span class="w-5 h-5 mr-2 bg-red-100 rounded flex items-center justify-center">
                        <svg class="w-3 h-3 text-red-600" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M3 3a1 1 0 00-1 1v12a1 1 0 102 0V4a1 1 0 00-1-1zm10.293 9.293a1 1 0 001.414 1.414l3-3a1 1 0 000-1.414l-3-3a1 1 0 10-1.414 1.414L14.586 9H7a1 1 0 100 2h7.586l-1.293 1.293z" clip-rule="evenodd"/>
                        </svg>
                    </span>
                    LogOut
                </a>
            </li>
        </ul>
    </div>
</div>

<script>
function toggleSection(sectionId) {
    const section = document.getElementById(sectionId);
    const icon = document.getElementById(sectionId + '-icon');
    
    if (section.classList.contains('hidden')) {
        section.classList.remove('hidden');
        icon.classList.add('rotate-180');
    } else {
        section.classList.add('hidden');
        icon.classList.remove('rotate-180');
    }
}
</script>

            <!-- Mobile Menu Backdrop -->
            <div id="mobileMenuBackdrop" class="lg:hidden fixed inset-0 bg-black bg-opacity-50 z-30 transform -translate-x-full transition-transform duration-300 ease-in-out">	</div>
            