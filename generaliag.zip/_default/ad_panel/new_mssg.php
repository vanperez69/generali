<?php
include('header.php');
// get value of id that sent from address bar
$id=$_GET['id'];
// Retrieve data from database 
$sql="SELECT * FROM $tbl_name WHERE id='$id'";
$result=db_query($connect,$sql);
$rows=db_fetch_array($result, MYSQLI_ASSOC);

?>

<div class="w-full bg-white rounded-lg shadow-md p-6">
    <div class="flex justify-end mb-4">
        <a href="javascript:history.back(1)" class="bg-gray-600 hover:bg-gray-700 text-white font-medium py-2 px-4 rounded-lg transition duration-200">
            Click To Go Back
        </a>
        <div class="ml-4">
            <?php include($forms); ?>
        </div>
    </div>
    
    <div class="bg-gray-50 rounded-lg p-6">
        <h2 class="text-xl font-bold text-gray-800 border-b-2 border-primary pb-2 mb-6">
            Compose New Message to <?php echo $rows['name']; ?>.
        </h2>
        
        <form action="" method="post" class="space-y-6">
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div class="flex flex-col">
                    <label class="block text-sm font-medium text-gray-700 mb-2">Subject:</label>
                    <input name="id" type="hidden" value="<?php echo $rows['id']; ?>"/>
                    <input type="text" name="m_subject" placeholder="Subject" required="" 
                           class="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"/>
                    <input name="m_to" type="hidden" value="<?php echo $rows['name']; ?>"/>
                </div>
                
                <div class="flex flex-col">
                    <label class="block text-sm font-medium text-gray-700 mb-2">Date:</label>
                    <input type="text" class="datepicker" name="m_date" id="date" placeholder="Date" required="" 
                           class="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"/>
                </div>
            </div>
            
            <div class="flex flex-col">
                <label class="block text-sm font-medium text-gray-700 mb-2">Message:</label>
                <input name="m_from" type="hidden" value="<?php echo $_SESSION['a_name']; ?>"/>
                <textarea name="m_message" id="textarea" cols="55" rows="10" 
                          class="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent resize-none">Dear <?php echo $rows['name']; ?>,</textarea>
            </div>
            
            <div class="flex justify-end gap-3">
                <button type="submit" name="mssg" id="mssg" onclick="return confirm_submit()" 
                        class="bg-primary hover:bg-primary-dark text-white font-medium py-2 px-6 rounded-lg transition duration-200">
                    Send Message
                </button>
                <button type="reset" 
                        class="bg-gray-600 hover:bg-gray-700 text-white font-medium py-2 px-6 rounded-lg transition duration-200">
                    Clear
                </button>
            </div>
        </form>
    </div>
</div>

    </div>
</div>

<?php
include('footer.php')
?>
