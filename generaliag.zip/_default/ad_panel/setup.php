<?php
/**
 * Setup/Migration Script
 * Use this to initialize or import existing data into JSON database
 */

// Include the JSON Database Handler
require_once('inc/JsonDatabase.php');

// Check if JSON file already exists
$dbFile = 'database/qqunion_database.json';
$backupFile = 'database/qqunion_database_backup_' . date('Y-m-d_His') . '.json';

echo "<!DOCTYPE html>
<html>
<head>
    <title>JSON Database Setup</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 800px; margin: 50px auto; padding: 20px; }
        .success { background: #d4edda; color: #155724; padding: 15px; border-radius: 5px; margin: 10px 0; }
        .warning { background: #fff3cd; color: #856404; padding: 15px; border-radius: 5px; margin: 10px 0; }
        .error { background: #f8d7da; color: #721c24; padding: 15px; border-radius: 5px; margin: 10px 0; }
        .info { background: #d1ecf1; color: #0c5460; padding: 15px; border-radius: 5px; margin: 10px 0; }
        button { background: #007bff; color: white; padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer; margin: 5px; }
        button:hover { background: #0056b3; }
        .danger { background: #dc3545; }
        .danger:hover { background: #c82333; }
    </style>
</head>
<body>
    <h1>JSON Database Setup & Migration</h1>";

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // Initialize new database
    if (isset($_POST['init_new'])) {
        if (file_exists($dbFile)) {
            // Create backup
            copy($dbFile, $backupFile);
            echo "<div class='warning'>Existing database backed up to: " . basename($backupFile) . "</div>";
        }
        
        $db = new JsonDatabase($dbFile);
        echo "<div class='success'>✓ New JSON database initialized successfully!</div>";
        echo "<div class='info'>Location: $dbFile</div>";
    }
    
    // Import sample data
    if (isset($_POST['import_sample'])) {
        $sampleData = [
            'admin' => [
                [
                    'admin_id' => 4,
                    'userid' => 'apanel',
                    'accesscode' => 'admin',
                    'name' => 'Admin Manager',
                    'lastlogin' => date('Y-m-d')
                ]
            ],
            'data' => [
                [
                    'id' => 1,
                    'trans_code' => '355890',
                    'tax_code' => 'TX30667',
                    'imf_code' => 'IMF6789902',
                    'ter_code' => 'ANTJH24509',
                    'contact' => '<p>2570 N. First Street, 2nd Floor San Jose, CA 95131, United States</p>'
                ]
            ],
            'users' => [
                [
                    'id' => 132,
                    'userid' => '02-4803125',
                    'password' => 'Huthmaureenlovelife1',
                    'userotp' => '873014',
                    'name' => 'Huth Stephen',
                    'email' => 'huthstephen9@gmail.com',
                    'address' => '2002 Camelot Dr',
                    'phone' => '9047676427',
                    'accountnumber' => '105324867',
                    'a_type' => 'Current Account',
                    'currency' => '$',
                    'availablebalance' => 1429795.86,
                    'sender' => null,
                    'credit' => null,
                    'debit' => 0.00,
                    'datesent' => date('Y-m-d'),
                    'trans' => 1,
                    'city' => 'Lewisville',
                    'state' => 'Texas',
                    'country' => 'United States Of America',
                    'bankname' => null,
                    'bankbranch' => null,
                    'iban' => null,
                    'swift' => null,
                    'accountname' => null,
                    'beneficiaryaccountnumber' => null,
                    'amount' => null,
                    'pic' => 'default.jpg',
                    'sms' => '0',
                    'lastlogin' => date('Y-m-d H:i:s')
                ]
            ],
            'trans' => [
                [
                    'trans_id' => 223,
                    'id' => '132',
                    'name' => 'QUAN/UDTCIADR',
                    'date' => '2025-05-15',
                    't_type' => 'Deposit',
                    't_description' => '<p>CREDIT</p>',
                    'debit' => 700000.00,
                    'balance' => 700000.00,
                    'currency' => '$'
                ]
            ],
            '_meta' => [
                'last_ids' => [
                    'admin' => 4,
                    'ben_info' => 0,
                    'chk_info' => 0,
                    'c_info' => 0,
                    'data' => 1,
                    'mail' => 0,
                    'sign_up' => 0,
                    'trans' => 223,
                    'users' => 132
                ],
                'version' => '1.0',
                'last_updated' => date('Y-m-d H:i:s')
            ]
        ];
        
        // Add empty arrays for other tables
        $allTables = ['ben_info', 'chk_info', 'c_info', 'mail', 'sign_up'];
        foreach ($allTables as $table) {
            if (!isset($sampleData[$table])) {
                $sampleData[$table] = [];
            }
        }
        
        file_put_contents($dbFile, json_encode($sampleData, JSON_PRETTY_PRINT));
        echo "<div class='success'>✓ Sample data imported successfully!</div>";
    }
    
    // Test database connection
    if (isset($_POST['test_connection'])) {
        try {
            $db = new JsonDatabase($dbFile);
            $result = mysqli_query($db, "SELECT * FROM admin LIMIT 1");
            $count = mysqli_num_rows($result);
            
            echo "<div class='success'>✓ Database connection successful!</div>";
            echo "<div class='info'>Admin records found: $count</div>";
            
            // Test each table
            $tables = ['users', 'trans', 'data', 'mail', 'ben_info', 'chk_info', 'c_info', 'sign_up'];
            foreach ($tables as $table) {
                $result = mysqli_query($db, "SELECT * FROM $table");
                $count = mysqli_num_rows($result);
                echo "<div class='info'>Table '$table': $count records</div>";
            }
            
        } catch (Exception $e) {
            echo "<div class='error'>✗ Database connection failed: " . $e->getMessage() . "</div>";
        }
    }
}

// Display current status
echo "<h2>Current Status</h2>";

if (file_exists($dbFile)) {
    echo "<div class='success'>✓ JSON Database exists at: $dbFile</div>";
    
    $fileSize = filesize($dbFile);
    $fileSizeKB = round($fileSize / 1024, 2);
    echo "<div class='info'>File size: $fileSizeKB KB</div>";
    
    $lastModified = date('Y-m-d H:i:s', filemtime($dbFile));
    echo "<div class='info'>Last modified: $lastModified</div>";
    
    // Check if writable
    if (is_writable($dbFile)) {
        echo "<div class='success'>✓ Database file is writable</div>";
    } else {
        echo "<div class='error'>✗ Database file is not writable! Please check permissions.</div>";
    }
} else {
    echo "<div class='warning'>⚠ JSON Database does not exist yet.</div>";
}

// Check directory permissions
if (!is_dir('database')) {
    echo "<div class='warning'>⚠ Database directory does not exist.</div>";
} elseif (!is_writable('database')) {
    echo "<div class='error'>✗ Database directory is not writable! Please check permissions.</div>";
} else {
    echo "<div class='success'>✓ Database directory is writable</div>";
}

// Display action buttons
echo "<h2>Actions</h2>";
echo "<form method='post' style='margin: 20px 0;'>";
echo "<button type='submit' name='init_new'>Initialize New Database</button>";
echo "<button type='submit' name='import_sample'>Import Sample Data</button>";
echo "<button type='submit' name='test_connection'>Test Connection</button>";
echo "</form>";

// Migration instructions
echo "<h2>Migration from MySQL</h2>";
echo "<div class='info'>
    <p><strong>To migrate from MySQL to JSON:</strong></p>
    <ol>
        <li>Click 'Initialize New Database' to create the JSON file</li>
        <li>Click 'Import Sample Data' to load the sample records from your SQL dump</li>
        <li>Update all your PHP files to use the new config.php</li>
        <li>Test the connection with 'Test Connection' button</li>
        <li>Your forms.php and user.php will work automatically with the new system!</li>
    </ol>
    <p><strong>Note:</strong> The JsonDatabase class provides full compatibility with your existing mysqli_query() functions.</p>
</div>";

echo "<h2>Configuration Files</h2>";
echo "<div class='info'>
    <p><strong>Files you need:</strong></p>
    <ul>
        <li><strong>JsonDatabase.php</strong> - Core database handler class</li>
        <li><strong>config.php</strong> - Updated configuration (replaces MySQL connection)</li>
        <li><strong>forms.php</strong> - No changes needed! Works with new system</li>
        <li><strong>user.php</strong> - No changes needed! Works with new system</li>
    </ul>
</div>";

echo "</body></html>";
?>