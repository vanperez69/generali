<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Include required files
require_once('JsonDatabase.php');
require_once('db_wrapper.php');

// Initialize
$jsonDb = new JsonDatabase('../database/qqunion_database.json');
$connect = new DB($jsonDb);

// Test variables
$admin = "admin";
$userid = "apanel";
$pass = "admin";

echo "<h2>Testing Database Functions</h2>";

// Test 1: Escape
echo "<h3>Test 1: Escape Function</h3>";
$escaped_userid = db_escape($connect, $userid);
$escaped_pass = db_escape($connect, $pass);
echo "Escaped userid: $escaped_userid<br>";
echo "Escaped pass: $escaped_pass<br>";

// Test 2: Query
echo "<h3>Test 2: SELECT Query</h3>";
$query = "SELECT * FROM $admin WHERE userid='$escaped_userid' AND accesscode='$escaped_pass' LIMIT 1";
echo "Query: $query<br>";
$sql = db_query($connect, $query);
echo "Query result type: " . gettype($sql) . "<br>";
echo "Query result class: " . (is_object($sql) ? get_class($sql) : 'not an object') . "<br>";

// Test 3: Num rows
echo "<h3>Test 3: Number of Rows</h3>";
$existCount = db_num_rows($sql);
echo "Row count: $existCount<br>";

// Test 4: Fetch array
if ($existCount > 0) {
    echo "<h3>Test 4: Fetch Array</h3>";
    $data = db_fetch_array($sql, 1); // MYSQLI_ASSOC = 1
    echo "Fetched data:<br>";
    echo "<pre>";
    print_r($data);
    echo "</pre>";
}

// Test 5: UPDATE Query
echo "<h3>Test 5: UPDATE Query</h3>";
$update_query = "UPDATE $admin SET lastlogin=NOW() WHERE userid='$escaped_userid'";
echo "Update query: $update_query<br>";
$update = db_query($connect, $update_query);
echo "Update result: " . ($update ? 'SUCCESS' : 'FAILED') . "<br>";
?>
