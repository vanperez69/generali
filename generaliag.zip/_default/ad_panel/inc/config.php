<?php
// Include the JSON Database Handler
require_once(__DIR__ . '/JsonDatabase.php');

// Include the DB Wrapper
require_once(__DIR__ . '/db_wrapper.php');

// Get the correct path relative to where index.php is (one level up from inc/)
$dbPath = __DIR__ . '/../database/qqunion_database.json';

// Initialize JSON Database
$jsonDb = new JsonDatabase($dbPath);
$connect = new DB($jsonDb);

// Table names (kept the same for compatibility)
$admin = "admin"; // Table name
$ben_info = "ben_info"; // Table name
$chk_info = "chk_info"; // Table name
$c_info = "c_info"; // Table name
$data = "data"; // Table name
$mail = "mail"; // Table name
$sign_up = "sign_up"; // Table name
$trans = "trans"; // Table name
$tbl_name = "users"; // Table name

// Site Configuration
$a_title = "Admin Panel v4.0"; // Panel Title
$title = "Quantum Quality Union"; // Site Title
$site_url = "qqbunion.com"; // Site URL
$site_email = "support@qqbunion.com"; // Site Email
$sender = "INFO"; // SMS Sender (11 Characters, use "-" instead of space)

// SMS Configuration
$sms_user = "nyscjobs@outlook.com"; // SMS Email ID
$sms_pass = "OnlineSMS1"; // SMS Password

// Include paths
$forms = "inc/forms.php";
$user = "../ad_panel/inc/user.php";

// Create database directory if it doesn't exist
$dbDir = __DIR__ . '/../database';
if (!is_dir($dbDir)) {
    mkdir($dbDir, 0755, true);
}

// Create images directory if it doesn't exist
$imgDir = __DIR__ . '/../images';
if (!is_dir($imgDir)) {
    mkdir($imgDir, 0755, true);
}
?>