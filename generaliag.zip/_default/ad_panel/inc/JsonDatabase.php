<?php
/**
 * JSON Database Handler Class
 * Replaces MySQL database operations with JSON file-based storage
 */

class JsonDatabase {
    private $dbFile;
    private $data;
    private $lastQuery;
    private $lastError = '';
    
    public function __construct($dbFile = '../database/qqunion_database.json') {
        $this->dbFile = $dbFile;
        
        // Create database directory if it doesn't exist
        $dir = dirname($dbFile);
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }
        
        // Initialize database file if it doesn't exist
        if (!file_exists($this->dbFile)) {
            $this->initDatabase();
        }
        
        $this->loadData();
    }
    
    /**
     * Initialize empty database structure
     */
    private function initDatabase() {
        $emptyDb = [
            'admin' => [],
            'ben_info' => [],
            'chk_info' => [],
            'c_info' => [],
            'data' => [],
            'mail' => [],
            'sign_up' => [],
            'trans' => [],
            'users' => [],
            '_meta' => [
                'last_ids' => [
                    'admin' => 0,
                    'ben_info' => 0,
                    'chk_info' => 0,
                    'c_info' => 0,
                    'data' => 0,
                    'mail' => 0,
                    'sign_up' => 0,
                    'trans' => 0,
                    'users' => 0
                ],
                'version' => '1.0',
                'last_updated' => date('Y-m-d H:i:s')
            ]
        ];
        
        file_put_contents($this->dbFile, json_encode($emptyDb, JSON_PRETTY_PRINT));
    }
    
    /**
     * Load data from JSON file
     */
    private function loadData() {
        if (file_exists($this->dbFile)) {
            $json = file_get_contents($this->dbFile);
            $this->data = json_decode($json, true);
        }
    }
    
    /**
     * Save data to JSON file
     */
    private function saveData() {
        $this->data['_meta']['last_updated'] = date('Y-m-d H:i:s');
        file_put_contents($this->dbFile, json_encode($this->data, JSON_PRETTY_PRINT));
        return true;
    }
    
    /**
     * Escape string (mimics mysqli_real_escape_string)
     */
    public function escape($string) {
        // For JSON database, just return as-is since we're not prone to SQL injection
        // The data will be JSON-encoded which handles escaping
        return $string;
    }
    
    /**
     * Execute a query
     */
    public function query($query) {
        $this->lastQuery = $query;
        $query = trim($query);
        
        if (stripos($query, 'SELECT') === 0) {
            return $this->executeSelect($query);
        } elseif (stripos($query, 'INSERT') === 0) {
            return $this->executeInsert($query);
        } elseif (stripos($query, 'UPDATE') === 0) {
            return $this->executeUpdate($query);
        } elseif (stripos($query, 'DELETE') === 0) {
            return $this->executeDelete($query);
        }
        
        return false;
    }
    
    /**
     * Execute SELECT query
     */
    private function executeSelect($query) {
        // Check if this is a COUNT query
        if (preg_match('/SELECT\s+COUNT\(([^)]+)\)/i', $query, $countMatch)) {
            return $this->executeCount($query);
        }
        
        preg_match('/FROM\s+`?(\w+)`?/i', $query, $tableMatch);
        if (!isset($tableMatch[1])) return false;
        
        $table = $tableMatch[1];
        if (!isset($this->data[$table])) return false;
        
        $results = $this->data[$table];
        
        // Handle WHERE clause
        if (preg_match('/WHERE\s+(.+?)(\s+LIMIT|\s+ORDER|$)/i', $query, $whereMatch)) {
            $whereClause = $whereMatch[1];
            $results = array_filter($results, function($row) use ($whereClause) {
                return $this->evaluateWhere($row, $whereClause);
            });
        }
        
        // Handle ORDER BY
        if (preg_match('/ORDER BY\s+(\w+)\s*(ASC|DESC)?/i', $query, $orderMatch)) {
            $orderField = $orderMatch[1];
            $orderDir = isset($orderMatch[2]) && strtoupper($orderMatch[2]) === 'DESC' ? -1 : 1;
            
            usort($results, function($a, $b) use ($orderField, $orderDir) {
                if (!isset($a[$orderField]) || !isset($b[$orderField])) return 0;
                return ($a[$orderField] <=> $b[$orderField]) * $orderDir;
            });
        }
        
        // Handle LIMIT
        if (preg_match('/LIMIT\s+(\d+)(?:\s*,\s*(\d+))?/i', $query, $limitMatch)) {
            if (isset($limitMatch[2])) {
                // LIMIT offset, count
                $offset = (int)$limitMatch[1];
                $count = (int)$limitMatch[2];
                $results = array_slice($results, $offset, $count);
            } else {
                // LIMIT count
                $results = array_slice($results, 0, (int)$limitMatch[1]);
            }
        }
        
        return new JsonResult(array_values($results));
    }
    
    /**
     * Execute COUNT query
     */
    private function executeCount($query) {
        preg_match('/FROM\s+`?(\w+)`?/i', $query, $tableMatch);
        if (!isset($tableMatch[1])) return false;
        
        $table = $tableMatch[1];
        if (!isset($this->data[$table])) return false;
        
        $results = $this->data[$table];
        
        // Handle WHERE clause
        if (preg_match('/WHERE\s+(.+?)$/i', $query, $whereMatch)) {
            $whereClause = $whereMatch[1];
            $results = array_filter($results, function($row) use ($whereClause) {
                return $this->evaluateWhere($row, $whereClause);
            });
        }
        
        $count = count($results);
        
        // Return result in format that fetch_row expects
        return new JsonResult([['COUNT' => $count]]);
    }
    
    /**
     * Evaluate WHERE clause
     */
    private function evaluateWhere($row, $whereClause) {
        if (stripos($whereClause, ' AND ') !== false) {
            $conditions = preg_split('/\s+AND\s+/i', $whereClause);
            foreach ($conditions as $condition) {
                if (!$this->evaluateCondition($row, trim($condition))) {
                    return false;
                }
            }
            return true;
        }
        
        if (stripos($whereClause, ' OR ') !== false) {
            $conditions = preg_split('/\s+OR\s+/i', $whereClause);
            foreach ($conditions as $condition) {
                if ($this->evaluateCondition($row, trim($condition))) {
                    return true;
                }
            }
            return false;
        }
        
        return $this->evaluateCondition($row, $whereClause);
    }
    
    /**
     * Evaluate a single condition - FIXED to handle backticks
     */
    private function evaluateCondition($row, $condition) {
        // Handle backticks and quotes in field names
        if (preg_match('/`?(\w+)`?\s*=\s*[\'"](.+?)[\'"]/', $condition, $match)) {
            $field = $match[1];
            $value = $match[2];
            return isset($row[$field]) && $row[$field] == $value;
        }
        
        if (preg_match('/`?(\w+)`?\s*=\s*(\d+)/', $condition, $match)) {
            $field = $match[1];
            $value = $match[2];
            return isset($row[$field]) && $row[$field] == $value;
        }
        
        return false;
    }
    
    /**
     * Execute INSERT query
     */
    private function executeInsert($query) {
        preg_match('/INTO\s+`?(\w+)`?/i', $query, $tableMatch);
        if (!isset($tableMatch[1])) return false;
        
        $table = $tableMatch[1];
        
        preg_match('/\(([^)]+)\)\s*VALUES\s*\(([^)]+)\)/i', $query, $match);
        if (!isset($match[1]) || !isset($match[2])) return false;
        
        $columns = array_map(function($col) {
            return trim($col, " \t\n\r\0\x0B`");
        }, explode(',', $match[1]));
        
        $values = $this->parseValues($match[2]);
        
        if (count($columns) !== count($values)) return false;
        
        $record = array_combine($columns, $values);
        
        $idField = $this->getIdField($table);
        if ($idField && !isset($record[$idField])) {
            if (!isset($this->data['_meta']['last_ids'][$table])) {
                $this->data['_meta']['last_ids'][$table] = 0;
            }
            $this->data['_meta']['last_ids'][$table]++;
            $record[$idField] = $this->data['_meta']['last_ids'][$table];
        }
        
        $this->data[$table][] = $record;
        return $this->saveData();
    }
    
    /**
     * Execute UPDATE query
     */
    private function executeUpdate($query) {
        preg_match('/UPDATE\s+`?(\w+)`?/i', $query, $tableMatch);
        if (!isset($tableMatch[1])) return false;
        
        $table = $tableMatch[1];
        
        preg_match('/SET\s+(.+?)\s+WHERE/i', $query, $setMatch);
        if (!isset($setMatch[1])) return false;
        
        $setClause = $setMatch[1];
        $updates = $this->parseSetClause($setClause);
        
        preg_match('/WHERE\s+(.+?)$/i', $query, $whereMatch);
        if (!isset($whereMatch[1])) return false;
        
        $whereClause = $whereMatch[1];
        
        $updated = false;
        foreach ($this->data[$table] as $key => $row) {
            if ($this->evaluateWhere($row, $whereClause)) {
                foreach ($updates as $field => $value) {
                    $this->data[$table][$key][$field] = $value;
                }
                $updated = true;
            }
        }
        
        if ($updated) {
            return $this->saveData();
        }
        
        return false;
    }
    
    /**
     * Execute DELETE query
     */
    private function executeDelete($query) {
        preg_match('/FROM\s+`?(\w+)`?/i', $query, $tableMatch);
        if (!isset($tableMatch[1])) return false;
        
        $table = $tableMatch[1];
        
        if (!isset($this->data[$table])) {
            $this->setError("Table $table does not exist");
            return false;
        }
        
        preg_match('/WHERE\s+(.+?)$/i', $query, $whereMatch);
        if (!isset($whereMatch[1])) return false;
        
        $whereClause = $whereMatch[1];
        
        $originalCount = count($this->data[$table]);
        $this->data[$table] = array_filter($this->data[$table], function($row) use ($whereClause) {
            return !$this->evaluateWhere($row, $whereClause);
        });
        
        $this->data[$table] = array_values($this->data[$table]);
        
        if (count($this->data[$table]) < $originalCount) {
            return $this->saveData();
        }
        
        return false;
    }
    
    /**
     * Parse VALUES clause - FIXED VERSION
     */
    private function parseValues($valueString) {
        $values = [];
        $parts = [];
        $current = '';
        $inQuote = false;
        $quoteChar = '';
        
        // Manually parse to handle commas within quotes
        for ($i = 0; $i < strlen($valueString); $i++) {
            $char = $valueString[$i];
            
            if (($char === '"' || $char === "'") && ($i === 0 || $valueString[$i-1] !== '\\')) {
                if (!$inQuote) {
                    $inQuote = true;
                    $quoteChar = $char;
                } elseif ($char === $quoteChar) {
                    $inQuote = false;
                    $quoteChar = '';
                }
                $current .= $char;
            } elseif ($char === ',' && !$inQuote) {
                $parts[] = trim($current);
                $current = '';
            } else {
                $current .= $char;
            }
        }
        
        if ($current !== '') {
            $parts[] = trim($current);
        }
        
        // Process each part
        foreach ($parts as $part) {
            $part = trim($part);
            
            // Check for NOW() function (exact match)
            if (preg_match('/^NOW\(\)$/i', $part)) {
                $values[] = date('Y-m-d H:i:s');
                continue;
            }
            
            // Remove quotes and add value
            $part = trim($part, "'\"");
            $values[] = $part;
        }
        
        return $values;
    }
    
    /**
     * Parse SET clause
     */
    private function parseSetClause($setClause) {
        $updates = [];
        $parts = explode(',', $setClause);
        
        foreach ($parts as $part) {
            // Handle backticks in field names
            if (preg_match('/`?(\w+)`?\s*=\s*[\'"](.+?)[\'"]/i', $part, $match)) {
                $updates[$match[1]] = $match[2];
            } elseif (preg_match('/`?(\w+)`?\s*=\s*NOW\(\)/i', $part, $match)) {
                $updates[$match[1]] = date('Y-m-d H:i:s');
            } elseif (preg_match('/`?(\w+)`?\s*=\s*(\d+\.?\d*)/i', $part, $match)) {
                $updates[$match[1]] = $match[2];
            }
        }
        
        return $updates;
    }
    
    /**
     * Get ID field for table
     */
    private function getIdField($table) {
        $idFields = [
            'admin' => 'admin_id',
            'ben_info' => 'ben_id',
            'chk_info' => 'chk_id',
            'c_info' => 'id',
            'data' => 'id',
            'mail' => 'mssg_id',
            'sign_up' => 'id',
            'trans' => 'trans_id',
            'users' => 'id'
        ];
        
        return isset($idFields[$table]) ? $idFields[$table] : null;
    }
    
    /**
     * Get last insert ID
     */
    public function insert_id() {
        $maxId = 0;
        foreach ($this->data['_meta']['last_ids'] as $id) {
            $maxId = max($maxId, $id);
        }
        return $maxId;
    }
    
    /**
     * Get last error message
     */
    public function getLastError() {
        return $this->lastError;
    }
    
    /**
     * Set error message
     */
    private function setError($message) {
        $this->lastError = $message;
    }
}

/**
 * JSON Result Class
 */
class JsonResult {
    private $data;
    private $position = 0;
    
    public function __construct($data) {
        $this->data = $data;
    }
    
    public function fetch_array($type = MYSQLI_ASSOC) {
        if ($this->position >= count($this->data)) {
            return null;
        }
        
        return $this->data[$this->position++];
    }
    
    public function fetch_row() {
        if ($this->position >= count($this->data)) {
            return null;
        }
        
        // Return indexed array (numeric keys only)
        return array_values($this->data[$this->position++]);
    }
    
    public function num_rows() {
        return count($this->data);
    }
}
?>