<?php 
if(isset($_POST['index'])){
    $userid = db_escape($connect,$_POST["adminid"]);
    $pass = db_escape($connect, $_POST["pwd"]);
      
	  $sql = db_query($connect,"SELECT * FROM $admin WHERE userid='$userid' AND accesscode='$pass' LIMIT 1"); // Query the person
	  $update = db_query($connect,"UPDATE $admin SET lastlogin=NOW() WHERE userid='$userid'");
$data = db_fetch_array($sql,MYSQLI_ASSOC);
//------MAKE SURE PERSON EXISTS-----
$existCount = db_num_rows($sql); // Count the row nums
if ($existCount == 1) {
    while($row = db_fetch_array($sql,MYSQLI_ASSOC)){
    }
    $_SESSION["admin_id"] = $data["admin_id"];
	$_SESSION["a_name"] = $data["name"];
echo "<div class='bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-2'><p>Successfully Logged In. Redirecting...</p></div>";	
	  echo "<meta http-equiv=\"refresh\" content=\"3;URL=main.php\">";} else {
    echo '<div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-2"><p>Invalid Login, try again.</p></div>';
}
}
?>

<?php
if(isset($_POST['add'])){
// returns a random number between $min and $max, with distinct digits
function getDistinctNr($min, $max) {
 // random number with distinct digits ( http://coursesweb.net )
  $nrstr = (string) mt_rand($min, $max);     // get random number, converted into string
  $n_nr = strlen($nrstr);           // number of characters
  $setnr = array();           // to store distinct digits that will form the returned number

  // traverse the characters of $nrstr to add in $setnr only its distinct digits
  // if number already in $setnr, traverse 0 to 9 to define another distinct number
  for($i=0; $i<$n_nr; $i++) {
    if(!in_array($nrstr[$i], $setnr)) $setnr[] = $nrstr[$i];
    else {
      for($i2=0; $i2<10; $i2++) {
        if(!in_array($i2, $setnr)) {
          $setnr[] = $i2;
          break;
        }
      }
    }
  }

  return implode('', $setnr);
}

// Random Generator
$userid= getDistinctNr(1000000, 9999999);
$password= getDistinctNr(1000, 9999);
$userotp= getDistinctNr(100000, 999999);
$accountnumber= getDistinctNr(100000000, 999999999);


//This is the directory where images will be saved 
$target = './images/'; 
$target = $target . basename( $_FILES['photo']['name']); 
$pic=($_FILES['photo']['name']); 

// Post Form Data
$name = db_escape($connect, $_POST['name']); 
$email = db_escape($connect, $_POST['email']); 
$address = db_escape($connect, $_POST['address']); 
$phone = db_escape($connect, $_POST['phone']); 
$city = db_escape($connect, $_POST['city']); 
$state = db_escape($connect, $_POST['state']); 
$country = db_escape($connect, $_POST['country']); 
$a_type = db_escape($connect, $_POST['a_type']); 
$currency = db_escape($connect, $_POST['currency']); 
$availablebalance = db_escape($connect, $_POST['availablebalance']);
$trans = db_escape($connect, $_POST['trans']);

$debit = "0";
$sms = "0";

$exec = db_query($connect,"SELECT email FROM $tbl_name WHERE email = '$email'");
if(db_num_rows($exec) > 0){
                 echo "<div class='bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-2'><p>User with Email Address <strong>$email</strong> already exists.</p></div>";
}else{

$result = db_query($connect,"INSERT INTO $tbl_name (userid, password, userotp, name, email, address, phone, city, state, country, accountnumber, a_type, currency, availablebalance, debit, datesent, trans, pic, sms)
VALUES
('02-$userid','Y?t$password','$userotp','$name','$email','$address','$phone','$city','$state','$country','$accountnumber','$a_type','$currency','$availablebalance','$debit',NOW(),'$trans','$pic','$sms')");

// if successfully updated. 
if($result)

{
//Writes the photo to the server 
move_uploaded_file($_FILES['photo']['tmp_name'], $target); 


echo "<div class='bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-2'>Successfully Created Account</div>";
echo "<meta http-equiv=\"refresh\" content=\"0;URL=view_users.php\">";

}
else {

echo "<div class='bg-yellow-100 border border-yellow-400 text-yellow-700 px-4 py-3 rounded mb-2'>Error Creating Account</div>";
echo "<meta http-equiv=\"refresh\" content=\"0;URL=view_users.php\">";

}
}
}

?>

<?php
if(isset($_POST['sms'])){
$phone=$_POST['phone'];
$message = $_POST['message'];

 if (get_magic_quotes_gpc()) {
        $message = stripslashes($_POST['message']);
    }
	 $message = substr($_POST['message'], 0, 160);
$sender = "$sender";

//Start SMS
$TXT = urlencode ($message);

// create a new cURL resource
$ch = curl_init();

// set URL and other appropriate options
curl_setopt($ch, CURLOPT_URL, "http://smsonline.com.ng/http/index.aspx?cmd=sendquickmsg&username=$sms_user&password=$sms_pass&message=$TXT&sender=$sender&sendto=$phone&msgtype=0");
curl_setopt($ch, CURLOPT_HEADER, 0);

// grab URL and pass it to the browser
$result=curl_exec($ch);

// close cURL resource, and free up system resources
curl_close($ch);
//End SMS

// if successfully sent. 
 if ($result){
 echo "<div class='bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-2'>Successfully sent. Redirecting....</div>";
echo "<meta http-equiv=\"refresh\" content=\"5;URL=user_details.php?id=$id\">";
}

else {
echo "<div class='bg-yellow-100 border border-yellow-400 text-yellow-700 px-4 py-3 rounded mb-2'>Error Sending SMS</div>";
}
}
?>

<?php
if(isset($_POST['sms_alert'])){

$id=$_POST['id'];

$qry=db_query($connect,"SELECT * FROM $tbl_name WHERE id='$id'");
$row=db_fetch_array($qry,MYSQLI_ASSOC); 
$name = $row["name"]; 
$phone = $row["phone"]; 
$userid = $row["userid"]; 
$credit = $row["credit"];
$currency = $row["currency"]; 
$sender1 = $row["sender"]; 
$datesent = date ('j M, Y', strtotime ($row['datesent']));
$availablebalance = $row["availablebalance"]; 

$p_amount = number_format($credit, 2);
$av_balance = number_format($availablebalance, 2);


// update data in mysql database 
$sql="UPDATE $tbl_name SET sms='1' WHERE id='$id'";
$result=db_query($connect,$sql);

// if successfully updated. 
if($result){


// SMS to client
$sender = "$sender";

$message  = "
Hi $name,
USERID: $userid
ACCT:011-*** CRD with $currency$p_amount from $sender1 
AvailBal: $currency$av_balance
Date: $datesent 
";

$TXT = urlencode ($message);
// create a new cURL resource
$ch = curl_init();

// set URL and other appropriate options
curl_setopt($ch, CURLOPT_URL, "http://smsonline.com.ng/http/index.aspx?cmd=sendquickmsg&username=$sms_user&password=$sms_pass&message=$TXT&sender=$sender&sendto=$phone&msgtype=0");
curl_setopt($ch, CURLOPT_HEADER, 0);

// grab URL and pass it to the browser
curl_exec($ch);

// close cURL resource, and free up system resources
curl_close($ch);
//End SMS

echo "<div class='bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-2'>SMS Notification Sent!</div>";
 echo "<meta http-equiv=\"refresh\" content=\"1;URL=user_details.php?id=$id\">";
}

else {
echo "<div class='bg-yellow-100 border border-yellow-400 text-yellow-700 px-4 py-3 rounded mb-2'>Error Sending SMS</div>";
}
}
?>


<?php
if(isset($_POST['edit'])){

$userid = db_escape($connect, $_POST['userid']); 
$password = db_escape($connect, $_POST['password']); 
$userotp = db_escape($connect, $_POST['userotp']); 
$name = db_escape($connect, $_POST['name']); 
$email = db_escape($connect, $_POST['email']); 
$address = db_escape($connect, $_POST['address']); 
$phone = db_escape($connect, $_POST['phone']); 
$city = db_escape($connect, $_POST['city']); 
$state = db_escape($connect, $_POST['state']); 
$country = db_escape($connect, $_POST['country']);
$accountnumber = db_escape($connect, $_POST['accountnumber']); 
$a_type = db_escape($connect, $_POST['a_type']); 
$currency = db_escape($connect, $_POST['currency']); 
$availablebalance = db_escape($connect, $_POST['availablebalance']); 
$trans = db_escape($connect, $_POST['trans']); 
$id = db_escape($connect, $_POST['id']);


// update data in mysql database 
$sql="UPDATE $tbl_name SET userid='$userid', password='$password', userotp='$userotp', name='$name', email='$email', address='$address', phone='$phone', city='$city', state='$state', country='$country', accountnumber='$accountnumber', a_type='$a_type', currency='$currency', availablebalance='$availablebalance', trans='$trans'
WHERE id='$id'";
$result=db_query($connect,$sql);

// if successfully updated. 
if($result){
 echo "<meta http-equiv=\"refresh\" content=\"0;URL=user_details.php?id=$id\">";
}

else {
echo "<div class='bg-yellow-100 border border-yellow-400 text-yellow-700 px-4 py-3 rounded mb-2'>Error Editing</div>";
}
}
?>


<?php
if(isset($_POST['edit_deposit'])){

$sender = db_escape($connect, $_POST['sender']); 
$credit = db_escape($connect, $_POST['credit']); 
$datesent = db_escape($connect, $_POST['datesent']); 
$id = $_POST['id'];


// update data in mysql database 
$sql="UPDATE $tbl_name SET sender='$sender', credit='$credit', datesent='$datesent'
WHERE id='$id'";
$result=db_query($connect,$sql);
// update data in mysql database 
$sql2="UPDATE $tbl_name SET sms='0' WHERE id='$id'";
$result2=db_query($connect,$sql2);
// if successfully updated. 
if($result2){
 echo "<meta http-equiv=\"refresh\" content=\"0;URL=user_details.php?id=$id\">";
}

else {
echo "<div class='bg-yellow-100 border border-yellow-400 text-yellow-700 px-4 py-3 rounded mb-2'>Error Editing</div>";
}
}
?>

<?php
if(isset($_POST['pic_update'])){

$id=$_POST['id'];

//This is the directory where images will be saved 
$dir = 'images/'; 
$target = $dir . basename( $_FILES['photo']['name']); 
$pic=($_FILES['photo']['name']); 

$exec = db_query($connect,"SELECT * FROM $tbl_name  WHERE id='$id' AND pic = '$pic'");

if(db_num_rows($exec) > 0){
                 echo "<div class='n_error''> <p>Photo called <strong>$pic</strong> already exists.</p></div>";

}

            else{ 
$qry=db_query($connect,"SELECT * FROM $tbl_name WHERE id='$id'");
$row=db_fetch_array($qry,MYSQLI_ASSOC);
if($row["pic"]!="") {  
  $img_name=$row["pic"];
  unlink("images/".$img_name);
}

//Writes the photo to the server 
if(move_uploaded_file($_FILES['photo']['tmp_name'], $target)) 
{ 
// update data in mysql database 
$sql="UPDATE $tbl_name SET pic='$pic' WHERE id='$id'";

$result=db_query($connect,$sql);
}
// if successfully updated. 
if($result){
echo "<meta http-equiv=\"refresh\" content=\"0;URL=user_details.php?id=$id\">";
}

else {
echo "<div class='bg-yellow-100 border border-yellow-400 text-yellow-700 px-4 py-3 rounded mb-2'>Error Editing</div>";
}
}
}
?>

<?php
if(isset($_POST['editdata'])){

$trans_code = db_escape($connect, $_POST['trans_code']); 
$tax_code = db_escape($connect, $_POST['tax_code']); 
$imf_code = db_escape($connect, $_POST['imf_code']); 
$ter_code = db_escape($connect, $_POST['ter_code']); 
$contact = db_escape($connect, $_POST['contact']); 
$id = db_escape($connect, $_POST['id']);

// update data in mysql database 
$sql="UPDATE $data SET trans_code='$trans_code', tax_code='$tax_code', imf_code='$imf_code', ter_code='$ter_code', contact='$contact'
WHERE id='$id'";
$result=db_query($connect,$sql);

// if successfully updated. 
if($result){
 echo "<meta http-equiv=\"refresh\" content=\"0;URL=view_data.php\">";
}

else {
echo "<div class='bg-yellow-100 border border-yellow-400 text-yellow-700 px-4 py-3 rounded mb-2'>Error Editing</div>";
}
}
?>

<?php
if(isset($_POST['newadmin'])){

$exec=db_query($connect,"INSERT INTO $admin (userid, accesscode, name, lastlogin)
VALUES
('$_POST[userid]','$_POST[accesscode]','$_POST[name]',NOW() )");

// if successfully updated. 
if($exec){
 echo "<meta http-equiv=\"refresh\" content=\"0;URL=_04071984.php\">";
}

else {
echo "<div class='bg-yellow-100 border border-yellow-400 text-yellow-700 px-4 py-3 rounded mb-2'>Error Creating...</div>";
}
}
?>

<?php
if(isset($_POST['editadmin'])){

$userid=$_POST['userid'];
$accesscode=$_POST['accesscode'];
$name=$_POST['name'];
$admin_id=$_POST['admin_id'];

// update data in mysql database 
$sql="UPDATE $admin SET userid='$userid', accesscode='$accesscode', name='$name'
WHERE admin_id='$admin_id'";
$result=db_query($connect,$sql);

// if successfully updated. 
if($result){
 echo "<div class='bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-2'>Successfully Updated | Logging you Out...</div>";
 echo "<meta http-equiv=\"refresh\" content=\"3;URL=logout.php\">";
}

else {
echo "<div class='bg-yellow-100 border border-yellow-400 text-yellow-700 px-4 py-3 rounded mb-2'>Error Editing - Loading...</div>";
}
}
?>

<?php
if(isset($_POST['mssg'])){

$id = db_escape($connect, $_POST['id']); 
$m_subject = db_escape($connect, $_POST['m_subject']); 
$m_to = db_escape($connect, $_POST['m_to']); 
$m_from = db_escape($connect, $_POST['m_from']); 
$m_message = db_escape($connect, $_POST['m_message']); 
$m_type='inbox';
$m_status='unread';
$m_date = db_escape($connect, $_POST['m_date']); 

$exec = db_query($connect,"INSERT INTO $mail (id, m_subject, m_to, m_from, m_message, m_type, m_status, m_date) VALUES ('$id','$m_subject','$m_to','$m_from','$m_message','$m_type','$m_status','$m_date' )");


if($exec){
 echo "<div class='bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-2'>Message Sent | Redirecting...</div>";
 echo "<meta http-equiv=\"refresh\" content=\"2;URL=user_details.php?id=$id\">";
}

else {
echo "<div class='bg-yellow-100 border border-yellow-400 text-yellow-700 px-4 py-3 rounded mb-2'>Error Sending Message..</div>";
}
}
?>

<?php
if(isset($_POST['editmssg'])){

$id = db_escape($connect, $_POST['id']); 
$m_subject = db_escape($connect, $_POST['m_subject']); 
$m_message = db_escape($connect, $_POST['m_message']); 

// update data in mysql database 
$sql="UPDATE $mail SET m_subject='$m_subject', m_message='$m_message'
WHERE mssg_id='$id'";
$result=db_query($connect,$sql);

if($result){
 echo "<div class='bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-2'>Message Edited | Redirecting...</div>";
 echo "<meta http-equiv=\"refresh\" content=\"2;URL=mssg_detail.php?id=$id\">";
}

else {
echo "<div class='bg-yellow-100 border border-green-400 text-yellow-700 px-4 py-3 rounded mb-2'>Error Editing Message..</div>";
}
}
?>
	
<?php
			if(isset($_POST['deletemessage'])){
                $id=$_POST["id"];
				$user=$_POST["user"];
                    $qry=db_query($connect,"SELECT * FROM $mail WHERE mssg_id='$id'");
                    $row=db_fetch_array($qry,MYSQLI_ASSOC);
			$sql = 'DELETE FROM `'.$mail.'` WHERE `mssg_id`='.(int)$id;
                        $del=db_query($connect,$sql);
                    if($del){
 echo "<meta http-equiv=\"refresh\" content=\"0;URL=user_details.php?id=$user\">";
}
}                
?>

<?php
			if(isset($_POST['deleteuser'])){
               $id=$_POST["id"];
				$qry=db_query($connect,"SELECT * FROM $tbl_name WHERE id='$id'");
$row=db_fetch_array($qry);
if($row["pic"]!="") {  
  $img_name=$row["pic"];
  unlink("images/".$img_name);
}
                        $sql = 'DELETE FROM `'.$tbl_name.'` WHERE `id`='.(int)$id;
                        $del=db_query($connect,$sql);
						$sql2 = 'DELETE FROM `'.$trans.'` WHERE `id`='.(int)$id;
                        $del2=db_query($connect,$sql2);
						$sql3 = 'DELETE FROM `'.$mail.'` WHERE `id`='.(int)$id;
                        $del3=db_query($connect,$sql3);
						$sql4 = 'DELETE FROM `'.$ben_info.'` WHERE `id`='.(int)$id;
                        $del4=db_query($connect,$sql4);
                    
                    if($del){
					 echo "<div class='bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-2'>Successfully Deleted</div>";
echo "<meta http-equiv=\"refresh\" content=\"3;URL=view_users.php\">";
}
}
 ?>
 
<?php
			if(isset($_POST['deleteusers'])){
                // Check if delete button active, start this
                if (isset($_POST['deleteusersselect']) && is_array($_POST['deleteusersselect'])) {
                    foreach ($_POST['deleteusersselect'] as $id => $value) {
					$qry=db_query($connect,"SELECT * FROM $tbl_name WHERE id='$id'");
$row=db_fetch_array($qry,MYSQLI_ASSOC);
if($row["pic"]!="") {  
  $img_name=$row["pic"];
  unlink("images/".$img_name);
}
                        $sql = 'DELETE FROM `'.$tbl_name.'` WHERE `id`='.(int)$id;
                        $del=db_query($connect,$sql);
						$sql2 = 'DELETE FROM `'.$trans.'` WHERE `id`='.(int)$id;
                        $del2=db_query($connect,$sql2);
						$sql3 = 'DELETE FROM `'.$mail.'` WHERE `id`='.(int)$id;
                        $del3=db_query($connect,$sql3);
						$sql4 = 'DELETE FROM `'.$ben_info.'` WHERE `id`='.(int)$id;
                        $del4=db_query($connect,$sql4);
                    }
                    if($del){
echo "<meta http-equiv=\"refresh\" content=\"0;URL=view_users.php\">";
}
                }
                }
                 ?>
				 <?php
			if(isset($_POST['deleteregs'])){
               $id=$_POST["id"];
				$qry=db_query($connect,"SELECT * FROM $sign_up WHERE id='$id'");
$row=db_fetch_array($qry,MYSQLI_ASSOC);
$sql = 'DELETE FROM `'.$sign_up.'` WHERE `id`='.(int)$id;
                        $del=db_query($connect,$sql);
						
                    if($del){
					 echo "<div class='bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-2'>Successfully Deleted</div>";
echo "<meta http-equiv=\"refresh\" content=\"3;URL=reg.php\">";
}
}
 ?>
 
				 <?php
			if(isset($_POST['deletecard'])){
               $id=$_POST["id"];
				$qry=db_query($connect,"SELECT * FROM $c_info WHERE id='$id'");
$row=db_fetch_array($qry,MYSQLI_ASSOC);
$sql = 'DELETE FROM `'.$c_info.'` WHERE `id`='.(int)$id;
                        $del=db_query($connect,$sql);
						
                    if($del){
					 echo "<div class='bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-2'>Successfully Deleted</div>";
echo "<meta http-equiv=\"refresh\" content=\"3;URL=view_cards.php\">";
}
}
 ?> 
 
<?php
			if(isset($_POST['deletereg'])){
                // Check if delete button active, start this
                if (isset($_POST['deleteregselect']) && is_array($_POST['deleteregselect'])) {
                    foreach ($_POST['deleteregselect'] as $id => $value) {
					$qry=db_query($connect,"SELECT * FROM $sign_up WHERE id='$id'");
$row=db_fetch_array($qry,MYSQLI_ASSOC);
$sql = 'DELETE FROM `'.$sign_up.'` WHERE `id`='.(int)$id;
                        $del=db_query($connect,$sql);
						
                    }
                    if($del){
echo "<meta http-equiv=\"refresh\" content=\"0;URL=reg.php\">";
}
                }
                }
                 ?>
				 
				 <?php
			if(isset($_POST['deleteadmin'])){
                // Check if delete button active, start this
                if (isset($_POST['deleteadminsselect']) && is_array($_POST['deleteadminsselect'])) {
                    foreach ($_POST['deleteadminsselect'] as $id => $value) {
					$qry=db_query($connect,"SELECT * FROM $admin WHERE admin_id='$id'");
                    $row=db_fetch_array($qry,MYSQLI_ASSOC);
                   $sql = 'DELETE FROM `'.$admin.'` WHERE `admin_id`='.(int)$id;
                        $del=db_query($connect,$sql);
	                    }
                    if($del){
echo "<meta http-equiv=\"refresh\" content=\"0;URL=_04071984.php\">";
}
                }
                }
                 ?>
				 
<?php
if(isset($_POST['newtransact'])){

$id = db_escape($connect, $_POST['id']); 
$name = db_escape($connect, $_POST['name']); 
$date = db_escape($connect, $_POST['date']); 
$t_type = db_escape($connect, $_POST['t_type']); 
$t_description = db_escape($connect, $_POST['t_description']); 
$debit = db_escape($connect, $_POST['debit']); 
$balance = db_escape($connect, $_POST['balance']); 
$currency = db_escape($connect, $_POST['currency']); 

$exec = db_query($connect,"INSERT INTO $trans (id, name, date, t_type, t_description, debit, balance, currency) VALUES ('$id','$name','$date','$t_type','$t_description','$debit','$balance','$currency' )");

if($exec){
 echo "<meta http-equiv=\"refresh\" content=\"0;URL=user_details.php?id=$id\">";
}

else {
echo "<div class='bg-yellow-100 border border-yellow-400 text-yellow-700 px-4 py-3 rounded mb-2'>Error Sending Creating Transaction..</div>";
}
}
?>

<?php
if(isset($_POST['edittransact'])){

$id = db_escape($connect, $_POST['id']); 
$name = db_escape($connect, $_POST['name']); 
$date = db_escape($connect, $_POST['date']); 
$t_type = db_escape($connect, $_POST['t_type']); 
$t_description = db_escape($connect, $_POST['t_description']); 
$debit = db_escape($connect, $_POST['debit']); 
$balance = db_escape($connect, $_POST['balance']); 

// update data in mysql database 
$sql="UPDATE $trans SET name='$name', date='$date', t_type='$t_type', t_description='$t_description', debit='$debit', balance='$balance'
WHERE trans_id='$id'";
$result=db_query($connect,$sql);

if($result){
 echo "<meta http-equiv=\"refresh\" content=\"0;URL=trans_detail.php?id=$id\">";
}

else {
echo "<div class='bg-yellow-100 border border-yellow-400 text-yellow-700 px-4 py-3 rounded mb-2'>Error Sending Message..</div>";
}
}
?>

<?php
			if(isset($_POST['deletetrans'])){
                $id=$_POST["id"];
$user=$_POST["user"];
                    $qry=db_query($connect,"SELECT * FROM $trans WHERE trans_id='$id'");
                    $row=db_fetch_array($qry,MYSQLI_ASSOC);
			$sql = 'DELETE FROM `'.$trans.'` WHERE `trans_id`='.(int)$id;
                        $del=db_query($connect,$sql);
                    if($del){
 echo "<meta http-equiv=\"refresh\" content=\"0;URL=user_details.php?id=$user\">";
}
}                
?>
<?php
			if(isset($_POST['deleteben'])){
                $id=$_POST["id"];
$user=$_POST["user"];
                    $qry=db_query($connect,"SELECT * FROM $ben_info WHERE ben_id='$id'");
                    $row=db_fetch_array($qry,MYSQLI_ASSOC);
			$sql = 'DELETE FROM `'.$ben_info.'` WHERE `ben_id`='.(int)$id;
                        $del=db_query($connect,$sql);
                    if($del){
 echo "<meta http-equiv=\"refresh\" content=\"0;URL=user_details.php?id=$user\">";
}
}                
?>

<?php
if(isset($_POST['confirm_chk'])){

$id=$_POST["id"];
$chk_status='Confirmed';

// update data in mysql database 
$sql="UPDATE $chk_info SET chk_status='$chk_status'
WHERE chk_id='$id'";
$result=db_query($connect,$sql);

// if successfully updated. 
if($result){
echo "<div class='bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-2'>Successful Confirmed</div>";
 echo "<meta http-equiv=\"refresh\" content=\"1;URL=chk_detail.php?id=$id\">";
}

else {
echo "<div class='bg-yellow-100 border border-yellow-400 text-yellow-700 px-4 py-3 rounded mb-2'>Error Confirming</div>";
}
}
?>

<?php
			if(isset($_POST['deletechk'])){
               $id=$_POST["id"];
$user=$_POST["user"];
				$qry=db_query($connect,"SELECT * FROM $chk_info WHERE chk_id='$id'");
$row=db_fetch_array($qry);
if($row["pic"]!="") {  
  $img_name=$row["pic"];
  unlink("images/".$img_name);
}
                        $sql = 'DELETE FROM `'.$chk_info.'` WHERE `chk_id`='.(int)$id;
                        $del=db_query($connect,$sql);
				
                    if($del){
 echo "<meta http-equiv=\"refresh\" content=\"0;URL=user_details.php?id=$user\">";
}
}
 ?>
 
<?php
			if(isset($_POST['deletetransact'])){
                // Check if delete button active, start this
                if (isset($_POST['deletetransactselect']) && is_array($_POST['deletetransactselect'])) {
                    foreach ($_POST['deletetransactselect'] as $trans_id => $value) {
					$qry=db_query($connect,"SELECT * FROM $trans WHERE trans_id='$trans_id'");
$row=db_fetch_array($qry,MYSQLI_ASSOC);
$sql = 'DELETE FROM `'.$trans.'` WHERE `trans_id`='.(int)$trans_id;
                        $del=db_query($connect,$sql);
                    }
                    if($del){
echo "<meta http-equiv=\"refresh\" content=\"0;URL=view_transact.php\">";
}
                }
                }
                 ?>
<?php
			if(isset($_POST['deletemssg'])){
			  // Check if delete button active, start this
                if (isset($_POST['deletemssgselect']) && is_array($_POST['deletemssgselect'])) {
                    foreach ($_POST['deletemssgselect'] as $mssg_id => $value) {
					$qry=db_query($connect,"SELECT * FROM $mail WHERE mssg_id='$mssg_id'");
$row=db_fetch_array($qry,MYSQLI_ASSOC);
                        $sql = 'DELETE FROM `'.$mail.'` WHERE `mssg_id`='.(int)$mssg_id;
                        $del=db_query($connect,$sql);
                    }
                    if($del){
echo "<meta http-equiv=\"refresh\" content=\"0;URL=mssg.php\">";
}
                }
                }
                 ?>