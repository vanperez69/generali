<?php
/**
 * Simple Database Wrapper - replaces mysqli with JSON database
 * This class provides all mysqli functions as methods
 */

class DB {
    private $jsonDb;
    
    public function __construct($jsonDb) {
        $this->jsonDb = $jsonDb;
    }
    
    // Escape string
    public function escape($string) {
        return $this->jsonDb->escape($string);
    }
    
    // Query
    public function query($query) {
        return $this->jsonDb->query($query);
    }
    
    // Fetch array
    public function fetch_array($result, $type = 1) {
        if (is_object($result) && method_exists($result, 'fetch_array')) {
            return $result->fetch_array($type);
        }
        return null;
    }
    
    // Fetch row (returns indexed array)
    public function fetch_row($result) {
        if (is_object($result) && method_exists($result, 'fetch_row')) {
            return $result->fetch_row();
        }
        return null;
    }
    
    // Number of rows
    public function num_rows($result) {
        if (is_object($result) && method_exists($result, 'num_rows')) {
            return $result->num_rows();
        }
        return 0;
    }
    
    // Insert ID
    public function insert_id() {
        return $this->jsonDb->insert_id();
    }
    
    // Get last error
    public function error() {
        return $this->jsonDb->getLastError();
    }
}

// Global wrapper functions that work with the DB class
function db_escape($db, $string) {
    return $db->escape($string);
}

function db_query($db, $query) {
    return $db->query($query);
}

function db_fetch_array($result, $type = 1) {
    if (is_object($result) && method_exists($result, 'fetch_array')) {
        return $result->fetch_array($type);
    }
    return null;
}

function db_fetch_row($result) {
    if (is_object($result) && method_exists($result, 'fetch_row')) {
        return $result->fetch_row();
    }
    return null;
}

function db_num_rows($result) {
    if (is_object($result) && method_exists($result, 'num_rows')) {
        return $result->num_rows();
    }
    return 0;
}

function db_insert_id($db) {
    return $db->insert_id();
}

function db_error($db) {
    return $db->error();
}
?>