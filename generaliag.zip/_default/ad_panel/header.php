<?php
session_start();
require_once('inc/config.php');
	
	// set inactive timing to 30minutes of idileness
	$inactive = 60*60;
	 
	if (isset($_SESSION["timeout"])) {
	    // calculate the session's "time to live"
	    $sessionTTL = time() - (int)$_SESSION["timeout"];
	    if ($sessionTTL > $inactive) {
	        session_destroy();
	        header("Location: index.php");
			exit();
	    }
	}
	 
	$_SESSION["timeout"] = time();
	
	
if(!isset($_SESSION['admin_id'])){
     header( 'Location: index.php' );
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="author" content="Da Netseer" />
    <title><?php echo $a_title ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="img/favicon.gif">
    
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: '#3B82F6',
                        secondary: '#6B7280',
                        accent: '#10B981',
                        dark: '#1F2937'
                    }
                }
            }
        }
    </script>
    
    <!-- Custom CSS for specific components -->
    <link rel="stylesheet" href="css/zebra_datepicker.css" type="text/css">
    <link rel="stylesheet" type="text/css" href="css/navi.css" media="screen" />
    
    <!-- JavaScript Libraries -->
    <script type="text/javascript" src="js/jquery-1.7.2.min.js"></script>
    <script type="text/javascript" src="js/zebra_datepicker.js"></script>
    <script type="text/javascript" src="js/tinymce/tinymce.min.js"></script>
    
    <script type="text/javascript">
        tinymce.init({
            selector: "#textarea"
        });
    </script>
    
    <script LANGUAGE="JavaScript">	
    $(document).ready(function() {
        // assuming the controls you want to attach the plugin to
        // have the "datepicker" class set
        $('input.datepicker').Zebra_DatePicker();
    });
    
    function confirm_delete() {
        var agree=confirm("Are you sure you want to delete?");
        if (agree)
            return true ;
        else
            return false ;
    }
    
    function confirm_submit() {
        var agree=confirm("Are you sure you want to Submit?");
        if (agree)
            return true ;
        else
            return false ;
    }
    
    function maxLength(el) {    
        if (!('maxLength' in el)) {
            var max = el.attributes.maxLength.value;
            el.onkeypress = function () {
                if (this.value.length >= max) return false;
            };
        }
    }
    
    maxLength(document.getElementById("message"));
    </script>
    
    <script type="text/javascript" language="javascript">
    function checkAll(deleteuserform, checktoggle) {
        var checkboxes = new Array(); 
        checkboxes = document[deleteuserform].getElementsByTagName('input');
     
        for (var i=0; i<checkboxes.length; i++)  {
            if (checkboxes[i].type == 'checkbox')   {
                checkboxes[i].checked = checktoggle;
            }
        }
    }
    </script>
    
    <script>
        // Mobile menu functionality
        document.addEventListener('DOMContentLoaded', function() {
            const mobileMenuToggle = document.getElementById('mobileMenuToggle');
            const sidebar = document.getElementById('sidebar');
            const backdrop = document.getElementById('mobileMenuBackdrop');
            
            function openMobileMenu() {
                sidebar.classList.remove('-translate-x-full');
                backdrop.classList.remove('-translate-x-full');
            }
            
            function closeMobileMenu() {
                sidebar.classList.add('-translate-x-full');
                backdrop.classList.add('-translate-x-full');
            }
            
            mobileMenuToggle.addEventListener('click', openMobileMenu);
            backdrop.addEventListener('click', closeMobileMenu);
            
            // Close menu on window resize if switching to desktop
            window.addEventListener('resize', function() {
                if (window.innerWidth >= 1024) { // lg breakpoint
                    closeMobileMenu();
                }
            });
        });
    </script>
    <style>
    /* Ensure the sidebar content starts from the top on mobile */
    @media (max-width: 1023px) {
        #sidebar {
            top: 0;
            padding-top: 4rem; /* Space for mobile menu button */
        }
    }
    
    /* Ensure desktop sidebar sticks properly */
    @media (min-width: 1024px) {
        #sidebar {
            position: sticky;
            top: 0;
            height: 100vh;
            overflow-y: auto;
        }
    }
</style>
</head>

<body class="bg-gray-50 min-h-screen">
    <div class="min-h-screen flex flex-col">
        <!-- Header Section -->
        <div id="header" class="sticky top-0 z-50 bg-white shadow-md border-b border-gray-200 mb-4">
            <!-- Top Bar -->
            <div id="top" class="bg-gradient-to-r from-primary to-gray-600 text-white">
                <div class="container mx-auto px-4 py-3">
                    <div class="flex flex-col sm:flex-row justify-between items-center">
                        <!-- Left Side - Welcome Message -->
                        <div class="left mb-2 sm:mb-0">
                            <p class="text-sm sm:text-base">
                                Welcome, <strong class="font-semibold"><?php echo $_SESSION["a_name"]; ?></strong> 
                                [ <a href="logout.php" class="text-blue-100 hover:text-white underline transition duration-200">logout</a> ]
                            </p>
                        </div>
                        
                        <!-- Right Side - Login Time -->
                        <div class="right">
                            <div class="text-right">
                                <p class="text-sm sm:text-base">
                                    Login Time: <strong class="font-semibold">
                                        <script>
                                            var mydate=new Date()
                                            var theYear=mydate.getFullYear()
                                            var day=mydate.getDay()
                                            var month=mydate.getMonth()
                                            var daym=mydate.getDate()
                                            if (daym<10)
                                                daym="0"+daym
                                            var dayarray=new Array("Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday")
                                            var montharray=new Array("January","February","March","April","May","June","July","August","September","October","November","December")
                                            document.write(dayarray[day]+", "+montharray[month]+" "+daym+", "+theYear)
                                        </script>
                                    </strong>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Main Content Area with Sidebar -->
        <div class="flex flex-1 mb-10">
            <!-- Mobile Menu Toggle Button -->
            <button id="mobileMenuToggle" class="lg:hidden fixed top-4 left-4 z-50 bg-white p-2 rounded-md shadow-md border border-gray-200">
                <svg class="w-6 h-6 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path>
                </svg>
            </button>
  <?php          
require_once('menu_s.php');
?>
<!-- Main Content -->
            <div id="main" class="flex-1 p-6 lg:ml-0">
