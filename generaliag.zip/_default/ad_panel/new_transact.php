<?php
include('header.php');
// get value of id that sent from address bar
$id=$_GET['id'];
// Retrieve data from database 
$sql="SELECT * FROM $tbl_name WHERE id='$id'";
$result=db_query($connect,$sql);
$rows=db_fetch_array($result, MYSQLI_ASSOC);

?>

<div class="w-full bg-white rounded-lg shadow-md p-6">
    <div class="flex justify-end mb-4">
        <a href="javascript:history.back(1)" class="bg-gray-600 hover:bg-gray-700 text-white font-medium py-2 px-4 rounded-lg transition duration-200">
            Click To Go Back
        </a>
        <div class="ml-4">
            <?php include($forms); ?>
        </div>
    </div>
    
    <div class="bg-gray-50 rounded-lg p-6">
        <h2 class="text-xl font-bold text-gray-800 border-b-2 border-primary pb-2 mb-6">
            Create New Transaction For <?php echo $rows['name']; ?>.
        </h2>
        
        <form action="" method="post" class="space-y-6">
            <!-- First Row -->
            <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div class="flex flex-col">
                    <input name="id" type="hidden" value="<?php echo $rows['id']; ?>"/>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Transaction Name:</label>
                    <input type="text" name="name" id="name" placeholder="Transaction Name" required="" 
                           class="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"/>
                </div>
                
                <div class="flex flex-col">
                    <label class="block text-sm font-medium text-gray-700 mb-2">Type:</label>
                    <select name="t_type" required="" 
                            class="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent">
                        <option value="" selected="selected">Select Type</option>
                        <option value="Deposit">Deposit</option>
                        <option value="Withdrawal">Withdrawal</option>
                        <option value="ATM">ATM</option>
                        <option value="Check">Check</option>
                        <option value="Online">Online</option>
                        <option value="POS">POS</option>
                    </select>
                </div>
                
                <div class="flex flex-col">
                    <label class="block text-sm font-medium text-gray-700 mb-2">Date:</label>
                    <input type="text" class="datepicker" name="date" id="date" placeholder="Date" required="" 
                           class="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"/>
</div>
             </div>
            
            <!-- Second Row -->
            <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div class="flex flex-col">
                    <label class="block text-sm font-medium text-gray-700 mb-2">Leg. Balance:</label>
                    <input type="text" name="balance" id="balance" 
                           oninput="
            this.value = this.value
                .replace(/[^0-9.]/g, '')            // allow only digits & .
                .replace(/(\..*)\./g, '$1')         // prevent more than one .
                .replace(/^(\d{11})(\d+)/, '$1')    // limit 11 digits before decimal
                .replace(/^(\d+)\.(\d{0,2}).*$/, '$1.$2'); // allow only 2 decimals
       "
                           placeholder="Numbers Only" required="" 
                           class="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"/>
                </div>
                
                <div class="flex flex-col">
                    <label class="block text-sm font-medium text-gray-700 mb-2">Amount:</label>
                    <input type="text" name="debit" id="debit" 
                            oninput="
            this.value = this.value
                .replace(/[^0-9.]/g, '')            // allow only digits & .
                .replace(/(\..*)\./g, '$1')         // prevent more than one .
                .replace(/^(\d{11})(\d+)/, '$1')    // limit 11 digits before decimal
                .replace(/^(\d+)\.(\d{0,2}).*$/, '$1.$2'); // allow only 2 decimals
       "
                           placeholder="Numbers Only" required="" 
                           class="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"/>
                </div>
                
                <div class="flex flex-col">
                    <label class="block text-sm font-medium text-gray-700 mb-2">Available Balance:</label>
                    <span class="px-3 py-2 bg-gray-100 border border-gray-300 rounded-md text-gray-900">
                        <?php echo $rows['currency']; ?><?php $availablebalance= $rows['availablebalance'];
                        $number = number_format($availablebalance, 2); print $number ?>
                    </span>
                </div>
			</div>
            
            <!-- Third Row -->
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div class="flex flex-col">
                    <label class="block text-sm font-medium text-gray-700 mb-2">Description:</label>
                    <textarea name="t_description" id="textarea" cols="30" rows="5" 
                              class="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent resize-none"></textarea>
</div>
 
                <div class="flex flex-col justify-between">
                    <input name="currency" type="hidden" value="<?php echo $rows['currency']; ?>"/>
                    <div class="flex flex-col sm:flex-row gap-2 justify-end">
                        <button type="submit" name="newtransact" id="add" onclick="return confirm_submit()" 
                                class="bg-primary hover:bg-primary-dark text-white font-medium py-2 px-6 rounded-lg transition duration-200">
                            Create Transaction
                        </button>
                        <button type="reset" 
                                class="bg-gray-600 hover:bg-gray-700 text-white font-medium py-2 px-6 rounded-lg transition duration-200">
                            Clear
                        </button>
                    </div>
                </div>
            </div>
        </form>
  </div>
</div>

    </div>
</div>
	<?php
include('footer.php')
?>
